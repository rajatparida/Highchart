<?php 
global $base_url, $user; ?>
<script type="text/javascript">
.upcom-auction{ 
	background: none repeat scroll 0 0 #3E3E41;
    color: #FFFFFF;
    font-size: 16px;
    height: 19px;
    margin: 0;
    padding: 6px; }
</script>
<?php $sellThroughRate->printScripts();?>
<div id="sellThroughRate" class="upcom-auction"></div> 
<script type="text/javascript"><?php echo $sellThroughRate->render();?></script>


