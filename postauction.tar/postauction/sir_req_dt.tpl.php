<?php
// print_r($data);
// print_r($rlddata);
$auction_dt = node_load($data->auction_id);
$lot_dt = node_load($data->lot_id);
$seller_dt = user_load($auction_dt->uid);
$bidder_dt = user_load($data->user_id);
$rr_dt = taxonomy_term_load($data->remove_reason);
?>
<table style="width:100%!important;">
	<tr><td ><strong> Auction </strong> </td><td><?php echo $auction_dt->nid."-".$auction_dt->title?></td></tr>
	<tr><td ><strong> Lot </strong> </td><td><?php echo $lot_dt->nid."-".$lot_dt->title?></td></tr>
	<tr><td><strong>EOA Date</strong> </td><td><?php echo date("Y-m-d",$data->created)?></td></tr>
	<tr><td><strong>Seller</strong> </td><td><?php echo $seller_dt->mail;?></td></tr>
	<tr><td><strong>Bidder</strong> </td><td><?php echo $bidder_dt->mail;?></td></tr>
	<tr><td><strong>Status</strong> </td><td><?php echo remove_soldlot_request_status($data->remove);?></td></tr>
	<tr><td colspan="2"><ul style="list-style-type: none;">
		<?php
		foreach($rlddata as $rmv_his)
		{
			$status_text = remove_soldlot_request_status($rmv_his->status);
			echo '<li style="width:100%;"><div style="float:left;width:22%;"> On '.$rmv_his->date.'</div>';
			echo '<div style="float:left;width:70%;"> '.$status_text.'<br>'.$rmv_his->comment.'</div></li>';
		}
		?>
		</ul></td></tr>
	<tr><td><strong>&nbsp;</strong> </td><td><a onclick="history.go(-1);" href="javascript:void(0)"> Back</a>
	</td></tr>
	
</table>
