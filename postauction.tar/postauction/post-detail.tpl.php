<?php
global $base_url;
global $user;
//echo "<pre>";print_r($data); die;

$title = $data->title;
$time = $data->field_auction_start_time[$data->language][0]['value'];
$des = $data->body[$data->language][0]['value'];
$term = $data->field_auction_term[$data->language][0]['value'];
$venue = $data->field_auction_venues[$data->language][0]['country_name'];
$currency_obj = taxonomy_term_load($data->field_currency[$data->language][0]['tid']);
$currency =  $currency_obj->name;
//$premium = $data->field_buyers_premium[$data->language][0]['value'];
//$premium = $data->field_buyers_premium['und'][0]['value'];
$pack_obj = node_load($data->field_purchased_package[$data->language][0]['nid']);
$pack = $pack_obj->title;
$premium = getpremiumlist($data->vid);

?>

<div class='det-title'><h3><?php echo $title;?></h3></div>
<div class="det">
<div class='det-type'>Auction Type:<?php echo $pack;?></div>
<div class='det-title'>Auction Title:<?php echo $title;?></div>
<div class='det-time'>Auction Date:<?php echo date('H:i A - M jS,Y',strtotime($time));?></div>
<div class='det-des'>Auction Description:<?php echo $des;?></div>
<div class='det-term'>Terms and conditions:<?php echo $term;?></div>
<div class='det-venue'>Auction Location:<?php echo $venue;?></div>
<div class='det-currency'>Currency:<?php echo $currency;?></div>
<div class='det-premium'>Buyer's Premium:<?php echo $premium;?></div>
</div>
