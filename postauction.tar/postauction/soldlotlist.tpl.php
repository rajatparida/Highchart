<?php
global $base_url;
?>
<table>
<tr><th>Lot Title</th><th>Hammer Price</th>
<th>Bidder</th>
 <th> Seller </th>
 <th>Auction</th>
  <th>Status</th> 
  <th>Sold Date </th>
   </tr>
<?php foreach($data as $soldlot)
{
	//print_r($soldlot);
	$lot_id = $soldlot->lot_id;
	$lot_dt = node_load($lot_id);
	
	$auction_id = $soldlot->auction_id;
	$auction_dt = node_load($auction_id);
	$seller_dt = user_load($auction_dt->uid);
	
	$bidder_id = $soldlot->user_id;
	$bidder_dt = user_load($bidder_id);
	$statusText = "";
	if($soldlot->paid!=0)
	{
		$statusText = '<span title="Paid"> P </span>';
	}
	if($soldlot->shipped!=0)
	{
		$statusText .= '<span title="Shipped"> S </span>';
	}
	if($soldlot->dispute!=0)
	{
		$statusText .= '<span title="Disputed"> D </span>';
	}
	if($soldlot->remove!=0)
	{
		$statusText .= '<span title="Removed Status" '.$soldlot->remove.remove_soldlot_request_status($soldlot->remove).' style="cursor:pointer"> R </span>';
	}
	
	?>
	<tr><td>#<?php echo $lot_id ?>-<a href='<?php echo  url('node/'.$lot_dt->nid);?>'><?php echo $lot_dt->title;?></a></td>
	<td><?php echo $soldlot->hammer_price;?></td>
	<td><span title="<?php echo $bidder_dt->mail;?>"><a href="<?php echo $base_url ?>/user/bidders-info/<?php echo $bidder_dt->uid;?>"><?php echo $bidder_dt->name;?></a> <span> </td>
	<td><span title="<?php echo $seller_dt->mail;?>"><a href="<?php echo $base_url ?>/user/sellers-info/<?php echo $seller_dt->uid;?>"><?php echo $seller_dt->name;?></a> <span> </td>
	<td>#<?php echo $auction_id ?>-<a href='<?php echo  $base_url.'/catalog/'.$auction_dt->nid;?>'><?php echo $auction_dt->title;?></a></td>
	<td> <?php echo $statusText;?></td>
	<td><?php echo date("Y-m-d H:i:s",$soldlot->created)?></td>
	</tr>
	<?php
}
?>
</table>
