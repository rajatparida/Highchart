<?php
global $base_url;
global $user;
$title = $data->title;
$time = $data->field_auction_start_time[$data->language][0]['value'];
$des = $data->body[$data->language][0]['value'];
$term = $data->field_auction_term[$data->language][0]['value'];
$venue = $data->field_auction_venues[$data->language][0]['country_name'];
$currency_obj = taxonomy_term_load($data->field_currency[$data->language][0]['tid']);
$currency = $currency_obj->name;
//$premium = $data->field_buyers_premium[$data->language][0]['value'];
//$premium = $data->field_buyers_premium['und'][0]['value'];
$pack_obj = node_load($data->field_purchased_package[$data->language][0]['nid']);
$pack = $pack_obj->title;
$premium = getpremiumlist($data->vid);
?>
<!-- tans firsrt -->
<!--<div class='det-title'><h3><?php //echo $title; ?></h3></div>-->
<div class="det det-main">
    <div class='det-type det-odd'><label>Auction Type:</label><span><?php echo $pack; ?></span></div>
    <div class='det-title det-even'><label>Auction Title:</label><span><?php echo $title; ?></span></div>
    <div class='det-time det-odd'><label>Auction Date:</label><span><?php echo date('H:i A - M jS,Y', strtotime($time)); ?></span></div>
    <div class='det-des det-even'><label>Auction Description:</label><span class="bg-text"> <div id='mycustomscroll3' class='flexcroll'><?php echo $des; ?></div></span></div>
    <div class='det-term det-odd'><label>Terms and conditions:</label><span class="bg-text"> <div id='mycustomscroll3' class='flexcroll'><?php echo $term; ?></div></span></div>
    <div class='det-venue det-even'><label>Auction Location:</label><span><?php echo $venue; ?></span></div>
    <div class='det-currency det-odd'><label>Currency:</label><span><?php echo $currency; ?></span></div>
    <div class='det-premium det-even'><label>Buyer's Premium:</label><span><?php echo $premium; ?></span></div>
</div>
