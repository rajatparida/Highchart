<?php 
$act_val = node_load($eoa_report[0]->auction_id);
//print_r($act_val); 
?>
<h2>End Of Auction Report - <?php echo $act_val->title; ?></h2>
<table>
	<tr>
		<th>Lot</th>
		<th>Auction Title</th>
		<th>Hammer Price</th>
		<th>Premium</th>
		<th>First Name</th>
		<th>Last Name</th>
		<th>Username</th>
		<th>Email</th>
		<th>Paid</th>
		<th>Shipped</th>
		<th>Dispute</th>
		<th>Remove</th>
	</tr>
	
	<?php 
	foreach ($eoa_report as $value) {		
		$act_dtl = node_load($value->auction_id) ;
		$user_dtl = user_load($value->uid);
        $lot_dtl = node_load($value->lot_id);
     //   print_r($act_dtl);
       //print_r($user_dtl); 
       // $act_dtl = node_load($res->auctionid) ;     
          
	 ?>
	<tr>
	<td><?php echo $value->lot_no; ?></td>
	<td><?php echo $lot_dtl->title; ?></td>
	<td><?php echo $value->bid_amt; ?></td>
	<td><?php echo $act_dtl->field_buyers_premium['und'][0]['value'];?></td>
	<td><?php echo $user_dtl->field_first_name['und'][0]['safe_value'];?></td>
	<td><?php echo $user_dtl->field_last_name['und'][0]['safe_value'];?></td>
	<td><?php echo $user_dtl->name;?></td>
	<td><?php echo $user_dtl->mail;?></td>
	<td><input type="checkbox" name="removed" id="remove" value="<?php echo $res->Removed; ?>"></td>
	<td><input type="checkbox" name="removed" id="remove" value="<?php echo $res->Removed; ?>"></td>
	<td><input type="checkbox" name="removed" id="remove" value="<?php echo $res->Removed; ?>"></td>
	<td><input type="checkbox" name="removed" id="remove" value="<?php echo $res->Removed; ?>"></td>
	
</tr>
	<?php } ?>
</table>

