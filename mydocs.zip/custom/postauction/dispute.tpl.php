<?php
//echo 'dispute page' ;
//print_r($result);
global $base_url ;
?>
<table> 
    <tr> 
        <th>Lot</th>
        <th>Auction</th>
        <th>Title</th>
        <th>Price</th>
        <th>Premium</th>
        <th>Name</th>        
        <th>User name</th>
        <th>Email</th>
        <th>Paid</th>
        <th>Shipped</th>
        <th>Dispute</th>
        <th>Removed</th>
    </tr>
    <?php 
    foreach ($result as $res) {              
        $user_dtl = user_load($res->bidderid);
        $lot_dtl = node_load($res->lot_id) ;
        $act_dtl = node_load($res->auctionid) ;       
        $fname = $user_dtl->field_first_name['und'][0]['safe_value'];   
        $lname = $user_dtl->field_last_name['und'][0]['safe_value'];
          ?>

     <form>
    <tr>
        <td><?php echo $res->lotno; ?></td>
        <td><?php echo $res->auctionid; ?></td>       
        <td><?php echo $lot_dtl->title; ?></td>        
        <td><?php echo $res->HammerPrice; ?></td>
        <td><?php echo $act_dtl->field_buyers_premium['und'][0]['value'] ; ?>% </td>       
        <td><?php echo $fname.'&nbsp;' . $lname ; ?></td>       
        <td><?php echo $user_dtl->name; ?></td>
        <td><?php echo $user_dtl->mail; ?></td>             
        <td><input type="checkbox" name="paid" id="paid" value="1" <?php if ($res->Paid == 1) echo 'checked'; ?> /></td>
        <td><input type="checkbox" name="shiped" id="shiped" value="<?php echo $res->Shipped; ?>"></td>        
        <?php if ($res->Disputes == 0) {  ?>
        <td><a href="<?php echo $base_url;?>/dispute/nojs/reasons/<?php echo $res->id; ?>" class="ctools-use-modal ctools-modal-modal-popup-medium"><input type="checkbox" name="dispute" id="dispute" value="<?php echo $res->Disputes ?>:"  /></a></td>
        <?php } else { ?>
        <td><a href="<?php echo $base_url;?>/dispute/nojs/removereasons/<?php echo $res->id; ?>" class="ctools-use-modal ctools-modal-modal-popup-medium"><input type="checkbox" name="dispute" id="dispute" value="<?php echo $res->Disputes ?>:"checked/></a></td>    
        <?php } ?>
        
        
        <td><input type="checkbox" name="removed" id="remove" value="<?php echo $res->Removed; ?>"></td>
    </tr>
     </form> 
    <?php } ?>
</table>

