<?php
 //print_r($data->hammer_price);
 
$auction_dt = node_load($data->auction_id);
//print_r($auction_dt);
$lot_dt = node_load($data->lot_id);
$seller_dt = user_load($auction_dt->uid);
$bidder_dt = user_load($data->user_id);
$rr_dt = taxonomy_term_load($data->remove_reason);
 $premiumval = getPremiumValue($data->auction_id, $data->hammer_price); 
 $newpremium = $data->hammer_price * ($premiumval / 100);
 $total = $newpremium + $data->hammer_price;
  $auc_currency = taxonomy_term_load($auction_dt->field_currency['und'][0]['tid']);
?>
<table style="width:100%!important;">
	<tr><td ><strong> Auction </strong> </td><td><?php echo $auction_dt->nid."-".$auction_dt->title?></td></tr>
	<tr><td ><strong> Lot </strong> </td><td><?php echo $lot_dt->nid."-".$lot_dt->title?></td></tr>
        <tr><td ><strong> Lot Hammer Price </strong> </td><td><?php echo $auc_currency->name;?>&nbsp;<?php echo $data->hammer_price;?></td></tr>
        <tr><td ><strong> Premium </strong> </td><td><?php echo $auc_currency->name;?>&nbsp;<?php echo $newpremium;?></td></tr>
        <tr><td ><strong> Total </strong> </td><td><?php echo $auc_currency->name;?>&nbsp;<?php echo $total;?></td></tr>
	<tr><td><strong>EOA Date</strong> </td><td><?php echo date("Y-m-d",$data->created)?></td></tr>
	<tr><td><strong>Seller</strong> </td><td><?php echo $seller_dt->mail;?></td></tr>
	<tr><td><strong>Bidder</strong> </td><td><?php echo $bidder_dt->mail;?></td></tr>
	<tr><td><strong>Status</strong> </td><td><?php echo remove_soldlot_request_status($data->remove);?></td></tr>
	<tr><td colspan="2"><ul style="list-style-type: none;">
		<?php
		foreach($rlddata as $rmv_his)
		{
			$status_text = remove_soldlot_request_status($rmv_his->status);
			echo '<li style="width:100%;"><div style="float:left;width:22%;"> On '.$rmv_his->date.'</div>';
			echo '<div style="float:left;width:70%;"> '.$status_text.'<br>'.$rmv_his->comment.'</div></li>';
		}
		?>
		</ul></td></tr>
	<tr><td><strong>&nbsp;</strong> </td><td><a onclick="history.go(-1);" href="javascript:void(0)"> Back</a>
	</td></tr>
	
</table>
