<div class="seller-dash">
    <h3>Saved Items </h3>
</div>
<div class="seller-auction">
    <div class="cover-image">
        <div class="auction-content ">
            <div class="auction-left">
                <div class="auction-category">
                    <?php
                    global $base_url, $base_path;
                    print drupal_render(drupal_get_form('create_search_form'));
                    ?>
                </div>
            </div>
            <div class="auction-right">
                <label>Records</label>	<select name="paging" id="paging" onchange="limitfunc('<?php echo $base_url; ?>/user/saveditem<?php echo $querystring; ?>&limit=' + this.value)">
                    <?php
                    $m = 4;
                    for ($j = 0; $j < 10; $j++) {
                        ?>    
                        <option value="<?php echo $m; ?>" <?php
                        if ($m == $limit) {
                            echo "selected";
                        }
                        ?>><?php echo $m; ?></option>
                                <?php
                                $m = $m + 4;
                            }
                            ?> 
                </select>
            </div>



<?php global $base_url; ?>


        </div>
        <div class="cover-cont">
            
                
                        <?php
                        if (!empty($data)) {?>
            <div class="request-inner">
                            <div class="live-items">
                    <div class="recent-lot">
                           <?php  foreach ($data as $user_row) {
                                $nodedt = node_load($user_row['nid']);
                                $imageuri = $nodedt->uc_product_image['und'][0]['uri'];
if(!empty($nodedt->uc_product_image['und'][0]['uri']))
{
        $lot_img_uri = $nodedt->uc_product_image['und'][0]['uri'];
        $img_url = file_create_url($lot_img_uri);              
        $derivative_uri = image_style_path('130x130', $lot_img_uri);
        $style = image_style_load('130x130');
        $der_imag = image_style_create_derivative($style, $lot_img_uri, $derivative_uri); 
        $der_img = file_create_url($derivative_uri);
}        
 else {
 $der_img =$base_url.'/sites/default/files/noimage.jpg';
     
 }
                                /*if ($imageuri != '') {
                                    $imageuriarr = explode('//', $imageuri);
                                }
                                if ($imageuriarr[1] == '') {
                                    $imageur = "noimage.jpg";
                                } else {
                                    $imageur = $imageuriarr[1];
                                }
                                $filePath = 'sites/default/files/' . $imageur;
                                if ($imageur != '' && file_exists($filePath)) {
                                    $resultpath = getReImagePath($filePath, 100, 70);
                                }*/
                                $lot_alias = drupal_get_path_alias('node/' . $nodedt->nid);
                                ?>
                                <div class="lot1-cont htauto">
                                    <div class="lot1-left"> <img src="<?php echo $der_img; ?>"   /> </div>
                                    <div class="lot1-right">Title:<a href="<?php echo $base_url . "/" . $lot_alias; ?>"><?php echo $nodedt->title; ?></a><br/>
                                        Lot No:<?php echo $nodedt->field_lot_no['und'][0]['value']; ?><br/>
                                        Seller Name:<?php echo $nodedt->name; ?><br/>
                                        <a href="javascript:void(0)" class="deleteitem" id="<?php echo $user_row['itemid']; ?>">Delete</a></div>
                                </div>
                                <?php
                            }?>
                            </div><!-- recent-lot -->
                </div>
                                   
            </div><!--end of request-inner -->
            <div class="view-image"> <?php echo $paging?> </div>
               
                      <?php  } else {
                            ?>
                            No Record(s) Found
                            <?php
                        }
                        ?>

        </div> <!--end of div cover-cont -->
    </div> <!--end of div Cover-image -->
</div> <!--end of seller-auction -->