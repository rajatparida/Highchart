<?php global $base_url;
if(count($pastauctionslist)>0 && $pastauctionslist[0]->bid_status!=3){
	echo "<b>Sold ".$auctioncurrency." </b> ".$lotbidamt;
	echo "<br/><b>Item Bid History</b> ";
	
?><div class="right_sec_block"><div class="border_head">
<table  border="1">
	<tr><td><b>Bidder</b></td><td><b>Bid</b></td></tr>
 <?php 
 foreach($pastauctionslist as $amtlist){
	
	if($amtlist->bid_status==2){
		$absent='(Absentee Bid)';
	}else{
		$absent='';
	}
	$biddern='';
	if($amtlist->eUserType=='S'){
		$biddern='paimai bidder';
	}else if($amtlist->eUserType=='B'){
		$biddern='competing bidder';
	}
	echo "<tr><td>".$biddern."</td><td>".$amtlist->bid_amt.$absent."</td></tr>";
 	?> 
 
<?php } ?>
 
</table></div></div>
<?php
 }else if(count($pastauctionslist)>0 && $pastauctionslist[0]->bid_status==3){
?>
<div  style="color:green;text-align:center">
	<b>Lot Passed </b>
</div>
<?php
 }
  ?> 
