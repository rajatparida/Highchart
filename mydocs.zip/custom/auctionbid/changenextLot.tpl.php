<script src="http://<?php print $_SERVER['SERVER_ADDR'] ?>:8080/socket.io/socket.io.js"></script>
<script type="text/javascript">
	base_url = Drupal.settings.basePath;
        var socket = io.connect('http://<?php print $_SERVER['SERVER_ADDR'] ?>:8080');
        // Connect to our node/websockets server

//------------------------------------------------------//
$(document).ready(function(){
    if($('#bids-info ul li').length >0){
        $("#unsold").hide();
        $("#sold").show();
    }
    $('div').find('.slider1').removeClass('arrow1');
    $(".slider1 img").mouseenter(function () {// show pohelp
        $(".banner-slider").show();
        $(this).parents('div:eq(0)').attr('id','currentimg');
        $('#imgTitle').html($('#currentimg span').text());
        $('#currentimg').addClass('arrow1');
        var images_var=$(this).attr('src');
        $('#middle_banner').fadeIn(300).attr('src',images_var);
    });
    $(".slider1 img").mouseleave(function() {
        $(".slider1").attr('id','');
        $('.banner-slider').hide();
        $(".slider1").removeClass('arrow1');
        $('#middle_banner').fadeIn(300).attr('src','<?php echo $base_url.'/'.path_to_theme()?>/images/banner.png');
        $('#imgTitle').html('');
    });
    /*messsge 4 buttons clicked actions*/
    $('.buttons').click(function(){
        $('.buttons').removeClass('buttons');
        /*user should not click any buttons in milli seconds gap so settimeout for add class for bind click*/
        setTimeout(function(){
            $('.msgalert span a').addClass('buttons');
        },200);
        var value=$(this).attr('alt');
        var applyclass=$(this).attr('altcls');
        console.log(value);
        if($(this).attr('id')=='sendmessage' && value==''){
            $('#message_text').attr('placeholder','Please enter message to send').focus();
            return false;
        }
        socket.emit( 'message', {
            name: $("#auction_lot_id").val(),
            message: value ,
            appliedclass:applyclass
        });

        // Ajax call for saving data in table
        $.ajax({
            type: "POST",
            dataType: 'json',
            data: {
                lot_value: value,
                lot_id: $("#auction_lot_id").val(),
                act_id: $("#auction_id").val(),
                lot_no: $("#auction_lot_value").val(),
                msg_class:applyclass
            },
            url: base_url+"store-lots-seller",
            success: function(data) {

            },
            error: function(xhr, textStatus, errorThrown){
                alert('server request failed .Please check your connection!');
                return false;
            }
        });

        return false;
    });
    /*$('.actionbuttons').click(function(){
    var bidactmsg=$(this).attr('alt');
    socket.emit( 'actionsblock', { meher: "krishnakanth" } );

});*/
    $('#sold').click(function(){
        if(!$('#sold').parent().hasClass('disableBtn')){
            socket.emit( 'sold', {
                lot_id: $("#auction_lot_id").val(),
                soldamt: $('#current_soldAmt').val() ,
                appliedclass:$(this).attr('altcls')
            } );
            $('#sold').parent().addClass('disableBtn');
            $('#pass').parent().addClass('disableBtn');
            $('#nextlot').parent().removeClass('disableBtn');
            $.get(base_url+"biddingStatusAction", {
                lot_id:$("#auction_lot_id").val(),
                act_id:$("#auction_id").val(),
                bid_amt:$('#current_soldAmt').val(),
                msg_class:$(this).attr('altcls'),
                bid_status:0//status sold
            },function(req, res){
                console.log(req);
                if(res=='success'){

                }else{
                    alert('Please check your network connection.');
                    return false;
                }
            });
            socket.on('sold',function(data){
                if($("#auction_lot_id").val() ==data.lot_id){
                    $("#messasgeBoard li").eq(0).remove();
                    $("#messasgeBoard").append('<li>Lot '+data.lot_id+' sold for $'+data.soldamt+' to LiveAuctioneers</li>');
                }
            });
        }
    });
    $('#pass').click(function(){
        if(!$('#pass').parent().hasClass('disableBtn')){
            socket.emit( 'pass', {
                lot_id: $("#auction_lot_id").val() ,
                appliedclass:$(this).attr('altcls')
            } );
            $('#sold').parent().addClass('disableBtn');
            $('#pass').parent().addClass('disableBtn');
            $('#nextlot').parent().removeClass('disableBtn');
            $.get(base_url+"biddingStatusAction", {
                lot_id:$("#auction_lot_id").val(),
                act_id:$("#auction_id").val(),
                bid_amt:$('#current_soldAmt').val(),
                msg_class:$(this).attr('altcls'),
                bid_status:2//status passed
            },function(req, res){
                console.log(req);
                if(res=='success'){

                }else{
                    alert('Please check your network connection.');
                    return false;
                }
            });
            socket.on('pass',function(data){
                if($("#auction_lot_id").val() ==data.lot_id){
                    $("#messasgeBoard li").eq(0).remove();
                    $("#messasgeBoard").append('<li>Lot '+data.lot_id+' passed</li>');
                }
            });
        }
    });
    $('#nextlot').click(function(){
        var lotId=$("#auction_lot_id").val();
        if(!$('#nextlot').parent().hasClass('disableBtn')){
            $.get(base_url+"nextLot-Change", {
                lot_id:$("#auction_lot_id").val(),
                act_id:$("#auction_id").val()
            },function(req, res){
                if(res=='success'){
                    $("#replace_content").html(req);
                    //here lot values and auction values currencies everything wil change
                }else{
                    alert('Please check your network connection.');
                    return false;
                }
            });
            socket.emit( 'nextlot', {
                        act_id:$("#auction_id").val(),
                        lot_id: lotId
            });
        }
    });
    socket.on( 'message', function( data ) {
    console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>fish");
        if(data.message!=''&& $("#auction_lot_id").val()==data.name){
            $('#messasgeBoard li').eq(0).remove();
            $('#messasgeBoard').append("<li> >>"+data.message+"</li>");
            $('#imgLoads').hide();
            $('#message_text').attr('placeholder','');
            $('#message_text').val('');
            $('#sendmessage').attr('alt','');
        }
    });
    socket.on('currentbid', function( data ) {
        if($("#auction_lot_id").val()==data.lotId){
            $("#unsold").hide();
            $("#sold").show();
            $('#bids-info ul').append("<li style='background-color:#BCF7FE'>$ "+data.amountonHisthreeLi+"(LiveAuctioneers)</li>");
            $( "#bids-info ul li" ).prev().removeAttr('style');
            $("#messasgeBoard li").eq(0).remove();
            $("#messasgeBoard").append('<li>Auto accepted bid $'+data.amountonHisthreeLi+'</li>');
            var inputAskValue=parseInt(data.amountonHisthreeLi)+parseInt(data.currentIncval);
            $("#askamt").val(inputAskValue);
            $("#ask_inc").val(data.currentIncval);
            $("#current_soldAmt").val(data.amountonHisthreeLi);
        }
    });

});
</script>
<?php
global $base_url, $user;
$node_dt=node_load(arg(1));
$aucnid = $node_dt->nid;
$node_dc = node_load($seller_data[0]->entity_id);
$lot_value = $node_dc->field_lot_no['und'][0]['value'] ;
$file = file_load($node_dc->uc_product_image['und'][0]['fid']);
$image = file_create_url($file->uri);
$auctitle= $node_dc->title;
$aucnidd= $node_dc->field_lot_no['und'][0]['value'];
$desc= $node_dc->body['und'][0]['value'];
$aucdesc= $node_dc->body['und'][0]['value'];
$high = $node_dc->field_company['und'][0]['value'];
$low = $node_dc->field_low_estimate['und'][0]['value'];
$start = $node_dc->field_timeout['und'][0]['value'];
/*foreach($seller_data as $key => $val){
    if($key>0){
    $nextLotsArr[] =node_load($seller_data[$key]->entity_id);
    }
}
 */
    /*start Bid Increment -value end*/
?>
<div class="inside_middlesec page-seller-live-auction">
	<input type="hidden" id="auction_lot_id" value="<?php echo $seller_data[0]->entity_id;?>"/>
	<input type="hidden" id="auction_id" value="<?php echo $seller_data[0]->field_choose_auction_nid;?>"/>
	<input type="hidden" id="auction_lot_value" value="<?php echo $lot_value ;?>"/>
        <input type="hidden" id="current_soldAmt" value="<?php echo $bidVal ?>"/>
	<div class="inside_middlesec_left">
		<!-- left AuctionConsolePageSec -->
		<div>
			<div class="Auction1">

				<div class="banner-cont">
            <div class="slider-cont">
                <?php
                foreach($seller_data as $single_lot){
                    if($single_lot->entity_id==$seller_data[0]->entity_id)
                        continue;
                    $lid = $single_lot->entity_id;
                    $lot_dt = node_load($lid);
                    $img_url= file_create_url($lot_dt->uc_product_image['und'][0]['uri']);
                    $img_title = $lot_dt->title;

                    echo '<div class="slider1 arrow1">
                    <span style="display:none;">'.$img_title.'</span>
                    <a href="#" class="arrow-curve"></a>
                    <a href="#"><img src="'.$img_url.'"  class="banners_div" alt="" style="cursor:pointer;width:50px;height:50px;"/></a></div>';
                }

                ?>
            </div>
           <div class="banner-img">
                <div class="banner-bg" >
                    <img src="<?php echo $image ?>" id="mainimg" alt=""  /></div>
                    <div class="banner-slider"  style="margin: 25px 0%;padding: 14px 2%;width: 96%;display:none;">
                        <img id="middle_banner" src="<?php echo $base_url.'/'.path_to_theme()?>/images/banner1.jpg"  alt=""/>
                    <p id="imgTitle"></p>
                    </div>
                </div>
                <div class="banner-pop" id="popup-div">
                    <table width="100%" cellpadding="2" cellspacing="0">
                        <tr>
                            <th width="75%" align="left"> Description</th>
                            <th width="25%" align="left">Estimate</th>
                        </tr>
                        <tr>
                            <td><?php echo $aucdesc;?></td>
                            <td><span><img src="<?php echo $base_url.'/'.path_to_theme()?>/images/arrow-bot.png"  alt="" /></span><?php echo $high;?><br/>
                                <span><img src="<?php echo $base_url.'/'.path_to_theme()?>/images/arrow-toop.png"  alt="" /></span><?php echo $low;?>
                            </td>
                        </tr>
                    </table>
                    <a href="#" class="close-icon"><img src="<?php echo $base_url.'/'.path_to_theme()?>/images/close-icon.png"  alt="" /></a>
                </div>
            </div>
				<div class="clear"></div>

                    <textarea id="item-desc" style="resize:none;" rows="3" cols="57" readonly="readonly"><?php echo $desc; ?></textarea>
                    <div>
                        <p>Estimate $ <?php echo $low?> - <?php echo $high?>
                        </p>
                    </div>

                  <!-- <div class="ConsBidContr">
                                <?php
                                if(is_array($nextLotsArr)&& count($nextLotsArr)>0){
                                    foreach($nextLotsArr as $k=>$v){
                                        echo "<p class='AuctionConsolSldRHDs'>lot ".$nextLotsArr[$k]->vid.":<span>". $nextLotsArr[$k]->title."</span></p>";
                                    }
                                }
                                ?>

                        <div class="clear"></div>
                    </div>-->
                </div>
                <span class="set-img" style="float:right;margin-top: -50px;cursor:pointer;height:40px;width:40px;"> <img src="images/set.png" alt=""></span>
                <div id="qt-auc-set" style="display:none;">

                </div>
            </div>
            <span style="display:none;" id="auid"></span>
            <!-- left AuctionConsolePageSec -->
            <div class="box_shadow Consbox_shadow"></div>
        </div>
        <img src="images/loader_ajax.gif" id="imgLoads" class="overlay" style="display:none;position: absolute; right: 478px; top: 539px;"/>
        <div class="inside_middlesec_rightbid">
            <div class="sell-op" >
                <div id="bids-info">
                      <ul >
                          <?php
                          foreach($bid_history as $k =>$v){
                                echo "<li>$".$bid_history[$k]->bid_amt." (LiveAuctioneers) </li>";
                          }
                          ?>
                      </ul>
                </div>
                <div id="bids-info-detail" style="width:48%;float:left;padding:1%;" >
                    <ul >
                          <?php
                          foreach($bid_sold as $k =>$v){
                                echo "<li>Lot ".$bid_sold[$k]->lot_no." sold for ".$bid_sold[$k]->bid_amt." to LiveAuctioneers</li>";
                          }
                          ?>
                      </ul>
                </div><!-- consolePageContRHead -->
            </div >
            <div class="message-cont">
                    <ul id="messasgeBoard">
                            <li>Lot <?php echo $lot_value; ?> opened</li>
                            <li>ask $<?php echo $bidVal; ?></li>
                            <li>Auto Accepted bid <?php echo $bidVal ?></li>
                    </ul>
             </div>
            <div  class="message-test1"><textarea id="message_text" onblur="$('#sendmessage').attr('alt',$(this).val());$(this).attr('placeholder','');"></textarea></div>
            <div class="bid-span msgalert">

                <span class="ConsSelContrR flr"><a href="javascript:void(0);" altcls="color2 list1" alt="Close soon...." class="ConsSelContrRBtn buttons">Close Soon</a></span>
                <span class="ConsSelContrR flr"><a href="javascript:void(0);" altcls="color3 list1" alt="Fair Warning...This lot is about to close" class="ConsSelContrRBtn buttons">Fair Warning</a></span>
                <span class="ConsSelContrR flr"><a href="javascript:void(0);" altcls="color4 list1" alt="Last call...1....2....3..." class="ConsSelContrRBtn buttons">Last Call</a></span>
                <span class="ConsSelContrR flr"><a href="javascript:void(0);" altcls="color1 list1" id="sendmessage" alt="" class="ConsSelContrRBtn buttons">Send Message</a></span>

            </div>
            <div class="sell-bids"><p class="cbid"><strong>Bid Increment : $</strong></span><input  style="float:right;margin-top: -2%; text-align: center; width: 24%;" readonly="readonly" type="text" id="ask_inc" value="<?php echo $currentInc; ?>" /></p>
                <h4 class="nbid"><span style="float:left;width:62%;"><strong>Current Ask : $</strong></span><input  style="float:left;margin-top: -2%; text-align: center; width: 30%;" type="text" id="askamt" value="<?php echo $bidVal; ?>" /></h4>			<!-- consolePageContRHead -->
            </div>
            <div class="bid-span bidactionbtns">
                <span class="ConsSelContrR flr">
                <a class="ConsSelContrRBtn actionbuttons" alt="unsold" id="unsold" href="javascript:void(0);">Unsold</a>
                <a class="ConsSelContrRBtn actionbuttons" alt="sold" id="sold" altcls="color5 list1" href="javascript:void(0);">sold</a>
                </span>
                <span class="ConsSelContrR flr">
                <a class="ConsSelContrRBtn actionbuttons" alt="pass" id="pass" altcls="color6 list1" href="javascript:void(0);">Pass</a>
                </span>
                <span class="ConsSelContrR flr disableBtn">
                <a class="ConsSelContrRBtn actionbuttons" alt="nextlot" id="nextlot" href="javascript:void(0);">NextLot</a>
                </span>
                <span class="ConsSelContrR flr">
                <a class="ConsSelContrRBtn actionbuttons" alt="retract" href="javascript:void(0);">Retract</a>
                </span>
            </div>
            <div class="bids-span">    <span class="ConsSelContrR flr"><a href="javascript:void(0);" class="ConsSelContrRBtn">Bids over Phone</a></span>
                <span class="ConsSelContrR flr"><a href="javascript:void(0);" class="ConsSelContrRBtn">Bids over Floor</a></span>
                <span class="ConsSelContrR flr"><a href="javascript:void(0);" class="ConsSelContrRBtn">Internet</a></span></div>

            <input type="hidden" id="sdnid" value="" />
            <input type="hidden" id="sduid" value="" />
            <input type="hidden" id="sdtime" value="" />
            <input type="hidden" id="sauction" value="" />
            <input type="hidden" id="snbid" value="" />


        </div>
        <!--	<div id="basic-modal-content-seller">
                        <h4>Do you want to end this auction?</h4><br/>
                        <div class="bid-span">
                        <span style="margin-left: 18% !important;" class="ConsSelContrR flr"></span>
                        <span style="margin-left: 18% !important;" class="ConsSelContrR flr"></span>
                        </div>
                </div>-->

    </div>
