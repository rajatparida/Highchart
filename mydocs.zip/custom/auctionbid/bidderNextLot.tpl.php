<?php
global $base_url, $user;
$node_dt = node_load(arg(1));
$aucnid = $node_dt->nid;
$node_dc = node_load($bidder_data[0]->entity_id);
$lot_value = $node_dc->field_lot_no['und'][0]['value'] ;
$file = file_load($node_dc->uc_product_image['und'][0]['fid']);
$image = file_create_url($file->uri);
$auctitle= $node_dc->title;
$aucnidd= $node_dc->field_lot_no['und'][0]['value'];
$aucdesc= $node_dc->body['und'][0]['value'];
$high = $node_dc->field_company['und'][0]['value'];
$low = $node_dc->field_low_estimate['und'][0]['value'];
$start = $node_dc->field_timeout['und'][0]['value'];
?>
<!-- <script src="http://182.74.75.19/node_modules/socket.io/socket.io.js"></script> -->

<script src="http://<?php print $_SERVER['SERVER_ADDR'] ?>:8080/socket.io/socket.io.js"></script>
<script src="http://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<script type="text/javascript">
document.getElementsByTagName("body")[0].oncontextmenu = function(e){ e.preventDefault();}
var base_url = Drupal.settings.basePath;
var total_rightLi = <?php echo count($bidderResArr) ?>-9;
var socket = io.connect('http://<?php print $_SERVER['SERVER_ADDR'] ?>:8080');
var posArrlength = <?php echo $posArrLenghth ?>;
var bidrageval = <?php echo $bidrageval ?>;
var posArr = <?php echo $posArr ?>;
var bidder_status ="<?php echo $bidder_status ?>";
console.log(" total_rightLi >>> "+total_rightLi);
if(total_rightLi >=8)
$('#append_message').children('li:lt('+total_rightLi+')').remove();
$('#append_message li').eq(0).remove();
function googleTranslateElementInit() {
    new google.translate.TranslateElement({
        pageLanguage: 'en'
    }, 'google_translate_element');
}
 /*function for changing the currency amount on select from dropdown currency
 *@author   krishnakanth
 *@To       -Currency format to changes
 *@From     -Currency format from changes
 *@Amount   -Currency amount to be changed
 */
 function currencyChange(To,From,Amount){
    $('.bid-list').html('').show();
    var final_val=fx.convert(Amount, {to: To});
    var final_amt= accounting.formatMoney(final_val, To, 2, ",", ".");
    console.log(final_amt);
    var lang_data=[];
    lang_data=final_amt;
    var lang_darr=[];
    var lang_actua_fileds=12-lang_data.length;
    if(lang_actua_fileds >0){
        for(var k=0;k<lang_actua_fileds;k++){
            lang_darr.push("<div class='bid2'><span></span></div>");
        }
    }
    for (var l = 0; l < lang_data.length; l++) {
        lang_darr.push("<div class='bid2'><span>"+lang_data[l]+"</span></div>");
    }
    $.each( lang_darr, function( i, val ) {
        $('.bid-list').append(lang_darr[i]);
    });
    console.log($('.bid-list').html())
    if(To=='USD'){
        $('.bid-list').hide();
    }
}
</script>
<!-- oncontextmenu="return false;"-->
<div id="result"></div>
<div class="gallery-page">
    <div class="gallery-desc">
        <div class="gallery-top">
            <a href="#" class="logo"><img src="<?php echo $base_url.'/'.path_to_theme()?>/images/logo-small.png" alt="" /></a>
            <div class="gallery-title">
                <h4><?php echo $node_dt->title;?></h4>
                <p><?php echo $node_dt->name;?></p>
             <!--    <button onclick="openWin()">Start bid</button>
                <script>
                function openWin(){
                    var myWindow = window.open("<?php //echo $base_url.'/bidder-console/'.arg(1);?>","","width=700,height=700");
                }
            </script>  -->
        </div>
        <div class="loader">
            <span>2% &nbsp;  804 0f 822 remaining</span><br/>
            <a href="javascript:void(0);"><img src="<?php echo $base_url.'/'.path_to_theme()?>/images/loader1_.GIF"  alt="" /></a>
        </div>
    </div>
    <div class="gallery-left">
        <div class="head1"><p><span>Lot<?php echo $aucnidd;?>:</span> <?php echo $auctitle;?>&nbsp;&nbsp;&nbsp;&nbsp;<br><span style="padding-left: 150px;" id="bidfinish_msg"></span><a href="#" class="desc-icon"><img src="<?php echo $base_url.'/'.path_to_theme()?>/images/desc-icon.png"  alt="" /></a></p>
        </div>
        <div class="banner-cont" style="height: 360px !important;">
            <div class="slider-cont">
                <?php
                foreach($bidder_data as $single_lot){
                    if($single_lot->entity_id ==$bidder_data[0]->entity_id)
                    continue;
                    $lid = $single_lot->entity_id;
                    $lot_dt = node_load($lid);
                    $img_url= file_create_url($lot_dt->uc_product_image['und'][0]['uri']);
                    $img_title = $lot_dt->title;

                    echo '<div class="slider1 arrow1">
                    <span style="display:none;">'.$img_title.'</span>
                    <a href="#" class="arrow-curve"></a>
                    <a href="#"><img src="'.$img_url.'"  class="banners_div" alt="" style="cursor:pointer;width:50px;height:50px;"/></a></div>';
                }

                ?>
            </div>
           <div class="banner-img">
                <div class="banner-bg">
                    <img src="<?php echo $image ?>" id="mainimg" alt="" style="display:none;max-height: 89%;" /></div>
                    <div class="banner-slider"  style="display:none;"> <img id="middle_banner" src="<?php echo $base_url.'/'.path_to_theme()?>/images/banner1.jpg"  alt=""/>
                    <p id="imgTitle"></p>

                    </div>
                </div>
                <div class="banner-pop" id="popup-div">
                    <table width="100%" cellpadding="2" cellspacing="0">
                        <tr>
                            <th width="75%" align="left"> Description</th>
                            <th width="25%" align="left">Estimate</th>
                        </tr>
                        <tr>
                            <td><?php echo $aucdesc;?></td>
                            <td><span><img src="<?php echo $base_url.'/'.path_to_theme()?>/images/arrow-bot.png"  alt="" /></span><?php echo $high;?><br/>
                                <span><img src="<?php echo $base_url.'/'.path_to_theme()?>/images/arrow-toop.png"  alt="" /></span><?php echo $low;?>
                            </td>
                        </tr>
                    </table>
                    <a href="#" class="close-icon"><img src="<?php echo $base_url.'/'.path_to_theme()?>/images/close-icon.png"  alt="" /></a>
                </div>
            </div>
            <div class="bid-cont">
                <div class="bid-left">
                    <h2>Lot <?php echo $aucnidd;?></h2>
                    <div id="google_translate_element"></div><!--generate a dropdown for all languages!-->
                    <?php
                    $currencies = array(
                        "USD" => "United States Dollars - USD",
                        "EUR" => "Euro - EUR",
                        "GBP" => "United Kingdom Pounds - GBP",
                        "JPY" => "Japan Yen - JPY",
                        "CNY" => "China Yuan Renminbi - CNY",
                        "CNY" => "RMB (China Yuan Renminbi) - CNY",
                        "RUB" => "Russia Rubles - RUB",
                        "CAD" => "Canada Dollars - CAD",
                        "AUD" => "Australia Dollars - AUD",
                        "ARS" => "Argentina Pesos - ARS",
                        "BHD" => "Bahrain Dinars - BHD",
                        "BRL" => "Brazil Reais - BRL",
                        "BGN" => "Bulgaria Leva - BGN",
                        "CHF" => "Switzerland Francs - CHF",
                        "ZAR" => "South Africa Rand - ZAR",
                        "DZD" => "Algeria Dinars - DZD",
                        "NZD" => "New Zealand Dollars - NZD",
                        "INR" => "India Rupees - INR",
                        "CLP" => "Chile Pesos - CLP",
                        "COP" => "Colombia Pesos - COP",
                        "CRC" => "Costa Rica Colones - CRC",
                        "HRK" => "Croatia Kuna - HRK",
                        "CZK" => "Czech Republic Koruny - CZK",
                        "DKK" => "Denmark Kroner - DKK",
                        "DOP" => "Dominican Republic Pesos - DOP",
                        "EGP" => "Egypt Pounds - EGP",
                        "EEK" => "Estonia Krooni - EEK",
                        "FJD" => "Fiji Dollars - FJD",
                        "HKD" => "Hong Kong Dollars - HKD",
                        "HUF" => "Hungary Forint - HUF",
                        "ISK" => "Iceland Kronur - ISK",
                        "INR" => "India Rupees - INR",
                        "IDR" => "Indonesia Rupiahs - IDR",
                        "ILS" => "Israel New Shekels - ILS",
                        "IQD" => "Iraqi Dinar - IQD",
                        "JMD" => "Jamaica Dollars - JMD",
                        "JOD" => "Jordan Dinars - JOD",
                        "KES" => "Kenya Shillings - KES",
                        "KRW" => "Korea (South) Won - KRW",
                        "KWD" => "Kuwait Dinars - KWD",
                        "LBP" => "Lebanon Pounds - LBP",
                        "MYR" => "Malaysia Ringgits - MYR",
                        "MUR" => "Mauritius Rupees - MUR",
                        "MXN" => "Mexico Pesos - MXN",
                        "MAD" => "Morocco Dirhams - MAD",
                        "NZD" => "New Zealand Dollars - NZD",
                        "NOK" => "Norway Kroner - NOK",
                        "OMR" => "Oman Rials - OMR",
                        "PKR" => "Pakistan Rupees - PKR",
                        "PEN" => "Peru Nuevos Soles - PEN",
                        "PHP" => "Philippines Pesos - PHP",
                        "PLN" => "Poland Zlotych - PLN",
                        "QAR" => "Qatar Riyals - QAR",
                        "RON" => "Romania New Lei - RON",
                        "RUB" => "Russia Rubles - RUB",
                        "SAR" => "Saudi Arabia Riyals - SAR",
                        "SGD" => "Singapore Dollars - SGD",
                        "SKK" => "Slovakia Koruny - SKK",
                        "ZAR" => "South Africa Rand - ZAR",
                        "KRW" => "South Korea Won - KRW",
                        "LKR" => "Sri Lanka Rupees - LKR",
                        "SEK" => "Sweden Kronor - SEK",
                        "CHF" => "Switzerland Francs - CHF",
                        "TWD" => "Taiwan New Dollars - TWD",
                        "THB" => "Thailand Baht - THB",
                        "TTD" => "Trinidad and Tobago Dollars - TTD",
                        "TND" => "Tunisia Dinars - TND",
                        "TRY" => "Turkey Lira - TRY",
                        "AED" => "United Arab Emirates Dirhams - AED",
                        "VEB" => "Venezuela Bolivares - VEB",
                        "VND" => "Vietnam Dong - VND",
                        "ZMK" => "Zambia Kwacha - ZMK"
                        );
                        ?>
                        <select class="currency_list"  onchange="currencyChange($(this).val(),'USD',$('#total_bid').val())">
                            <?php
                            foreach ($currencies as $k => $v) {
                                echo "<option value=\"$k\">$v</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="bid-right">
                        <div class="bid-top">
                            <div class="bid1">&nbsp;</div>
                            <div class="bid1">&nbsp;</div>
                            <div class="bid1">&nbsp;</div>
                            <div class="bid1">&nbsp;</div>
                            <div class="bid1">&nbsp;</div>
                            <div class="bid1">&nbsp;$</div>
                            <div class="bid1"><span>$</span></div>
                            <div class="bid1"><span></span></div>
                            <div class="bid1"><span></span></div>
                            <div class="bid1"><span></span></div>
                        </div>
                        <input type="hidden" id="total_bid" value="<?php echo $bidLAtAmount ?>"/>
                        <input type="hidden" id="auction_lot_id" value="<?php echo $bidder_data[0]->entity_id;?>"/>
                        <input type="hidden" id="auction_id" value="<?php echo $aucnid;?>"/>
                        <input type="hidden" id="auction_lot_value" value="<?php echo $lot_value ;?>"/>
                        <input type="hidden" id="total_bid_with_curr" value="$<?php echo $bidLAtAmount ?>"/>
                        <span id="converted_money1" style="display:none;"></span>
                        <div class="bid-mid">
                            <div class="bid-list">
                                <div class="bid2">&nbsp;</div>
                                <div class="bid2">&nbsp;</div>
                                <div class="bid2">&nbsp;</div>
                                <div class="bid2">&nbsp;</div>
                                <div class="bid2">&nbsp;</div>
                                <div class="bid2">&nbsp;</div>
                                <div class="bid2">A</div>
                                <div class="bid2">U</div>
                                <div class="bid2">$</div>
                                <div class="bid2">1</div>
                                <div class="bid2">9</div>
                                <div class="bid2">5</div>
                            </div>
                        </div>

                        <div class="bid-bot">
                        <?php if ($user->uid == 0) {  ?>
                            <p><a href="<?php echo $base_url ?>/user/login">Sign in to bid</a> </p>
                            <?php } ?>
                            <?php /*if (in_array('bidders', $user->roles)) { */?>
                            <div class="button-bid"> <button id="text_filed">Bid</button></div>
                            <?/*php } */?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="gallery-right">
                <ul id="append_message">
                <?php for($i=0;$i<count($bidderResArr);$i++) { ?>
                    <li ><div class='<?php if($bidderResArr[$i]->msg_class !='') echo $bidderResArr[$i]->msg_class; else echo "color1 list1";?>'>
                        <?php
                            if($bidderResArr[$i]->bid_status==2){
                                echo "Lot ".$bidderResArr[$i]->lot_id ." passed";
                            }else{
                                if($bidderResArr[$i]->msg_class !='')
                                    echo $bidderResArr[$i]->bid_amt;
                                else
                                    echo "Auto accepted bid $".$bidderResArr[$i]->bid_amt;
                            }
                        ?>
                        </div></li>
                <?php } ?>
                <!-- <li><div class='color1 list1'>bbbbb</div></li>
                <li><div class='color1 list1'>ccccc</div></li> -->
                </ul>
            </div>
        </div>
    </div>