<?php 
$path = drupal_get_path('module', 'modal_forms'); 
drupal_add_js($path . '/js/modal_forms_login.js', array('weight' => -20)); 
global $user; 
$end_arr = end($bidderResArr); 
if ($end_arr->bid_amt == "Pause") {  ?>  
<script> 
jQuery(document).ready(function() { 
    jQuery('#my-popup').show(); 
    jQuery('.black_overlay').show(); 
}); 
</script>  
<?php } ?> 
<?php if ($end_arr->uid == $user->uid) { ?> 
<script> 
jQuery(document).ready(function() { 
    jQuery('.button-bid').css('display', 'none'); 
    jQuery('.higbid').css('display', 'block'); 
}); 
</script>  
<?php } ?> 
<input type="hidden" id="userid" value="<?php echo $user->uid; ?>"/> 
<div class="black_overlay"></div> 
<div id="my-popup" class="popup1" style="display:none;" > 
  <div class="popup-detail"> 
  <input type="hidden" id="pause" > 
  <div style="position: relative;" > 
    <h2>Auction has Paused by Seller</h2>  
    <br><br>Please Wait...   
  </div> 
</div> 
</div>

<div id="end-auction" class="popup1" style="display:none;" > 
    <div class="popup-detail"> 
    <div style="position: relative;" >
         
        <h2>The Auction has ended</h2> 
        <br/><br/> 
        <p ><a onclick="window.parent.close();">Click here</a> to close this window</p> 
    </div>
    </div>
</div> 
<div id="close-auction" class="popup1" style="display:none;" > 
        <div class="popup-detail"> 
    <div style="position: relative;" >
         
        <h2>The Auction has closed by seller</h2> 
        <br/><br/> 
        <p ><a onclick="window.parent.close();">Click here</a> to close this window</p> 
    </div></div> 
</div> 
<div id="sold-lot" style="display:none;" class="popup1" >
        <div class="popup-detail"> 
    <div style="position: relative;" > 
        <h2>The lot has been sold / Unsold / Pass</h2> 
        <br/>Please wait for next lot..<br/> 
    </div> 
    </div>
</div>
  
<script> 
function googleTranslateElementInit() { 
    new google.translate.TranslateElement({ 
        pageLanguage: 'en', 
        multilanguagePage: true 
    }, 'google_translate_element1'); 
    if (typeof (document.querySelector) == 'function') { 
        document.querySelector('.goog-logo-link').setAttribute('style', 'display: none'); 
        document.querySelector('.goog-te-gadget').setAttribute('style', 'font-size: 0'); 
    } 
    // If you have jQuery - works cross-browser - uncomment this 
    jQuery('.goog-logo-link').css('display', 'none'); 
    jQuery('.goog-te-gadget').css('font-size', '0'); 
} 
</script> 

<span id="replace_content">  
    <input type="hidden" id="cc_counter" value="0">
    <input type="hidden" id="cc_counterseller" value="0">
    <input type="hidden" id="bid_counterseller" value="0"> 
<?php 
global $base_url, $user; 
$node_dt = node_load($bidder_data[0]->field_choose_auction_nid); 
$cr_tid = getTermName($node_dt->field_currency['und'][0]['tid']); 
if ($cr_tid == 'CHF') { 
    $cr = $cr_tid; 
} else { 
    $cr = '$'; 
} 
$aucnid = $node_dt->nid; 
$node_dc = node_load($bidder_data[0]->entity_id); 
$auctionsCount = $totalLot; 
$lot_value = $node_dc->field_lot_no['und'][0]['value']; 
//$file = file_load($node_dc->uc_product_image['und'][0]['fid']); 
//$image = file_create_url($file->uri); 

$variables=array( 
    'style_name'=>'bidderconsole500x385', 
    'path'=>$node_dc->uc_product_image['und'][0]['uri'], 
    'height'=>'', 
    'width'=>'',
    ); 
$image = theme_image_style($variables); 


$alias = drupal_get_path_alias('node/' . $node_dc->nid); 
$auctitle1 = $node_dc->title; 
$nodename = $node_dt->name; 
$auctitle = l($node_dc->title, $base_url . '/' . $alias, array('attributes' => array('target' => array('_blank')))); 
$aucnidd = $node_dc->field_lot_no['und'][0]['value']; 
$aucdesc = $node_dc->body['und'][0]['value']; 
$high = $node_dc->field_company['und'][0]['value']; 
$low = $node_dc->field_low_estimate['und'][0]['value']; 
$start = $node_dc->field_timeout['und'][0]['value']; 
foreach ($totalLot_arr as $key => $val) {  
    $dem_arr[$key] = $totalLot_arr[$key]->entity_id;  
    if ($bidder_data[0]->entity_id == $totalLot_arr[$key]->entity_id) { 
        $xtra_dem_arr['len_uncount'] = count($dem_arr); 
        $xtra_dem_arr['len'] = $auctionsCount - count($dem_arr); 
        $xtra_dem_arr['currentid'] = $totalLot_arr[$key]->entity_id; 
    } 
}  
?> 

<script type="text/javascript"> 
document.getElementsByTagName("body")[0].oncontextmenu = function(e) { 
    e.preventDefault(); 
} 
var base_url = Drupal.settings.basePath; 
var total_rightLi = <?php echo count($bidderResArr) ?>; 
var posArrlength = <?php echo $posArrLenghth ?>; 
var bidrageval = <?php echo $bidrageval ?>; 
var posArr = <?php echo $posArr ?>; 
var bidder_status = "<?php echo $bidder_status ?>"; 
$(document).ready(function() { 
    if (parseInt(total_rightLi) >= 12) { 
        console.log(" total_rightLi >>> " + total_rightLi); 
        $('#append_message').children('li:lt(<?php echo count($bidderResArr) - 11 ?>)').remove(); 
        $('#append_message li').eq(0).remove(); 
    } 
    // $('#append_message li').eq(0).remove(); 
    if ($('.slider-cont div').length >= 13) { 
        var len = 13; 
        $('.slider-cont').find("div:gt(" + len + ")").remove(); 
    } 
}); 
/*function for changing the currency amount on select from dropdown currency 
*@author   Rajat 
*@To       -Currency format to changes 
*@From     -Currency format from changes 
*@Amount   -Currency amount to be changed 
*/ 
function currencyChange(To, From, Amount) { 
   $('#curr').html("");     
    $('.bid-list').html('').show(); 
    $('.conv-content').show();
   
    //alert(fx.convert(75, {from: "INR", to: "USD"})); 
    var final_val = fx.convert(Amount, {from: From,to: To}); 
    var final_amt = accounting.formatMoney(final_val, To, 2, ",", "."); 
    console.log(final_amt); 
    var lang_data = []; 
    lang_data = final_amt; 
    var lang_darr = []; 
    var lang_actua_fileds = 12 - lang_data.length; 
    if (lang_actua_fileds > 0) { 
        for (var k = 0; k < lang_actua_fileds; k++) { 
            //lang_darr.push("<div class='bid2'><span></span></div>"); 
        } 
    } 
    for (var l = 0; l < lang_data.length; l++) { 
        lang_darr.push("" + lang_data[l] + ""); 
    }
    //alert(lang_darr) ;
   
    $.each(lang_darr, function(i, val) { 

        $('#curr').append(lang_darr[i]); 
    }); 
   var ss=$('#curr').html();
   var text = ss.replace(To, '');
   $('.conv-value').html(To+"<span>"+text+"</span>");

} 
</script> 
<div style="display:none" id="curr"></div>
<!-- oncontextmenu="return false;"--> 
<div id="result"></div>  
<div id="main-container">
       <div class="main-consoler">
<!-- <div class="wrapper-fox"> 
    <div class="gallery-page"> -->
       <div class="top-consoler">
        <div class="console-left">
            <div class="logo-console">
                <a href="#"> 
                    <img src="<?php echo $base_url.'/'.path_to_theme()?>/images/console-logo.png" alt="" /> 
                </a>
                </div> 
                <div class="auction-console"> 
                    <h4><?php echo $auctitle1 //$node_dt->title;?></h4> 
                    <p><?php echo $nodename //$node_dt->name; ?></p> 
                </div> 
            </div>
                <div class="loader console-right"> 
                    <?php  
                    $aucnid = $bidder_data[0]->field_choose_auction_nid; 
                    $round_no = findAuctionRound($aucnid); 
                    $len = $totalitems - $xtra_dem_arr['len']; ?> 
                    <span><?php if ($round_no > 1) echo '100'; 
                    else echo round(($len / $totalitems) * 100); ?>% &nbsp;  <?php if ($round_no > 1) echo '0'; 
                    else echo $xtra_dem_arr['len']; ?> 0f <?php echo $totalitems; ?> remaining</span><br> 
                    <script> 
                    var diagram = "<?php if ($round_no > 1) echo '100'; 
                    else echo round(($len / $totalitems) * 100); ?>"; 
                    $(document).ready(function() {
                        
                        $('#myid').attr('style', "width:" + diagram + '% !important'); 
                    }) 
                </script> 
                <!--<div class="containerprogess"> -->
                    <div class="progress"> 
                        <div id="myid" class="barfox"></div> 
                    <!-- </div> -->
                </div> 
            </div> 
        </div> 
        <!--Top part end here-->
     <div class="middle-consoler">
        <div class="mid-console-left">             
          <div class="lot-title">
            <a href="#" class="lot-black">Lot: <?php echo $aucnidd; ?></a>  
                <p><?php echo $auctitle; ?> </p> 
                <a href="#" class="desc-icon indiacate-icon"><img src="<?php echo $base_url.'/'.path_to_theme() ?>/images/indicate-icon.png"  alt="" />  
                </a> 
		 </div> 
        <div class=" lot-details banner-cont">
            <div class="slider-cont lot-left">
                <?php 
                foreach ($bidder_data as $single_lot) { 
                    if ($single_lot->entity_id == $bidder_data[0]->entity_id) 
                        continue; 
                    $lid = $single_lot->entity_id; 
                    $lot_dt = node_load($lid); 
                    //$img_url = file_create_url($lot_dt->uc_product_image['und'][0]['uri']); 
                    $img_title = $lot_dt->title; 

                      $variables=array(  
                            'style_name'=>'84x54', 
                            'path'=>$lot_dt->uc_product_image['und'][0]['uri'],
                            'height'=>'', 
                            'width'=>'', 
                            );  
                      $picname = theme_image_style($variables); 
                      $biddervariables=array( 
                        'style_name'=>'bidderconsole500x385', 
                        'path'=>$lot_dt->uc_product_image['und'][0]['uri'],  
                        'height'=>'',  
                        'width'=>'',  
                        );  
                      $BidderMoverImg = theme_image_style($biddervariables); 
                      echo '<div class="slider1 lot1"> 
                    <span style="display:none;">' . $img_title . '</span> 
                    <a href="#" class="arrow-curve"></a> 
                    <a href="#">'.$picname.'</a> 
                    <a class="hidden-img" href="#">'.$BidderMoverImg.'</a> 
					
                    </div>'; 
                } 
                ?> 
            </div> 
            
            <div class="banner-img lot-right">  
                <img src="<?php //echo $image ?>" id="mainimg" alt="" style="display:none;max-height: 89%;" />  
             <div class="banner-slider"  style="display:none;">  
                        <img id="middle_banner" src="<?php //echo $base_url . '/' . path_to_theme() ?>/images/banner1.jpg"  alt=""/> 
                        <p id="imgTitle"></p> 
                    </div>
                   
                     <div class="banner-bg" > 
                      <?php echo $image ; ?>
                        <!--img src="<?php //echo $image ?>" id="mainimg" alt=""  /--> 

                    </div>
                    </div> 
                 
                      <div class="banner-pop" id="popup-div">
                            <table width="100%" cellpadding="2" cellspacing="0">
                                <tr>
                                    <th width="75%" align="left"> Description</th>
                                    <th width="25%" align="left">Estimate</th>
                                </tr>
                                <tr>
                                    <td><?php echo $aucdesc; ?></td>
                                    <td><span><img src="<?php echo $base_url . '/' . path_to_theme() ?>/images/arrow-bot.png"  alt="" /></span><?php echo $high; ?><br/>
                                        <span><img src="<?php echo $base_url . '/' . path_to_theme() ?>/images/arrow-toop.png"  alt="" /></span><?php echo $low; ?>
                                    </td>
                                </tr>
                            </table>
                            <a href="#" class="close-icon"><img src="<?php echo $base_url . '/' . path_to_theme() ?>/images/close-icon.png"  alt="" /></a>
                        </div> 
                </div> 
               
            
              <div class="dollar-value bid-top">
                 <ul> 
                           
                            <li></li> 
                            <li></li> 
                            <li></li>  
                            <li class="last"></li> 
                        </ul>
              		  
                    <!-- <div class="dollar-left">
                        <a href="#" class="current-btn">Current Ask</a>
                    </div>-
                    <div class="dollar-right bid-top"> 
                        <ul> 

                            <li></li> 
                            <li></li> 
                            <li></li>  
                            <li class="last"></li> 
                        </ul>
                    </div>-->
                </div> 
            <div class="bid-cont"> 
         
                
           
<div class="bid-right"> 
  <input type="hidden" id="current_amount" value="0"/> 
  <input type="hidden" id="current_amount1" value="<?php echo $currentbid ?>"/> 
  <input type="hidden" id="currency_auction" value="<?php echo $cr; ?>" /> 
  <input type="hidden" id="total_bid" value="<?php echo $bidLAtAmount ?>"/> 
  <input type="hidden" id="auction_lot_id" value="<?php echo $bidder_data[0]->entity_id; ?>"/> 
  <input type="hidden" id="auction_id" value="<?php echo $aucnid; ?>"/> 
  <input type="hidden" id="auction_lot_value" value="<?php echo $lot_value; ?>"/> 
  <input type="hidden" id="total_bid_with_curr" value="<?php echo $cr . $bidLAtAmount ?>"/> 
  <input type="hidden" id="mybid" /> 
  <span id="converted_money1" style="display:none;"></span> 
</div> 
<div class="currency-details"> 
  <?php   
  $currencies = array(  
  "USD" => "United States Dollars - USD",
  "EUR" => "Euro - EUR",
  "GBP" => "United Kingdom Pounds - GBP",
  "JPY" => "Japan Yen - JPY",
  "CNY" => "China Yuan Renminbi - CNY",
  "CNY" => "RMB (China Yuan Renminbi) - CNY",
  "RUB" => "Russia Rubles - RUB",
  "CAD" => "Canada Dollars - CAD",
  "AUD" => "Australia Dollars - AUD",
  "ARS" => "Argentina Pesos - ARS",
  "BHD" => "Bahrain Dinars - BHD",
  "BRL" => "Brazil Reais - BRL",
  "BGN" => "Bulgaria Leva - BGN",
  "CHF" => "Switzerland Francs - CHF",
  "ZAR" => "South Africa Rand - ZAR",
  "DZD" => "Algeria Dinars - DZD",
  "NZD" => "New Zealand Dollars - NZD",
  "INR" => "India Rupees - INR",
  "CLP" => "Chile Pesos - CLP",
  "COP" => "Colombia Pesos - COP",
  "CRC" => "Costa Rica Colones - CRC", 
  "HRK" => "Croatia Kuna - HRK",
  "CZK" => "Czech Republic Koruny - CZK",
  "DKK" => "Denmark Kroner - DKK",
  "DOP" => "Dominican Republic Pesos - DOP",
  "EGP" => "Egypt Pounds - EGP",
  "EEK" => "Estonia Krooni - EEK",
  "FJD" => "Fiji Dollars - FJD",
  "HKD" => "Hong Kong Dollars - HKD",
  "HUF" => "Hungary Forint - HUF",
  "ISK" => "Iceland Kronur - ISK",
  "INR" => "India Rupees - INR",
  "IDR" => "Indonesia Rupiahs - IDR",
  "ILS" => "Israel New Shekels - ILS",
  "IQD" => "Iraqi Dinar - IQD",
  "JMD" => "Jamaica Dollars - JMD",
  "JOD" => "Jordan Dinars - JOD",
  "KES" => "Kenya Shillings - KES",
  "KRW" => "Korea (South) Won - KRW",
  "KWD" => "Kuwait Dinars - KWD",
  "LBP" => "Lebanon Pounds - LBP",
  "MYR" => "Malaysia Ringgits - MYR",
  "MUR" => "Mauritius Rupees - MUR",
  "MXN" => "Mexico Pesos - MXN",
  "MAD" => "Morocco Dirhams - MAD",
  "NZD" => "New Zealand Dollars - NZD",
  "NOK" => "Norway Kroner - NOK",
  "OMR" => "Oman Rials - OMR",
  "PKR" => "Pakistan Rupees - PKR",
  "PEN" => "Peru Nuevos Soles - PEN",
  "PHP" => "Philippines Pesos - PHP",
  "PLN" => "Poland Zlotych - PLN",
  "QAR" => "Qatar Riyals - QAR",
  "RON" => "Romania New Lei - RON",
  "RUB" => "Russia Rubles - RUB",
  "SAR" => "Saudi Arabia Riyals - SAR",
  "SGD" => "Singapore Dollars - SGD",
  "SKK" => "Slovakia Koruny - SKK",
  "ZAR" => "South Africa Rand - ZAR",
  "KRW" => "South Korea Won - KRW",
  "LKR" => "Sri Lanka Rupees - LKR",
  "SEK" => "Sweden Kronor - SEK",
  "CHF" => "Switzerland Francs - CHF",
  "TWD" => "Taiwan New Dollars - TWD",
  "THB" => "Thailand Baht - THB",
  "TTD" => "Trinidad and Tobago Dollars - TTD",
  "TND" => "Tunisia Dinars - TND",
  "TRY" => "Turkey Lira - TRY",
  "AED" => "United Arab Emirates Dirhams - AED",
  "VEB" => "Venezuela Bolivares - VEB",
  "VND" => "Vietnam Dong - VND",
  "ZMK" => "Zambia Kwacha - ZMK"  
  );  
  ?>  
  <div class="clear"></div> 
<?php 
if ($cr == '$') { 
    $g_crnc = 'USD'; 
} else { 
    $g_crnc = 'CHF'; 
} 
?> 

<select class="currency_list"  onchange="currencyChange($(this).val(), '<?php echo $g_crnc; ?>', $('#total_bid').val())"> 

<?php  
foreach ($currencies as $k => $v) {  
    echo "<option value=\"$k\">$v</option>"; 
    } ?> 
</select> 
 <div id="google_translate_element1"></div> 
                    <!--<select>
                        <option>SELECT LANGUAGE</option>
                        <option>LANGUAGE1</option>
                        <option>LANGUAGE2</option>
                        <option>LANGUAGE3</option>
                    </select> -->
      
      <div class="conv-content" style="display:none;"> 
                        <div class="conv-value">
                            <span></span>
                        </div> 
                      </div>
                </div>

</div> 

</div> 

<div class="mid-console-right"> 
    <ul id="append_message"> 
        <?php for ($i = 0; $i < count($bidderResArr); $i++) { ?> 
        <? if(strpos($bidderResArr[$i]->msg_class,'phone') == false) { $class=$bidderResArr[$i]->msg_class; } else { $class= str_replace('phone', '', $bidderResArr[$i]->msg_class); } ?> 
        <?php if (strpos($class, 'floor') != false) { 
            $class = str_replace('floor', '', $bidderResArr[$i]->msg_class); 
        } ?> 
        <li><div class='<?php if ($bidderResArr[$i]->msg_class != '') echo $class; 
        else echo "color7 list1"; ?>'> 
        <?php 
        if ($bidderResArr[$i]->bid_status == 3) { 
            echo "Lot " . $bidderResArr[$i]->lot_no . " passed"; 
        } else { 
            if ($bidderResArr[$i]->msg_class == 'reset') { 
                echo "Lot " . $bidderResArr[$i]->lot_no . " ask " . $cr . intval($bidderResArr[$i]->bid_amt); 
            } elseif ($bidderResArr[$i]->msg_class == 'systembid') { 
                echo "Auto accepted bid " . $cr . $bidderResArr[$i]->bid_amt; 
            } elseif ($bidderResArr[$i]->msg_class == 'retract') { 
                echo "Competing bid " . $cr . $bidderResArr[$i]->bid_amt; 
            } elseif ($bidderResArr[$i]->msg_class == 'color5 list1') { 
                echo "Lot " . $bidderResArr[$i]->lot_no . " sold for " . $cr . $bidderResArr[$i]->bid_amt . " to paimai"; 
            } elseif ($bidderResArr[$i]->msg_class == 'color5 list1 phone' || $bidderResArr[$i]->msg_class == 'color5 list1 floor') { 
                echo "Lot " . $bidderResArr[$i]->lot_no . " sold for " . $cr . $bidderResArr[$i]->bid_amt . " to competing bid"; 
            } 
            elseif ($bidderResArr[$i]->msg_class == 'color5 list1 ') { 
                echo "Lot " . $bidderResArr[$i]->lot_no . " sold for " . $cr . $bidderResArr[$i]->bid_amt . " to paimai"; 
            } 
            elseif ($bidderResArr[$i]->msg_class == 'color4 list1 unsold') { 
                echo "Lot " . $bidderResArr[$i]->lot_no . " unsold"; 
            } 
            elseif ($bidderResArr[$i]->msg_class == 'phone' || $bidderResArr[$i]->msg_class == 'floor') { 
                echo "Competing bid " . $cr . $bidderResArr[$i]->bid_amt; 
            } 
            elseif ($bidderResArr[$i]->msg_class != '') { 
                echo $bidderResArr[$i]->bid_amt; 
            } else { 
                echo "Auto accepted bid " . $cr . $bidderResArr[$i]->bid_amt; 
            } 
        } 
        ?> 
    </div></li> 
    <?php } ?> 
</ul> 



 <div class="sign-register"> 
        <?php 
        $destination = drupal_get_destination(); 
        if ($user->uid == 0) { 
            echo $link = l('Sign in to Register for this auction', 'user/login', array('attributes' => array('class' => array(' long_button ')), 'query' => array('destination' => $destination['destination']))); 
        } 
        elseif (isset($bidder_id)) { 
          $test = 350 ;
            echo '<div class="button-bid" > <button id="text_filed">Bid '. $cr. $bidLAtAmount .'</button></div>'; 
            echo "<span class='higbid' style='display:none;'>You placed highest bid</span>"; 
        } else { 
            echo $link = l('Register For This Auction', $base_url . '/register/auction/' . $aucnid . '/req', array('attributes' => array('class' => array(' long_button ')), 'query' => array('destination' => $destination['destination']))); 
        } ?> 
    </div> 


 </div>  
 </div>
   

 <div class="bottom-consoler">
            <div class="copy-console">Copyright &copy; 2013 Paimai-liveAuctioneers. All Right Reserved</div>
        </div>
</div>

</div> 
<span style="padding-left: 150px;" id="bidfinish_msg"></span> 
<div class="clear"></div> 
<!-- </div> -->
<div class="clear"></div> 
</span>