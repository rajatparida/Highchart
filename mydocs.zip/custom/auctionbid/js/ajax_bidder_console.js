jQuery(document).ready(function(){
    $('div').find('.slider1').removeClass('arrow1');
    var amount = 1;
    fx.base = "USD";
    fx.settings = {
        from : "USD"
    };
    /*$('#mainimg').animate({
        height: "toggle",
        width: "toggle"
    }, 200);
    */
   $('#mainimg').show();
    $('.bid-list').hide();
    /*on mouse hover image pop up -start*/
    $(".slider1 img").mouseenter(function () {// show pohelp
        $(".banner-slider").show();
        $(this).parents('div:eq(0)').attr('id','currentimg');
        $('#imgTitle').html($('#currentimg span').text());
        $('#currentimg').addClass('arrow1');
        var images_var=$(this).attr('src');
        $('#middle_banner').fadeIn(300).attr('src',images_var);
    });
    $(".slider1 img").mouseleave(function() {
        $(".slider1").attr('id','');
        $('.banner-slider').hide();
        $(".slider1").removeClass('arrow1');
        $('#middle_banner').fadeIn(300).attr('src','<?php echo $base_url.'/'.path_to_theme()?>/images/banner.png');
        $('#imgTitle').html('');
    });
    /*on mouse hover image pop up -end*/
    /*currency json generates & plugin loads -start*/
    $.getJSON(
        'http://openexchangerates.org/api/latest.json?app_id=6f47e005633741d485d28f5485c2c94d',
        function(data) {
            // Check money.js has finished loading:
            if ( typeof fx !== "undefined" && fx.rates ) {
                fx.rates = data.rates;
                fx.base = data.base;
            } else {
                // If not, apply to fxSetup global:
                var fxSetup = {
                    rates : data.rates,
                    base : data.base
                }
            }
        });
    /*currency json generates & plugin loads -end*/
    /*setinterval for checking whether the actual currency has changed or not -start*/
    setInterval(function(){
        var data=[];
        $('.bid-top').html('').show();
        data=$('#total_bid_with_curr').val();
        var darr=[];
        var actua_fileds=10-data.length;
        if(actua_fileds >0){
            for(var j=0;j<actua_fileds;j++){
                darr.push("<div class='bid1'><span></span></div>");
            }
        }
        for (var i = 0; i < data.length; i++) {
            darr.push("<div class='bid1'><span>"+data[i]+"</span></div>");
        }
        $.each( darr, function( i, val ) {
            $('.bid-top').append(darr[i]);
        });
    },500);
    /*setinterval for checking whether the actual currency has changed or not -end*/
    /*action performed when clicks on bid button -start*/

    /*display data when note icon clicked -start*/
    $(".desc-icon").click(function(){
        $("#popup-div").slideToggle( "slow", function() {
            });
    });
    $(".close-icon").click(function(){
        $("#popup-div").slideUp();
    });
    base_url = Drupal.settings.basePath;
       jQuery('.button-bid').click(function(){
        if(bidder_status == 'notApproved'){
            $('#bidfinish_msg').html('Your request is already pending for approval');
            setTimeout(function(){
                $('#bidfinish_msg').fadeOut();
            },3000);
            return false;
        }
        $('#text_filed').attr('disabled','disabled');
        var lot_value = $("#total_bid").val();
        var lot_id = $("#auction_lot_id").val();
        var act_id = $("#auction_id").val();
        var lot_no = $("#auction_lot_value").val();
        var newar=[];
        var xtrapArr=[];
        var newxtra=[];
        var currentIncmt;
        for(var i=0;i<posArrlength;i++){
            if ((posArr[i] <= lot_value && lot_value < posArr[i + 1]) || i == 9) {
                xtrapArr[i] = posArr[i];
                newxtra=xtrapArr.indexOf(xtrapArr[i])
            }
        }
        currentIncmt = parseInt(bidrageval[newxtra]); //how much should increase increment
        socket.emit( 'currentbid', {
            amountonHisthreeLi: lot_value,
            currentIncval:parseInt(bidrageval[newxtra]),
            lotId:lot_id
        });
        $.get(base_url+"store-lots", {
            lot_value:lot_value,
            lot_id:lot_id,
            iCurrentIncBid:currentIncmt,
            act_id:act_id,
            lot_no:lot_no
        },function(req, res){
            $('#text_filed').removeAttr('disabled');
            if(res=='success'){
               if($.parseJSON(req).msg!='No'){
                    $('#bidfinish_msg').html($.parseJSON(req).msg);
                }
            }else{
                alert('Please check your network connection.');return false;
            }
        });
    });
    socket.on( 'message', function( data ) {
        console.log(data.name);
        if($("#auction_lot_id").val()==data.name){
            console.log(" yes am in >> "+data.name);
            if($('#append_message li').length >8)
                $('#append_message li').eq(0).remove();
            $("#append_message").append("<li><div class='"+data.appliedclass+"'>"+data.message+"</div></li>")
        }
    });
    socket.on( 'currentbid', function( data ) {
        if($("#auction_lot_id").val()==data.lotId){
            console.log(" yes am incremented of amount >> "+data.currentIncval);
            if($('#append_message li').length >8)
                $('#append_message li').eq(0).remove();
            $("#append_message").append("<li><div class='color1 list1'>Auto accepted bid $"+data.amountonHisthreeLi+"</div></li>");
            var valuefinal=parseInt(data.amountonHisthreeLi)+parseInt(data.currentIncval);
            $('#total_bid').val(valuefinal);
            $('#total_bid_with_curr').val($('#total_bid_with_curr').val().split(/(\d)/)[0]+valuefinal);
            if($('.currency_list').val()!='USD')
                currencyChange($('.currency_list').val(),'USD',$('#total_bid').val())
        }
    });
   socket.on('sold',function(data){
            if($("#auction_lot_id").val() == data.lot_id){
                if($('#append_message li').length >8)
                $('#append_message li').eq(0).remove();
                $("#append_message").append('<li><div class="'+data.appliedclass+'">Lot '+data.lot_id+' sold for $'+data.soldamt+' to LiveAuctioneers</div></li>');
            }
   });
   socket.on('pass',function(data){
            if($("#auction_lot_id").val() == data.lot_id){
                if($('#append_message li').length >8)
                $('#append_message li').eq(0).remove();
                $("#append_message").append('<li><div class="'+data.appliedclass+'">Lot '+data.lot_id+' passed</div></li>');
            }
   });
   socket.on('nextlot',function(data){
       console.log("current_seller >>"+data.lot_id);
       console.log("current_bidder >>"+$("#auction_lot_id").val());
       $.get(base_url+"next-lot-bidder", {
            lot_id:$("#auction_lot_id").val(),
            act_id:$("#auction_id").val()
        },function(req, res){
            $('#replace_content').html(req);
            $("#auction_id").val(data.act_id);
        });
   });
/*    socket.on( 'currencyupdate', function( data ) {
            if($("#auction_lot_id").val()==data.lotId){

            }
    });
 */
});
function updateRight(callback){
    base_url = Drupal.settings.basePath;
    $.ajax({
        'url':base_url+'send-bidder-request',
        'type':'POST'
    });
    $.ajax({
        'url':base_url+'fetch-bidder-responce',
        'type':'POST',
        data: {
            act_id:$("#auction_id").val()
            } ,
        'success': function(response){
            var datas = $.parseJSON(response);
            console.log(datas.success)
            if(datas.success!='' && datas.success_id!='' && $('#append_message li').last().attr('id')!=datas.success_id){
                console.log("<br> >>"+datas.success)
                if($('#append_message li').length >8)
                    $('#append_message li').eq(0).remove();
                $("#append_message").append("<li id='"+datas.success_id+"'><div class='color1 list1'>"+datas.success+"</div></li>")
            //$('#append_message li').last().toggle("slide");
            }
        }
    });
    console.clear();
}
