/*var http = require('http').createServer(handler);
// Let’s make node/socketio listen on port 3000
var io = require('socket.io').listen(http).set('log level', 1);

function handler(req, res) {
  res.writeHead(200);
  res.end();
}
http.listen(8080);
console.log('Chatserver listening on port 8080');

// Define/initialize our global vars
var notes = []
var isInitNotes = false
var socketCount = 0

io.sockets.on('connection', function(socket){
    // Socket has connected, increase socket count
    socketCount++
    // Let all sockets know how many are connected
    io.sockets.emit('users connected', socketCount)

    socket.on('disconnect', function() {
        // Decrease the socket count on a disconnect, emit
        socketCount--
        io.sockets.emit('users connected', socketCount)
    })

    // Check to see if initial query/notes are set
    if (! isInitNotes) {

    } else {
        // Initial notes already exist, send out
        socket.emit('initial notes', notes)
    }
})
*/
var socket = require( 'socket.io' );
var express = require( 'express' );
var http = require( 'http' );
var hbs = require('hbs');
var app = express();
var server = http.createServer(app);
var io = socket.listen( server );
app.set('view engine', 'html');
app.engine('html', hbs.__express);
app.use(express.json());
app.use(express.urlencoded());
app.use(app.router);

io.sockets.on( 'connection', function( client ) {
    console.log( "New client !" );

    client.on( 'messages', function( data ) {
        console.log( 'Message received ' + data.name + ":" + data.message + ":" +data.appliedclass );
        io.sockets.emit( 'messages', { name: data.name, message: data.message ,appliedclass:data.appliedclass } );
    });
    client.on( 'currentbid', function( data ) {
        console.log( 'Message received :'+ data.amountonHisthreeLi + ":" + data.currentIncval+ ":" +data.lotId);
        io.sockets.emit( 'currentbid', { amountonHisthreeLi: data.amountonHisthreeLi ,currentIncval:data.currentIncval,lotId:data.lotId } );
    });
    client.on( 'sold', function( data ) {
        console.log( 'Message received ' + data.lot_id + ":" + data.soldamt + ":" +data.appliedclass );
        io.sockets.emit( 'sold', { lot_id: data.lot_id, soldamt: data.soldamt ,appliedclass:data.appliedclass } );
    });
    client.on( 'unsold', function( data ) {
        console.log( 'Message received ' + data.lot_id + ":"+data.appliedclass );
        io.sockets.emit( 'unsold', { lot_id: data.lot_id, appliedclass:data.appliedclass } );
    });
    client.on( 'pass', function( data ) {
        console.log( 'Message received ' + data.lot_id + ":" +data.appliedclass );
        io.sockets.emit( 'pass', { lot_id: data.lot_id,appliedclass:data.appliedclass } );
    });
    client.on( 'nextlot', function( data ) {
        console.log( 'Message received ' + data.lot_id + ":" +data.act_id );
        io.sockets.emit( 'nextlot', { lot_id: data.lot_id,act_id:data.act_id } );
    });
    client.on( 'cc_countertobidder', function( data ) {
        io.sockets.emit( 'cc_countertobidder', { cc_counter: data.cc_count } );
    });
    client.on( 'cc_countertoseller', function( data ) {
        io.sockets.emit( 'cc_countertoseller', { cc_counter: data.cc_count } );
    });
    client.on( 'phoneFloor', function( data ) {
        console.log( 'Message received ' + data.lotid + ":" + data.bidamt + ":" +data.appliedclass );
        io.sockets.emit( 'phoneFloor', { lotid: data.lotid, bidamt: data.bidamt ,appliedclass:data.appliedclass } );
    });
    client.on( 'retract', function( data ) {
        console.log( 'Message received ' + data.amountonHisthreeLi + ":" + data.currentIncval+ ":" +data.lotId);
        io.sockets.emit( 'retract', { amountonHisthreeLi: data.amountonHisthreeLi ,currentIncval:data.currentIncval,lotId:data.lotId } );
    });
    client.on( 'reset', function( data ) {
        console.log( 'Message received ' + data.amountonHisthreeLi + ":" + data.currentIncval+ ":" +data.lotId);
        io.sockets.emit( 'reset', { amountonHisthreeLi: data.amountonHisthreeLi ,currentIncval:data.currentIncval,lotId:data.lotId } );
    });
    client.on( 'endauction', function( data ) {
        io.sockets.emit( 'endauction',{endauction:'close',act_id:data.act_id});
    });
    
     client.on( 'reopen', function( data ) {
        io.sockets.emit( 'reopen',{act_id:data.act_id});
    });
     
     client.on( 'systembid', function( data ) {
        io.sockets.emit( 'systembid',{act_id:data.act_id,lotId:data.lotId,lotno:data.lotno,bidamt: data.bidamt,appliedclass:data.appliedclass,userid:data.userid});
    });
      client.on( 'systembidbidder', function( data ) {
        io.sockets.emit( 'systembidbidder',{act_id:data.act_id,lotId:data.lotId,lotno:data.lotno,bidamt: data.bidamt,appliedclass:data.appliedclass,userid:data.userid});
    });
 client.on( 'closeconsole', function( data ) {
        io.sockets.emit( 'closeconsole',{act_id:data.act_id});
    });

//    app.get('/store-lots-seller', function(req, res) {
//        cosnole.log("---------------->"+req);
//        res.send("hi bombbbbbbb");
//   });

    /*app.get("store-lots", function(req, res) {
        console.log(req.body.lot_value)
        console.log(req.body.lot_id);
        console.log(req.body.act_id);
        console.log(req.body.lot_no);
        console.log(res);
        res.contentType('json');
        res.send({ some: JSON.stringify({response:'json'}) });
    });
    */
});

server.listen( 8080 );

//http.createServer(function (req, res) {
//    res.writeHead(200, {'Content-Type': 'text/plain'});
//    res.end('Hello World\n');
//}).listen(8085, "127.0.0.1");
