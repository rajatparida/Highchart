$(window).load(function () { 
    if(sessionVar!='' || parseInt($('#round_no').val()) >1){ 
        return false; 
    } 
    jQuery('#my-popup').show(); 
}); 
window.onbeforeunload = function() { 
    if($('#round_no').val()==1){ 
        socket.emit( 'closeconsole', { 
            act_id:$("#auction_id").val() 
        }); 
        jQuery.ajax({ 
            type: "POST",
            url: base_url+"ajax/unsetsession", 
        }).done(function() { 
            return; 
        }); 
        alert("Bidders will see closed message on their console"); 
    } 
}; 
function mypopup(){
    jQuery('#my-popup').show();
}
function submitform() { 
    var str = $( "form" ).serialize(); 
    // Change auction status to live 
    base_url = Drupal.settings.basePath; 
    jQuery.ajax({ 
        type: "POST", 
        url: base_url+"updateauction", 
        data: {act_id: $("#auction_id").val()} 
    }).done(function() { 
        $( "#systembid" ).trigger( "click" ); 
    }); 
    if($('#close_soon').val()=='' || $('#close_soon').val()=='' ||$('#close_soon').val()==''){ 
        $('.form-text').trigger('blur'); 
        return false; 
    } 
    $("#my-popup").hide(); 
    $.post(Drupal.settings.basePath+'ajax/stresession?'+str,{ 
    },function(req, res){ 
        var data=$.parseJSON(req); 
        $('#colsesoon_mainbtn').attr('alt',data.closesoon); 
        $('#farewarning_mainbtn').attr('alt',data.fairwarning); 
        $('#lastacll_mainbtn').attr('alt',data.lastcall); 
        if($('#askamt').val()!='' && cc_xtra_count==0 && sessionVar!=''){ 
            cc_xtra_count=1; 
            $.ajax({ 
                type: "POST", 
                dataType: 'json', 
                data: { 
                    lot_value: "Lot "+$("#auction_lot_value").val()+" opened ask "+$("#currency_auction").val()+" "+$('#askamt').val(), 
                    lot_id: $("#auction_lot_id").val(), 
                    act_id: $("#auction_id").val(), 
                    lot_no: $("#auction_lot_value").val(), 
                    msg_class:'color8 list1' 
                }, 
                url: base_url+"store-lots-seller", 
                success: function(data) { 
                }, 
                error: function(xhr, textStatus, errorThrown){ 
                    alert('server request failed .Please check your connection!'); 
                    return false; 
                } 
            }); 
        } 
        if(data.autoaccept=='auto'){ 
            $('#internet').parent().addClass('disableBtn'); 
        }else{ 
            $('#internet').parent().removeClass('disableBtn'); 
        } 
    } 
    ); 
return false; 
}