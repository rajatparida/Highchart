function googleTranslateElementInit() { 
    new google.translate.TranslateElement({ 
        pageLanguage: 'en', 
        multilanguagePage: true 
    }, 'google_translate_element1');
        if(typeof(document.querySelector) == 'function') {
        document.querySelector('.goog-logo-link').setAttribute('style', 'display: none');
        document.querySelector('.goog-te-gadget').setAttribute('style', 'font-size: 0');
        } 
        // If you have jQuery - works cross-browser - uncomment this 
        jQuery('.goog-logo-link').css('display', 'none'); 
        jQuery('.goog-te-gadget').css('font-size', '0'); 
    } 
    jQuery(document).ready(function(){ 
        document.onkeydown = function(){ 
            switch (event.keyCode){ 
            case 116 : //F5 button 
            event.returnValue = false;
            event.keyCode = 0; 
            alert('This operation is not allowed'); 
            return false; 
            case 82 : //R button 
            if (event.ctrlKey){ 
                event.returnValue = false;
                event.keyCode = 0;
                return false; 
            } 
        } 
    } 
window.onbeforeunload = function(e) { 
    base_url = Drupal.settings.basePath; 
    $.get(base_url+"deletesession", {act_id:$("#auction_id").val(),}) 
}; 
if($(window).width()<795 && $(window).width()>480 ){  
    $("body").find(".wrapper").attr("class","container-popup-win"); 
} 
$( window ).resize(function() { 
    if($(window).width()<795 && $(window).width()>480 ){  
        $("body").find(".wrapper").attr("class","container-popup-win"); 
    } else { 
        $("body").find(".container-popup-win").attr("class","wrapper"); 
    } 
}); 
if(parseInt($('#total_bid').val())==0){ 
    $('#text_filed').hide(); 
} 
var counterDm=0; 
$('div').find('.slider1').removeClass('arrow1'); 
var amount = 1; 
fx.base = "USD"; 
fx.settings = { 
    from : "USD" 
}; 
$('#mainimg').show(); 
$('.bid-list').hide(); 
/*on mouse hover image pop up -start*/ 
$(".slider1 img").mouseenter(function () { // show pohelp 
    $(".banner-slider").show(); 
    $(this).parents('div:eq(0)').attr('id','currentimg'); 
    $('#imgTitle').html($('#currentimg span').text()); 
    $('#currentimg').addClass('arrow1'); 
    var images_var=$(this).attr('src'); 
     value = images_var.replace(base_url+'sites/default/files/styles/84x54', base_url+'sites/default/files/styles/bidderconsole500x385'); 
        if(value ==''){
            //myvalue = 'No Image created yet' ;
            myvalue = images_var; 
        } else { 
            myvalue = value ;
        }
        $('#middle_banner').fadeIn(300).attr('src',myvalue);
    //$('#middle_banner').fadeIn(300).attr('src',images_var); 
}); 
$(".slider1 img").mouseleave(function() { 
    $(".slider1").attr('id',''); 
    $('.banner-slider').hide(); 
    $(".slider1").removeClass('arrow1'); 
    $('#middle_banner').fadeIn(300).attr('src','<?php echo $base_url.'/'.path_to_theme()?>/images/banner.png'); 
    $('#imgTitle').html(''); 
}); 
/*on mouse hover image pop up -end*/ 
/*currency json generates & plugin loads -start*/ 
$.getJSON( 
    'http://openexchangerates.org/api/latest.json?app_id=6f47e005633741d485d28f5485c2c94d', 
    function(data) { 
    // Check money.js has finished loading: 
    if ( typeof fx !== "undefined" && fx.rates ) { 
        fx.rates = data.rates; 
        fx.base = data.base; 
    } else { 
    // If not, apply to fxSetup global: 
    var fxSetup = { 
        rates : data.rates, 
        base : data.base 
        } 
    } 
}); 
/*currency json generates & plugin loads -end*/ 
/*setinterval for checking whether the actual currency has changed or not -start*/ 
setInterval(function(){ 
    var data=[]; 
    $('.bid-top').html('').show(); 
    //data=$('#total_bid_with_curr').val(); 
    var current_val = $('#current_amount1').val();
    if(current_val == ''){
        data=$('#total_bid_with_curr').val(); 
    }else{ 
        data=$('#currency_auction').val()+""+ $('#current_amount1').val();          
    }
    
    var darr=[]; 
    var actua_fileds=10-data.length; 
    if(actua_fileds >0){ 
        for(var j=0;j<actua_fileds;j++){ 
            darr.push("<li class='bid1'><span></span></li>"); 
        } 
    } 
    for (var i = 0; i < data.length; i++) { 
        darr.push("<li class='bid1'><span>"+data[i]+"</span></li>"); 
    } 
    $.each( darr, function( i, val ) { 
        $('.bid-top').append(darr[i]); 
    }); 
},500);
    /*setinterval for checking whether the actual currency has changed or not -end*/
    /*action performed when clicks on bid button -start*/

    /*display data when note icon clicked -start*/

    $(".desc-icon").bind('click',function(){ 
        $("#popup-div").slideDown( "slow", function() { 
        }); 
    }); 
    $(".close-icon").bind('click',function(){ 
        $("#popup-div").slideUp(); 
    }); 
    base_url = Drupal.settings.basePath; 
    $('.button-bid').click(function(){ 
        if(bidder_status == 'notApproved'){ 
            $('#bidfinish_msg').html('Your request sent for approval').show(); 
            setTimeout(function(){ 
                $('#bidfinish_msg').fadeOut(); 
            },3000); 
            return false; 
        } 
        $("#mybid").val($("#total_bid").val());  
        if($("#total_bid").val()=='' || parseInt($("#total_bid").val()) ==0){ 
            $('#text_filed').attr('disabled','disabled'); 
            return false; 
        } 
        var lot_value = $("#total_bid").val();
        var lot_id = $("#auction_lot_id").val();
        var act_id = $("#auction_id").val();
        var lot_no = $("#auction_lot_value").val();
        var newar=[];
        var xtrapArr=[];
        var newxtra=[];
        var currentIncmt; 
        var i; 
        for(i=0;i<posArrlength;i++){ 
            console.log(i); 
            var j=i; 
            if (i == (posArrlength-1)) { 
                var bigVal=parseInt(lot_value)+1; 
            }else{ 
                bigVal= parseInt(posArr[++j]); 
            } 
            if (i==0) { 
                //if(parseInt(lot_value) <= parseInt(posArr[i])) {  
                   if(parseInt(lot_value) < parseInt(posArr[i])) {  
                    newxtra= bidrageval[i]; 
                    break; 
                } 
            } 
            //if (parseInt(posArr[i]) <= parseInt(lot_value) &&  parseInt(lot_value) <= bigVal ) { 
                if (parseInt(posArr[i]) <= parseInt(lot_value) &&  parseInt(lot_value) < bigVal ) { 
                var bid=bidrageval[i+1]; 
                if(bid != undefined) { 
                    newxtra= bid; 
                    break; 
                }else{ 
                    newxtra= bidrageval[i]; 
                    break;	 
                } 
            } 
        } 
        currentIncmt = newxtra;//parseInt(bidrageval[newxtra]); //how much should increase increment 
        $('#cc_counterseller').val("0"); 
        var val_cc=$('#bid_counterseller').val(); 
        if (val_cc==0) { 
            $('#bid_counterseller').val("2"); 
            socket.emit( 'cc_countertoseller', { 
                cc_count: 0 
            }); 
            socket.emit( 'currentbid', { 
                amountonHisthreeLi: lot_value, 
                currentIncval:parseInt(currentIncmt), 
                lotId:lot_id 
            }); 
        } 
        if ($('#current_amount').val() < $('#total_bid').val())  {        
	
       
       $('.button-bid').css('display','none');
       $('.higbid').css('display','block');
      
      
	    
	    }
        $.get(base_url+"store-lots", {
            lot_value:lot_value,
            lot_id:lot_id,
            iCurrentIncBid:currentIncmt,
            act_id:act_id,
            lot_no:lot_no
        },function(req, res){
            $('#text_filed').removeAttr('disabled');
            if(res=='success'){

            }else{
                alert('Please check your network connection.');return false;
            }
        });
    });
         socket.on('endauction',function(data){
	     $('#sold-lot').hide();
         if(data.act_id==$("#auction_id").val() || $("#auction_lot_id").val()=="" ){
	    
             $('#end-auction').show();
	     $('.black_overlay').show();
	    $('.button-bid').find('input, textarea, button, select').attr('disabled','disabled');
	   
           
	   
         }
     });
    socket.on( 'cc_countertobidder',function (data){
            $('#cc_counter').val(data.cc_counter) ;
            console.log("pagi !!" +data.cc_counter);
    });
    socket.on( 'phoneFloor', function( data ) {
        socket.on( 'cc_countertobidder',function (data){
                $('#cc_counter').val(data.cc_counter) ;
                console.log("yeeeey !!" +data.cc_counter); 
            }); 
        var val_cc= $('#cc_counter').val();
        console.log($("#auction_lot_id").val()+"--phonefloor--"+data.lotid);
        if($("#auction_lot_id").val()==data.lotid && (val_cc==1 || val_cc==0)){ 
            $('.button-bid').css('display','block'); 
            $('.higbid').css('display','none'); 
            $('#cc_counter').val('2');
            console.log(" yes am in phonefloor> "+data.lotid);
            if($('#append_message li').length >8)
                $('#append_message li').eq(0).remove();
            $("#append_message").append("<li><div class='"+data.appliedclass+"'>Competing bid "+$("#currency_auction").val()+" "+data.bidamt+" </div></li>")
           // Bid increment
	    var newar=[]; 
        var xtrapArr=[]; 
        var newxtra; 
        var currentIncmt; 
        for(i=0;i<posArrlength;i++){ 
            var j=i; 
            if (i == (posArrlength-1)) { 
                var bigVal=parseInt(data.bidamt)+1; 
            }else{ 
                bigVal= parseInt(posArr[++j]); 
            } 
            if (i==0) { 
                //if(parseInt(data.bidamt) <= parseInt(posArr[i])){ 
                if(parseInt(data.bidamt) < parseInt(posArr[i])){ 
                    newxtra= bidrageval[i]; 
                    break; 
                } 
            } 
            if (parseInt(posArr[i]) <= parseInt(data.bidamt) &&  parseInt(data.bidamt) < bigVal ) { 
                var bid=bidrageval[i+1]; 
                //  alert(bid); 
                // last lot condition 
                if(bid != undefined){ 
                    newxtra= bid; 
                    break; 
                } else { 
                    newxtra= bidrageval[i]; 
                    break; 
                } 
            } 
        } 
        currentIncmt = newxtra; 
        var totalVal=parseInt(data.bidamt)+parseInt(currentIncmt); 
        // var totalVal=parseInt(data.bidamt); 
        $('#total_bid').val(totalVal); 
        $('#text_filed').html('Bid '+''+$('#currency_auction').val()+''+totalVal); 
        $('#total_bid_with_curr').val($('#total_bid_with_curr').val().split(/(\d)/)[0]+data.bidamt); 
        $('#current_amount1').val(data.bidamt); 
    } 
}); 
socket.on( 'messages', function( data ) { 
    socket.on( 'cc_countertobidder',function (data){ 
        $('#cc_counter').val(data.cc_counter) ; 
        console.log("yeeeey !!" +data.cc_counter); 
    }); 
    var str=data.message 
    n=0; 
    if (str=='Pause') { 
        n=1; 
    } 
    if (n>0) { 
    //$('.button-bid').addClass('disableBtn'); 
    $('#sold-lot').hide(); 
    $('#pause').val(1); 
    $('.black_overlay').show(); 
    $('#my-popup').show(); 
    //$('.button-bid').find('input, textarea, button, select').prop("disabled", true); 
}else { 
    $('#pause').val(0); 
    $('.black_overlay').hide(); 
    $('#my-popup').hide(); 
    //$('.button-bid').find('input, textarea, button, select').prop("disabled", false); 
} 
var val_cc= $('#cc_counter').val(); 
console.log($("#auction_lot_id").val()+"----"+data.name); 
if($("#auction_lot_id").val()==data.name && (val_cc==1 || val_cc==0)){ 
//   if($("#auction_lot_id").val()==data.name){ 
    $('#cc_counter').val('2'); 
    console.log(" yes am in >> "+data.name); 
    if($('#append_message li').length >8) 
        $('#append_message li').eq(0).remove(); 
    $("#append_message").append("<li><div class='"+data.appliedclass+"'>"+data.message+"</div></li>") 
} 
}); 
socket.on( 'currentbid', function( data ) {  
    $('#bid_counterseller').val("0"); 
    $('#current_amount1').val(data.amountonHisthreeLi); 
    var val_cc=$('#cc_counterseller').val();
        console.log("val_cc  in bidder !!!"+val_cc);

        socket.emit( 'cc_countertoseller', {
               cc_count: val_cc

        });
    
        if(parseInt($("#auction_lot_id").val()) == parseInt(data.lotId)){
	   
             if($('#current_amount').val() == data.amountonHisthreeLi){
	
              return ;
	     }
	     
	     //alert($('#total_bid').val() +"!="+ $('#mybid').val());
	      if ($('#total_bid').val() != $('#mybid').val()) {
		 $('.button-bid').css('display','block');
		 $('.higbid').css('display','none');
       
	    }
	    else
	    {
		 $('.button-bid').css('display','none');
		 $('.higbid').css('display','block');
		
	    }
	    
            $('#cc_counterseller').val("2");
            console.log(" yes am incremented of amount >> "+data.currentIncval);
            if($('#append_message li').length >8)
                $('#append_message li').eq(0).remove();
            $("#append_message").append("<li><div class='color7 list1'>Auto accepted bid "+$("#currency_auction").val()+" "+data.amountonHisthreeLi+"</div></li>");
            $('#current_amount').val(data.amountonHisthreeLi);
            var valuefinal=parseInt(data.amountonHisthreeLi)+parseInt(data.currentIncval);
            $('#total_bid').val(valuefinal);
            //$('#text_filed').html('Bid '+valuefinal);
            $('#text_filed').html('Bid '+''+$('#currency_auction').val()+''+valuefinal); 
            
            $('#total_bid_with_curr').val($('#total_bid_with_curr').val().split(/(\d)/)[0]+data.amountonHisthreeLi);
            if($('.currency_list').val()!='USD')
                currencyChange($('.currency_list').val(),'USD',$('#total_bid').val())
            if(parseInt($('#total_bid').val())!=0){
                $('#text_filed').show();
            }
        }
    });
   socket.on('sold',function(data){
       console.log("are you coming to sell ???  "+$('#cc_counter').val());
            socket.on( 'cc_countertobidder',function (data){
                    $('#cc_counter').val(data.cc_counter) ;
                    console.log("yeeeeysold !!" +data.cc_counter);
            });
            var val_cc= $('#cc_counter').val();
            if($("#auction_lot_id").val() == data.lot_id && (val_cc==1 || val_cc==0)){
		$('#sold-lot').show();
		 $('.button-bid').css('display','none');
		
                $('#cc_counter').val('2');
                if($('#append_message li').length >8)
                $('#append_message li').eq(0).remove();
		var classstyle=data.appliedclass;
		if (classstyle.indexOf("phone") >= 0)
		{
		var str='Competing bid';
		var classstyle = classstyle.replace("phone", "");
		}
		else
		{
		str='Paimaili';
		}
                $("#append_message").append('<li><div class="'+classstyle+'">Lot '+$("#auction_lot_value").val()+' sold for $'+data.soldamt+' to ' +str+'</div></li>');
            }
   });
   socket.on('unsold',function(data){
            socket.on( 'cc_countertobidder',function (edata){
                    $('#cc_counter').val(edata.cc_counter) ;
                    console.log("yeeeeyunsold !!" +edata.cc_counter);
            });
            var val_cc= $('#cc_counter').val();
            if($("#auction_lot_id").val() == data.lot_id && (val_cc==1 || val_cc==0)){
		$('#sold-lot').show();
		 $('.button-bid').css('display','none');
                $('#cc_counter').val('2');
                if($('#append_message li').length >8)
                $('#append_message li').eq(0).remove();
                $("#append_message").append('<li><div class="'+data.appliedclass+'">Lot '+$("#auction_lot_value").val()+' unsold</div></li>');
            }
   });
   socket.on('pass',function(data){
            socket.on( 'cc_countertobidder',function (data){
                    $('#cc_counter').val(data.cc_counter) ;
                    console.log("yeeeeypass !!" +data.cc_counter);
            });
            var val_cc= $('#cc_counter').val();
            if($("#auction_lot_id").val() == data.lot_id  && (val_cc==1 || val_cc==0)){
		$('#sold-lot').show();
		 $('.button-bid').css('display','none');
                $('#cc_counter').val('2');
                if($('#append_message li').length >8)
                $('#append_message li').eq(0).remove();
                $("#append_message").append('<li><div class="'+data.appliedclass+'">Lot '+$("#auction_lot_value").val()+' passed</div></li>');
            }
   });
   socket.on('nextlot',function(data){
       socket.on( 'cc_countertobidder',function (data){
                    $('#cc_counter').val(data.cc_counter) ;
                    console.log("next lot :| !!" +data.cc_counter);
       });

            var val_cc= $('#cc_counter').val();
        if($("#auction_id").val() == data.act_id  && (val_cc==1)){
	   $('#sold-lot').hide();
	     $('.button-bid').css('display','block');
	    $('.higbid').css('display','none');
             $('#cc_counter').val('2');
            $.get(base_url+"next-lot-bidder", {
                    lot_id:data.lot_id,//$("#auction_lot_id").val(),
                    act_id:$("#auction_id").val()
                },function(req, res){
                    if(res=='success'){
			
                            $('#replace_content').html(req);
			   
                            $.getScript(base_url+"misc/jquery.js");
                            $.getScript(base_url+"sites/all/modules/custom/auctionbid/js/bidder_console.js");
                            $("#auction_id").val(data.act_id);
			    
			     socket.emit( 'cc_countertoseller', {
			    cc_count: 0
			     });
			     socket.emit( 'systembidbidder', {
			     lot_id:$("#auction_lot_id").val(),
			     act_id:$("#auction_id").val()        
            
			    });
                    }else{
                            alert('Please check your network connection.');
                            return false;
                    }
 googleTranslateElementInit();
         });

        }
    });
   socket.on( 'reopen',function (data){
    $('#sold-lot').show();
    
    
	     window.location.href=base_url+"bidder-console/"+data.act_id;
	     
	      
	});
   // System Bid socket
   socket.on('systembid',function(data){
         socket.on( 'cc_countertobidder',function (edata){
                    $('#cc_counter').val(edata.cc_count) ;
                    
       });
	  var val_cc= $('#cc_counter').val();
	 /*if(data.act_id==$("#auction_id").val() && val_cc==0){
            $('#cc_counter').val("2");
         $("#append_message").append("<li><div class='color6 list1'>System bid  $"+ data.bidamt+"</div></li>");
            
         }*/
	 
	  if(data.act_id==$("#auction_id").val() && (val_cc==1 || val_cc==0)){
	   
	    if (parseInt(data.userid)==parseInt($("#userid").val())) {
		$('#sold-lot').hide();
		 $('.button-bid').css('display','none');
	     $('.higbid').css('display','block');
	    }
	    else
	    {
	       $('#sold-lot').hide();
	     $('.button-bid').css('display','block');
	    $('.higbid').css('display','none');
	    }
            $('#cc_counter').val('2');
            
            if($('#append_message li').length >8)
                $('#append_message li').eq(0).remove();
           $("#append_message").append("<li><div class='color7 list1'>Auto accepted bid "+$("#currency_auction").val()+" "+data.bidamt+"</div></li>");
           // Bid increment
	    var newar=[];
            var xtrapArr=[];
            var newxtra;
            var currentIncmt;
	
	    for(i=0;i<posArrlength;i++){
	
	
	  
	     var j=i;
	     
	     if (i == (posArrlength-1)) {
		var bigVal=parseInt(data.bidamt)+1;
		
	     }else{
		bigVal= parseInt(posArr[++j]);
		
	     }
	    
	    if (i==0) {
		
		if(parseInt(data.bidamt) <= parseInt(posArr[i]))
		{
		newxtra= bidrageval[i];
		break;
		}
	    }
	   
	//alert(posArr[i]+ "<=" + lot_value +"&&"+ lot_value +"<"+bigVal );    
           if (parseInt(posArr[i]) <= parseInt(data.bidamt) &&  parseInt(data.bidamt) < bigVal ) {
	     var bid=bidrageval[i+1];
	  //  alert(bid);
	  // last lot condition
	    if(bid != undefined)
	    {
		
		newxtra= bid;
		break;
	    }
		else
		{
		newxtra= bidrageval[i];
		break;
		}
	    
	    
		
		
            }
	}
	
	
	currentIncmt = newxtra;
	
	   
	   
	    var totalVal=parseInt(data.bidamt)+parseInt(currentIncmt);
	   
           // var totalVal=parseInt(data.bidamt);
            $('#total_bid').val(totalVal); 
            $('#text_filed').html('Bid '+' '+$('#currency_auction').val()+''+totalVal); 
            $('#total_bid_with_curr').val($('#currency_auction').val()+parseInt(data.bidamt));
            $('#current_amount1').val(parseInt(data.bidamt));
        }
	 
     });
   
   // End System Bid socket
      socket.on( 'retract',function (data){
	 socket.on( 'cc_countertobidder',function (data){
                    $('#cc_counter').val(data.cc_count) ;
                    
       });

            var val_cc= $('#cc_counter').val();
        
	if (val_cc==0) { 
	    $('#cc_counter').val("2");
	
         if ($('#total_bid').val() != $('#mybid').val()) {
		 $('.button-bid').css('display','block');
		 $('.higbid').css('display','none');
       
	    }
	    else
	    {
		 $('.button-bid').css('display','none');
		 $('.higbid').css('display','block');
		
	    }     
             
		  
            $("#append_message").append("<li><div class='color6 list1'>Competing bid  "+$("#currency_auction").val()+" "+data.amountonHisthreeLi+"</div></li>");
	    
            $('#current_amount').val(0);
            var valuefinal=parseInt(data.amountonHisthreeLi);
	    $("#mybid").val("0"); 
            $('#total_bid').val(valuefinal);
            //$('#text_filed').html('Bid '+valuefinal);
            $('#text_filed').html('Bid '+''+$('#currency_auction').val()+''+valuefinal); 

            $('#total_bid_with_curr').val($('#total_bid_with_curr').val().split(/(\d)/)[0]+valuefinal);
            if($('.currency_list').val()!='USD')
                currencyChange($('.currency_list').val(),'USD',$('#total_bid').val())
            if(parseInt($('#total_bid').val())!=0){
                $('#text_filed').show();
            } 
        } 
    }); 
socket.on( 'reset',function (data){ 
    socket.on( 'cc_countertobidder',function (data){ 
        $('#cc_counter').val(data.cc_count) ; 
    }); 
    var val_cc= $('#cc_counter').val(); 
    if (val_cc==0) { 
        $('#cc_counter').val("2"); 
        $('.button-bid').css('display','block'); 
        $('.higbid').css('display','none');
	    if($('#append_message li').length >8)
            $('#append_message li').eq(0).remove(); 
            $("#append_message").append("<li><div class='color7 list1'> Lot "+$("#auction_lot_value").val()+" ask "+$("#currency_auction").val()+" "+ data.amountonHisthreeLi+" </div></li>");
            $('#current_amount').val(0);
            var valuefinal=parseInt(data.amountonHisthreeLi);
	    $("#mybid").val("0"); 
            $('#total_bid').val(valuefinal);
            $('#total_bid_with_curr').val($('#total_bid_with_curr').val().split(/(\d)/)[0]+valuefinal);
            if($('.currency_list').val()!='USD')
                currencyChange($('.currency_list').val(),'USD',$('#total_bid').val())
           
            if(parseInt($('#total_bid').val())!=0){
               // $('#text_filed').show();
                $('#text_filed').html('Bid '+' '+$('#currency_auction').val()+''+valuefinal); 
            }         
}   
       });
       
       socket.on('closeconsole',function(data){
	
	     $('#sold-lot').hide();
         if(data.act_id==$("#auction_id").val() || $("#auction_lot_id").val()=="" ){
	    
             $('#close-auction').show();
	     $('.black_overlay').show();
	    $('.button-bid').find('input, textarea, button, select').attr('disabled','disabled');
	   
           
	   
         }
     });
        
   
});
function updateRight(callback){
    base_url = Drupal.settings.basePath;
    $.ajax({
        'url':base_url+'send-bidder-request',
        'type':'POST'
    });
    $.ajax({
        'url':base_url+'fetch-bidder-responce',
        'type':'POST',
        data: {
            act_id:$("#auction_id").val()
            } ,
        'success': function(response){
            var datas = $.parseJSON(response);
            console.log(datas.success)
            if(datas.success!='' && datas.success_id!='' && $('#append_message li').last().attr('id')!=datas.success_id){
                console.log("<br> >>"+datas.success)
                if($('#append_message li').length >8)
                    $('#append_message li').eq(0).remove();
                $("#append_message").append("<li id='"+datas.success_id+"'><div class='color1 list1'>"+datas.success+"</div></li>")
            //$('#append_message li').last().toggle("slide");
            }
        }
    });
    console.clear();
}
