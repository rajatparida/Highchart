/*First install npm                           >> var/www$ install npm
  next using npm install socket.io.js         >> var/www$ npm install socket.io
  next using npm,socket.io.js install express >> var/www$ npm install socket.io express
  run this command very first time on the day >> var/www$ node liveauctions/sites/all/modules/custom/auctionbid/js/sellerServer.js
  //after that the result should show like this without errors
                "info  - socket.io started"
*/
jQuery(document).ready(function(){
    if($('#bids-info ul li').length >0){
        $("#unsold").hide();
        $("#sold").show();
    }
    $('div').find('.slider1').removeClass('arrow1');
    $(".slider1 img").mouseenter(function () {// show pohelp
        $(".banner-slider").show();
        $(this).parents('div:eq(0)').attr('id','currentimg');
        $('#imgTitle').html($('#currentimg span').text());
        $('#currentimg').addClass('arrow1');
        var images_var=$(this).attr('src');
        $('#middle_banner').fadeIn(300).attr('src',images_var);
    });
    $(".slider1 img").mouseleave(function() {
        $(".slider1").attr('id','');
        $('.banner-slider').hide();
        $(".slider1").removeClass('arrow1');
        $('#middle_banner').fadeIn(300).attr('src','<?php echo $base_url.'/'.path_to_theme()?>/images/banner.png');
        $('#imgTitle').html('');
    });
    /*messsge 4 buttons clicked actions*/
    $('.buttons').click(function(){
        console.log("-ajax buttons--");
        $('.buttons').removeClass('buttons');
        /*user should not click any buttons in milli seconds gap so settimeout for add class for bind click*/
        setTimeout(function(){
            $('.msgalert span a').addClass('buttons');
        },200);
        var value=$(this).attr('alt');
        var applyclass=$(this).attr('altcls');
        console.log(value);
        if($(this).attr('id')=='sendmessage' && value==''){
            $('#message_text').attr('placeholder','Please enter message to send').focus();
            return false;
        }

        socket.emit( 'message', {
            name: $("#auction_lot_id").val(),
            message: value ,
            appliedclass:applyclass
        } );
        // Ajax call for saving data in table
        $.ajax({
            url: base_url+"store-lots-seller",
            type: "POST",
            data: {
                lot_value: value,
                lot_id: $("#auction_lot_id").val(),
                act_id: $("#auction_id").val(),
                lot_no: $("#auction_lot_value").val(),
                msg_class:applyclass
            },
            success: function(data) {

            },
            error: function(xhr, textStatus, errorThrown){
                alert('server request failed .Please check your connection!');
                return false;
            }
        });

        return false;
    });
    /*$('.actionbuttons').click(function(){
    var bidactmsg=$(this).attr('alt');
    socket.emit( 'actionsblock', { meher: "krishnakanth" } );

});*/
    $('#sold').click(function(){
        if(!$('#sold').parent().hasClass('disableBtn')){
            socket.emit( 'sold', {
                lot_id: $("#auction_lot_id").val(),
                soldamt: $('#current_soldAmt').val() ,
                appliedclass:$(this).attr('altcls')
            } );
            $('#sold').parent().addClass('disableBtn');
            $('#pass').parent().addClass('disableBtn');
            $('#nextlot').parent().removeClass('disableBtn');
            $.get(base_url+"biddingStatusAction", {
                lot_id:$("#auction_lot_id").val(),
                act_id:$("#auction_id").val(),
                bid_amt:$('#current_soldAmt').val(),
                msg_class:$(this).attr('altcls'),
                bid_status:0//status sold
            },function(req, res){
                console.log(req);
                if(res=='success'){

                }else{
                    alert('Please check your network connection.');
                    return false;
                }
            });
            socket.on('sold',function(data){
                if($("#auction_lot_id").val() ==data.lot_id){
                    $("#messasgeBoard li").eq(0).remove();
                    $("#messasgeBoard").append('<li>Lot '+data.lot_id+' sold for $'+data.soldamt+' to LiveAuctioneers</li>');
                }
            });
        }
    });
    $('#pass').click(function(){
        if(!$('#pass').parent().hasClass('disableBtn')){
            socket.emit( 'pass', {
                lot_id: $("#auction_lot_id").val() ,
                appliedclass:$(this).attr('altcls')
            } );
            $('#sold').parent().addClass('disableBtn');
            $('#pass').parent().addClass('disableBtn');
            $('#nextlot').parent().removeClass('disableBtn');
            $.get(base_url+"biddingStatusAction", {
                lot_id:$("#auction_lot_id").val(),
                act_id:$("#auction_id").val(),
                bid_amt:$('#current_soldAmt').val(),
                msg_class:$(this).attr('altcls'),
                bid_status:2//status passed
            },function(req, res){
                console.log(req);
                if(res=='success'){

                }else{
                    alert('Please check your network connection.');
                    return false;
                }
            });
            socket.on('pass',function(data){
                if($("#auction_lot_id").val() ==data.lot_id){
                    $("#messasgeBoard li").eq(0).remove();
                    $("#messasgeBoard").append('<li>Lot '+data.lot_id+' passed</li>');
                }
            });
        }
    });
    $('#nextlot').click(function(){
        var lotId=$("#auction_lot_id").val();
        if(!$('#nextlot').parent().hasClass('disableBtn')){
            $.get(base_url+"nextLot-Change", {
                lot_id:$("#auction_lot_id").val(),
                act_id:$("#auction_id").val()
            },function(req, res){
                if(res=='success'){
                    $("#replace_content").html(req);
                    //here lot values and auction values currencies everything wil change
                }else{
                    alert('Please check your network connection.');
                    return false;
                }
            });
            socket.emit( 'nextlot', {
                        act_id:$("#auction_id").val(),
                        lot_id: lotId
            });
        }
    });
    socket.on( 'message', function( data ) {
        console.log("---------------------------------->here ");
        if(data.message!=''&& $("#auction_lot_id").val()==data.name){
            $('#messasgeBoard li').eq(0).remove();
            $('#messasgeBoard').append("<li> >>"+data.message+"</li>");
            $('#imgLoads').hide();
            $('#message_text').attr('placeholder','');
            $('#message_text').val('');
            $('#sendmessage').attr('alt','');
        }
    });
    socket.on('currentbid', function( data ) {
        if($("#auction_lot_id").val()==data.lotId){
            $("#unsold").hide();
            $("#sold").show();
            $('#bids-info ul').append("<li style='background-color:#BCF7FE'>$ "+data.amountonHisthreeLi+"(LiveAuctioneers)</li>");
            $( "#bids-info ul li" ).prev().removeAttr('style');
            $("#messasgeBoard li").eq(0).remove();
            $("#messasgeBoard").append('<li>Auto accepted bid $'+data.amountonHisthreeLi+'</li>');
            var inputAskValue=parseInt(data.amountonHisthreeLi)+parseInt(data.currentIncval);
            $("#askamt").val(inputAskValue);
            $("#ask_inc").val(data.currentIncval);
            $("#current_soldAmt").val(data.amountonHisthreeLi);
        }
    });
    /*socket.on( 'actionsblock', function(data) {
    $(".ConsBidContr").append('<p class="AuctionConsolSldRHDs">Lot xxxx:<span>'+data.meher+'</span></p>');
});*/

    //----------backup of previous logic-starts-----------//
    $('#message_text').val('');
    $('.buttons111').click(function(){
        $('.buttons').removeClass('buttons');
        /*user should not click any buttons in milli seconds gap so settimeout for add class for bind click*/
        setTimeout(function(){
            $('.bid-span span a').addClass('buttons');
        },210);
        var value=$(this).attr('alt');
        console.log(value)
        if($(this).attr('id')=='sendmessage' && value==''){
            $('#message_text').attr('placeholder','Please enter message to send').focus();
            return false;
        }
        $('#imgLoads').show();
        var url = base_url+"store-lots-seller";
        $.post(url, {
            lot_value : value,
            lot_id : $("#auction_lot_id").val(),
            act_id : $("#auction_id").val(),
            lot_no : $("#auction_lot_value").val()
        },
        function(response){
            var data = $.parseJSON(response);
            if(data.success!=''){
                setTimeout(function(){
                    $('#messasgeBoard li').eq(0).remove();
                    $('#messasgeBoard').append("<li> >>"+data.success+"</li>");
                    $('#imgLoads').hide();
                },500);
                $('#message_text').attr('placeholder','');
                $('#message_text').val('');
                $('#sendmessage').attr('alt','');
            }
        });
    });
});
//----------backup of previous logic-ends-----------//