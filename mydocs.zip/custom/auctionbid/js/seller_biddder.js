jQuery(document).ready(function(){
 base_url = Drupal.settings.basePath;
 function currencyChange(To,From,Amount){ 
    $('.bid-list').html('').show(); 
    var final_val=fx.convert(Amount, {to: To}); 
    var final_amt= accounting.formatMoney(final_val, To, 2, ",", "."); 
    console.log(final_amt); 
    var lang_data=[]; 
    lang_data=final_amt; 
    var lang_darr=[]; 
    var lang_actua_fileds=12-lang_data.length; 
    if(lang_actua_fileds >0){ 
        for(var k=0;k<lang_actua_fileds;k++){ 
            lang_darr.push("<div class='bid2'><span></span></div>"); 
        } 
    } 
    for (var l = 0; l < lang_data.length; l++) { 
        lang_darr.push("<div class='bid2'><span>"+lang_data[l]+"</span></div>"); 
    } 
    $.each( lang_darr, function( i, val ) { 
        $('.bid-list').append(lang_darr[i]); 
    }); 
    console.log($('.bid-list').html()) 
    if(To=='USD'){ 
        $('.bid-list').hide(); 
    } 
} 
// alert(base_url);
/*jQuery('.button-bid').click(function(){ 
        var value=$("#total_bid").val(); 
   //     var url = base_url + "/sites/all/modules/custom/auctionbid/chat_action.php";          
        alert(value);
        alert(url);
        //var url = '/sites/all/modules/custom/auctionbid/chat_action.php'; 
        jQuery.post(url, { 
            closesoon: value 
        }, 
        function(response){ 
            var data = $.parseJSON(response); 
            $('#append_message li').eq(0).remove(); 
            $("#append_message").append("<li style='display:none;'><div class='color1 list1'>"+data.success+"</div></li>")
            $('#append_message li').last().toggle("slide"); 
            var valuefinal=parseInt(data.success)+18; 
            $('#total_bid').val(valuefinal); 
            $('#total_bid_with_curr').val($('#total_bid_with_curr').val().split(/(\d)/)[0]+valuefinal); 
            if($('.currency_list').val()!='USD') 
                currencyChange($('.currency_list').val(),'USD',$('#total_bid').val()) 
        }); 
    }); */

    jQuery('.button-bid').click(function(){ 
      var lot_value = $("#total_bid").val(); 
      var lot_id = $("#auction_lot_id").val();       
      var act_id = $("#auction_id").val(); 
      var lot_no = $("#auction_lot_value").val();             
     
      jQuery.ajax({
          method:"get",
          url:  base_url+"store-lots",
          data: {lot_value:lot_value,lot_id:lot_id,act_id:act_id,lot_no:lot_no} ,
          success: function(response){ 
             // var data = jQuery.parseJSON(response); 
             alert(response);
              $("#total_bid").val(response);
                //$('#total_bid').val(valuefinal); 
        } 

       // function(html){ 
       //      $(".member_details").html(html).fadeIn("slow"); 
       //  } 
        }); 
    }); 
});
