/*First install npm                           >> var/www$ install npm
  next using npm install socket.io.js         >> var/www$ npm install socket.io
  next using npm,socket.io.js install express >> var/www$ npm install socket.io express
  run this command very first time on the day >> var/www$ node liveauctions/sites/all/modules/custom/auctionbid/js/sellerServer.js
  //after that the result should show like this without errors
                "info  - socket.io started"
*/
//jQuery(document).ready(function(){
var keyboardArr=[];
var unsoldArr=[];
var cc_xtra_count=0; 
$(document).ready(function(){ 
    var aid = jQuery('#auction_id').val(); 
    if (aid== "") { 
        var pathname = window.location.pathname.split("/"); 
        var filename = pathname[pathname.length-1];
        alert("Auction has reached to end and there is no further lots"); 
        $.get(base_url+"auction_end", { 
            act_id:filename 
        },function(req, res){ 
            if(res=='success'){ 
                socket.emit( 'endauction', { 
                    act_id:$("#auction_id").val() 
                }); 
            } 
        }); 
    } 
    $("body").find(".wrapper").attr("class","container-popup-win"); 
    if(parseInt($('#lot_history').val()) ==1){ 
        $("#resetbtn").attr('disabled','disabled'); 
       $("#resetbtn").addClass('resetdisabled');  
        $("#askamt").attr('readonly','readonly');
        $("#unsold").hide();
        $("#sold").show(); 
    } 
    $('div').find('.slider1').removeClass('arrow1');
    $(".slider1 img").mouseenter(function () {// show pohelp 
        $(".banner-slider").show();
       // var currentimg = $("#hhhh").val();
        $(this).parents('div:eq(0)').attr('id','currentimg');
        $('#imgTitle').html($('#currentimg span').text());
        $('#currentimg').addClass('arrow1');
        var images_var=$(this).attr('src');         
        value = images_var.replace(base_url+'sites/default/files/styles/84x54', base_url+'sites/default/files/styles/sellerconsole370x358'); 
         if(value ==''){
            //myvalue = 'No Image created yet' ;
            myvalue = images_var; 
        } else { 
            myvalue = value ;
        }

        $('#middle_banner').fadeIn(300).attr('src',myvalue);  
    }); 
    $(".slider1 img").mouseleave(function() { 
        $(".slider1").attr('id','');
        $('.banner-slider').hide();
        $(".slider1").removeClass('arrow1');
        $('#middle_banner').fadeIn(300).attr('src','<?php echo $base_url.'/'.path_to_theme()?>/images/banner.png');
        $('#imgTitle').html('');
    }); 
    /*messsge 4 buttons clicked actions*/ 
    $('.buttons').click(function(){ 
        if(!$(this).parent().hasClass('disableBtn')){ 
            if($(this).attr('id')=='sendmessage'){ 
                var reg =/<(.|\n)*?>/g; 
                if (reg.test($('#message_text').val()) == true) { 
                    $('#message_text').val(''); 
                    $('#message_text').attr('placeholder','Please enter proper content'); 
                    return false; 
                } 
            } 
            console.log("-buttons--"); 
            $('.buttons').removeClass('buttons'); 
            /*user should not click any buttons in milli seconds gap so settimeout for add class for bind click*/ 
            setTimeout(function(){ 
                $('.msgalert span a').addClass('buttons'); 
            },200); 
            var value=$(this).attr('alt'); 
            var applyclass=$(this).attr('altcls'); 
            if($(this).attr('id')=='sendmessage' && value==''){ 
                $('#message_text').attr('placeholder','Please enter message to send').focus(); 
                return false; 
            } 
            socket.emit( 'cc_countertobidder', { 
                cc_count: 0 
            }); 
            socket.emit( 'messages', { 
                name: $("#auction_lot_id").val(), 
                message: value , 
                appliedclass:applyclass 
            }); 
            $('#cc_counter').val("0"); 
            // Ajax call for saving data in table 
            $.ajax({ 
                type: "POST", 
                dataType: 'json', 
                data: { 
                    lot_value: value, 
                    lot_id: $("#auction_lot_id").val(), 
                    act_id: $("#auction_id").val(), 
                    lot_no: $("#auction_lot_value").val(), 
                    msg_class:applyclass 
                }, 
                url: base_url+"store-lots-seller", 
                success: function(data) { 
                }, 
                error: function(xhr, textStatus, errorThrown){ 
                    alert('server request failed .Please check your connection!'); 
                    return false; 
                } 
            }); 
            return false; 
        } 
    }); 
$('#sold').click(function(){ 
    if(!$('#sold').parent().hasClass('disableBtn')){ 
        $('#cc_counter').val("1"); 
        var val_cc=$('#cc_counter').val(); 
        socket.emit( 'cc_countertobidder', { 
            cc_count: val_cc 
        }); 
        socket.emit( 'sold', { 
            lot_id: $("#auction_lot_id").val(), 
            soldamt: $('#current_soldAmt').val() , 
            appliedclass:$(this).attr('altcls') 
        } ); 
        $('#pauseauction').attr('disabled','disabled');
        $('#pauseauction').addClass('resetdisabled'); 
        $('#sold').parent().addClass('disableBtn'); 
        $('#bidoverphone').parent().addClass('disableBtn'); 
        $('#bidoverphone').attr('disabled','disabled'); 
        $('#bidoverfloor').parent().addClass('disableBtn'); 
        $('#bidoverfloor').attr('disabled','disabled'); 
        $('#retract').parent().addClass('disableBtn'); 
        $('#retract').attr('disabled','disabled'); 
        $('#pass').parent().addClass('disableBtn'); 
        $('.buttons').parent().addClass('disableBtn');
        if (parseInt($("#total_lot").val())!=0) { 
            $('#nextlot').parent().removeClass('disableBtn'); 
        } 
        $.get(base_url+"biddingStatusAction", { 
            sellerId:$('#sellerId').val(), 
            // premium:$('#premium').val(), 
            lottitle:$('#lottitle').val(), 
            lot_id:$("#auction_lot_id").val(), 
            act_id:$("#auction_id").val(), 
            bid_amt:$('#current_soldAmt').val(), 
            msg_class:$(this).attr('altcls'), 
            auction_lot_value:$('#auction_lot_value').val(), 
            bid_status:0//status sold 
        },function(req, res){ 
            console.log(req); 
            if(res=='success'){ 
            }else{ 
                alert('Please check your network connection.'); 
                return false; 
            } 
        }); 
        socket.on('sold',function(data){ 
            var val_cc=$('#cc_counter').val(); 
            if($("#auction_lot_id").val() ==data.lot_id && (val_cc==1 || val_cc==0)){ 
                $('#cc_counter').val("2"); 
                $("#messasgeBoard li").eq(0).remove(); 
                var classstyle=$('#sold').attr('altcls'); 
                if (classstyle.indexOf("phone") >= 0) 
                    $("#messasgeBoard").append('<li>Lot '+$("#auction_lot_value").val()+' sold for'+$("#currency_auction").val()+" "+data.soldamt+' to competing bid</li>'); 
                else 
                    $("#messasgeBoard").append('<li>Lot '+$("#auction_lot_value").val()+' sold for'+$("#currency_auction").val()+" "+data.soldamt+' to paimai</li>'); 
            } 
        }); 
    } 
    if ($("#total_lot").val()==0 ) { 
        $('#nextlot').parent().addClass('disableBtn'); 
        if ($("#round_no").val()==1) { 
            var a=confirm('You have reached end of the auction. Do you want to end this auction?') 
        } else{ 
            a=false; 
        } 
        if (!a) { 
            var act_id=$("#auction_id").val(); 
            /* reopen call */ 
            $.get(base_url+"reopen-console", { 
                act_id:$("#auction_id").val() 
            },function(req, res){ 
                if(res=='success'){ 
                    socket.emit( 'reopen', { 
                        act_id:$("#auction_id").val() 
                    }); 
                    $('#wait').show(); 
                    window.location.href=base_url+"seller-console/"+act_id; 
                } 
            }); 
        /* end reopen call */ 
    } else { 
        $.get(base_url+"auction_end", { 
            act_id:$("#auction_id").val() 
        },function(req, res){ 
            if(res=='success'){ 
                socket.emit( 'endauction', { 
                    act_id:$("#auction_id").val() 
                }); 
            } 
        }); 
    } 
} 
}); 
/*unsold functionality*/ 
$('#unsold').click(function(){ 
    if(!$('#unsold').parent().hasClass('disableBtn')){ 
        $('#cc_counter').val("1"); 
        var val_cc=$('#cc_counter').val(); 
        socket.emit( 'cc_countertobidder', { 
            cc_count: val_cc 
        }); 
        socket.emit( 'unsold', { 
            lot_id: $("#auction_lot_id").val(), 
            appliedclass:$(this).attr('altcls') 
        });  
        $('#unsold').parent().addClass('disableBtn'); 
        $('#sold').parent().addClass('disableBtn'); 
        $('#pass').parent().addClass('disableBtn'); 
        $('#bidoverphone').parent().addClass('disableBtn'); 
        $('#bidoverphone').attr('disabled','disabled'); 
        $('#bidoverfloor').parent().addClass('disableBtn'); 
        $('#bidoverfloor').attr('disabled','disabled'); 
        $('#retract').parent().addClass('disableBtn'); 
        $('#retract').attr('disabled','disabled'); 
        $('#resetbtn').attr('disabled','disabled'); 
        $("#resetbtn").addClass('resetdisabled');  
        $('#pauseauction').attr('disabled','disabled');
        $('#pauseauction').addClass('resetdisabled'); 
        $('.buttons').parent().addClass('disableBtn'); 
        if (parseInt($("#total_lot").val())!=0) { 
            $('#nextlot').parent().removeClass('disableBtn'); 
        } 
        $.get(base_url+"biddingStatusAction", { 
            lot_id:$("#auction_lot_id").val(), 
            lot_no:$("#auction_lot_value").val(), 
            act_id:$("#auction_id").val(), 
            bid_amt:$('#current_soldAmt').val(), 
            msg_class:$(this).attr('altcls'), 
            bid_status:1//status sold 
        },function(req, res){ 
            console.log(req); 
            if(res=='success'){ 
            }else{ 
                alert('Please check your network connection.'); 
                return false; 
            } 
        }); 
        socket.on('unsold',function(data){ 
            var val_cc=$('#cc_counter').val(); 
            if($("#auction_lot_id").val() == data.lot_id && (val_cc==1 || val_cc==0)){ 
                $("#messasgeBoard li").eq(0).remove(); 
                $("#messasgeBoard").append('<li>Lot '+data.lot_id+' unsold </li>'); 
                $('#cc_counter').val('2'); 
            } 
        }); 
    } 
    if ($("#total_lot").val()==0) { 
        act_id=$("#auction_id").val(); 
        $('#nextlot').parent().addClass('disableBtn'); 
        if ($("#round_no").val()==1) {  
            var a=confirm('You have reached end of the auction. Do you want to end this auction?') 
        }else{ 
            a=false; 
        } 
        if (!a) { 
            /* reopen call */ 
            $.get(base_url+"reopen-console", { 
                act_id:$("#auction_id").val() 
            },function(req, res){ 
                if(res=='success'){ 
                    socket.emit( 'reopen', { 
                        act_id:$("#auction_id").val() 
                    }); 
                    $('#wait').show(); 
                    window.location.href=base_url+"seller-console/"+act_id; 
                } 
            }); 
        /* end reopen call */ 
    }else{ 
        $.get(base_url+"auction_end", { 
            act_id:$("#auction_id").val() 
        },function(req, res){ 
            if(res=='success'){ 
                socket.emit( 'endauction', { 
                    act_id:$("#auction_id").val() 
                }); 
            } 
        }); 
    } 
} 
}); 
/*pass lot functionality*/ 
$('#pass').click(function(){ 
    if(!$('#pass').parent().hasClass('disableBtn')){ 
        $('#cc_counter').val("1"); 
        var val_cc=$('#cc_counter').val(); 
        socket.emit( 'cc_countertobidder', { 
            cc_count: val_cc 
        }); 
        socket.emit( 'pass', { 
            lot_id: $("#auction_lot_id").val() , 
            appliedclass:$(this).attr('altcls') 
        } ); 
        $('#pauseauction').attr('disabled','disabled');
        $('#pauseauction').addClass('resetdisabled'); 
        $('#sold').parent().addClass('disableBtn'); 
        $('#bidoverphone').parent().addClass('disableBtn'); 
        $('#bidoverphone').attr('disabled','disabled'); 
        $('#bidoverfloor').parent().addClass('disableBtn'); 
        $('#bidoverfloor').attr('disabled','disabled'); 
        $('#retract').parent().addClass('disableBtn'); 
        $('#retract').attr('disabled','disabled'); 
        $('#pass').parent().addClass('disableBtn');
        $('.buttons').parent().addClass('disableBtn');         
        $('#resetbtn').attr('disabled','disabled'); 
        $("#resetbtn").addClass('resetdisabled');  

        if ($("#total_lot").val()==0) { 
            act_id=$("#auction_id").val(); 
            if ($("#round_no").val()==1) { 
                $('#nextlot').parent().addClass('disableBtn'); 
                var a=confirm('You have reached end of the auction. Do you want to end this auction?') 
            }else{ 
                a=false; 
            } 
            if (!a) { 
                /* reopen call */ 
                $.get(base_url+"reopen-console", { 
                    act_id:$("#auction_id").val() 
                },function(req, res){ 
                    if(res=='success'){ 
                        socket.emit( 'reopen', { 
                            act_id:$("#auction_id").val() 
                        }); 
                        $('#wait').show(); 
                        window.location.href=base_url+"seller-console/"+act_id; 
                    } 
                }); 
            /* end reopen call */ 
        }else{ 
            $.get(base_url+"auction_end", { 
                act_id:$("#auction_id").val() 
            },function(req, res){ 
                if(res=='success'){ 
                    socket.emit( 'endauction', { 
                        act_id:$("#auction_id").val() 
                    }); 
                } 
            }); 
        } 
    } 
    if (parseInt($("#total_lot").val())!=0) { 
        $('#nextlot').parent().removeClass('disableBtn'); 
    } 
    $.get(base_url+"biddingStatusAction", { 
        lot_id:$("#auction_lot_id").val(), 
        lot_no:$("#auction_lot_value").val(), 
        act_id:$("#auction_id").val(), 
        bid_amt:$('#current_soldAmt').val(), 
        msg_class:$(this).attr('altcls'), 
        bid_status:2//status passed 
    },function(req, res){ 
        console.log(req); 
        if(res=='success'){ 
        }else{ 
            alert('Please check your network connection.'); 
            return false; 
        } 
    }); 
    socket.on('pass',function(data){ 
        var val_cc=$('#cc_counter').val(); 
        if($("#auction_lot_id").val() == data.lot_id && (val_cc==1 || val_cc==0)){ 
            $("#messasgeBoard li").eq(0).remove(); 
            $("#messasgeBoard").append('<li>Lot '+data.lot_id+' passed</li>'); 
            $('#cc_counter').val("2"); 
        } 
    }); 
} 
}); 
$('#nextlot').click(function(){ 
    var lotId=$("#auction_lot_id").val(); 
    /* this is for first message when next lot clicked -start*/ 
    if(!$('#nextlot').parent().hasClass('disableBtn')){ 

        /* this is for first message when next lot clicked -end*/ 
        $.get(base_url+"nextLot-Change", { 
            lot_id:$("#auction_lot_id").val(), 
            act_id:$("#auction_id").val() 
        },function(req, res){ 
            if(res=='success'){ 
                $("#replace_content").html(req); 
                $('#pauseauction').removeClass('resetdisabled'); 
                $('#pauseauction').removeAttr('disabled');
                $('.buttons').parent().removeClass('disableBtn'); 
                $('#resetbtn').removeAttr('disabled','disabled');     
                $("#resetbtn").removeClass('resetdisabled');

                $.getScript(base_url+"misc/jquery.js"); 
                $.getScript(base_url+"sites/all/modules/custom/auctionbid/js/seller_console.js"); 
                //here lot values and auction values currencies everything wil change 
                $.ajax({ 
                    type: "POST", 
                    dataType: 'json', 
                    data: { 
                        lot_value: "Lot "+$("#auction_lot_value").val()+" opened ask "+$("#currency_auction").val()+" "+$('#askamt').val(), 
                        lot_id: $("#auction_lot_id").val(), 
                        act_id: $("#auction_id").val(), 
                        lot_no: $("#auction_lot_value").val(), 
                        msg_class:'color8 list1' 
                    }, 
                    url: base_url+"store-lots-seller", 
                    success: function(data) { 
                        $('#cc_counter').val("1"); 
                        var val_cc=$('#cc_counter').val();  
                        socket.emit( 'cc_countertobidder', { 
                            cc_count: val_cc  
                        });  
                        socket.emit( 'nextlot', {  
                            act_id:$("#auction_id").val(),  
                            lot_id: lotId  
                        }); 
                    },  
                    error: function(xhr, textStatus, errorThrown){  
                        alert('server request failed .Please check your connection!');  
                        return false; 
                    } 
                }); 
/* this is for first message when next lot clicked -end*/ 
}else{ 
    alert('Please check your network connection.'); 
    return false; 
} 
}) 
} 
}); 
$('#retract').click(function(){ 
    var lotId=$("#auction_lot_id").val(); 
    if(!$('#retract').parent().hasClass('disableBtn')){ 
        $('#retract').parent().addClass('disableBtn'); 
        $.get(base_url+"retract-Bid", { 
            lot_id:$("#auction_lot_id").val(), 
            act_id:$("#auction_id").val() 
        },function(req, res){ 
            var data = $.parseJSON(req); 
            if(res=='success'){ 
                $('#bids-info ul li').last().remove(); 
                //  alert(data.msg) ; 
                $('#sold').attr('altcls',data.msg); 
                $('#current_soldAmt').val(data.soldamt); 
                $('#messasgeBoard li').eq(0).remove(); 
                $('#messasgeBoard').append("<li> Competing bid retract "+$("#currency_auction").val()+" "+data.bid_amt+"</li>"); 
                $("#ask_inc").val(data.iCurrentIncBid); 
                $("#askamt").val(data.bid_amt); 
                socket.emit( 'cc_countertobidder', { 
                    cc_count: 0 
                }); 
                socket.emit('retract', { 
                    amountonHisthreeLi: data.bid_amt, 
                    currentIncval:parseInt(data.iCurrentIncBid), 
                    lotId:$("#auction_lot_id").val(), 
                }); 
            }else{ 
                alert('Please check your network connection.'); 
                return false; 
            } 
        }); 
} 
}) 
$('#resetbtn').click(function(){ 
    var amt = $('#askamt').val(); 
    if(amt == 0 || amt == " " ){ 
        alert('Please enter current ask value to reset'); 
        $("#askamt" ).focus(); 
        return false ; 
    } 
    $('#resetbtn').attr('disabled','disabled');
    $("#resetbtn").addClass('resetdisabled');  
    socket.emit( 'cc_countertobidder', { 
        cc_count: 0 
    }); 
    $.ajax({ 
        type: "POST", 
        dataType: 'json', 
        data: { 
            lot_value: amt, 
            lot_id: $("#auction_lot_id").val(), 
            act_id: $("#auction_id").val(), 
            lot_no: $("#auction_lot_value").val(), 
            reset:'yes', 
            msg_class:$(this).attr('altcls'), 
            iCurrentIncBid:$('#ask_inc').val() 
        }, 
        url: base_url+"phone-floor-bidder", 
        success: function(data) { 
            $('#retract').parent().addClass('disableBtn'); 
            socket.emit( 'cc_countertobidder', { 
                cc_count: 0 
            }); 
            socket.emit('reset', { 
                amountonHisthreeLi: parseInt($('#askamt').val()), 
                currentIncval:parseInt(data.currentIncval), 
                lotId:$("#auction_lot_id").val(), 
            }); 
            $('#messasgeBoard li').eq(0).remove(); 
            $('#messasgeBoard').append("<li> Lot "+$("#auction_lot_value").val()+" ask "+$("#currency_auction").val()+" "+amt+"</li>"); 
            var inputAskValue=parseInt(amt); 
            $("#askamt").val(inputAskValue); 
            $("#ask_inc").val(data.currentIncval); 
            $('#cc_counter').val("2"); 
            $('#resetbtn').removeAttr('disabled');
            $("#resetbtn").removeClass('resetdisabled');    
        }, 
        error: function(xhr, textStatus, errorThrown){ 
            alert('server request failed .Please check your connection!'); 
            return false; 
        } 
    }); 
return false; 
}) 
$('#bidoverphone, #bidoverfloor').click(function(){ 
    if(this.id=="bidoverphone"){ 
        var msg_class='phone'; 
    }else { 
        var msg_class='floor'; 
    } 
    if($("#bidoverphone").attr("disabled")=="disabled"){ 
        e.preventDefault(); 
    } 
    $('#bidoverphone').attr('disabled','disabled'); 
    $('#retract').parent().addClass('disableBtn'); 
    $('#retract').attr('disabled','disabled'); 
    $('#bidoverphone').parent().addClass('disableBtn'); 
    $('#bidoverfloor').attr('disabled', 'disabled'); 
    $('#bidoverfloor').parent().addClass('disableBtn'); 
    $('#PhoneFloor').val($('#askamt').val()); 
    var amt=$('#PhoneFloor').val(); 
    if($('#PhoneFloor').val()==''){ 
        alert('Please enter value for phone/floor bidder'); 
        return false; 
    } 
    socket.emit( 'cc_countertobidder', { 
        cc_count: 0 
    }); 
    socket.emit( 'phoneFloor', { 
        lotid: $("#auction_lot_id").val(), 
        bidamt: amt , 
        appliedclass:$(this).attr('altcls') 
    }); 
    $('#cc_counter').val("0"); 
    // Ajax call for saving data in table 
    $.ajax({ 
        type: "POST", 
        dataType: 'json', 
        data: { 
            lot_value: amt, 
            lot_id: $("#auction_lot_id").val(), 
            act_id: $("#auction_id").val(), 
            lot_no: $("#auction_lot_value").val(), 
            msg_class:msg_class, 
            iCurrentIncBid:$('#ask_inc').val() 
        }, 
        url: base_url+"phone-floor-bidder", 
        success: function(data) { 
            $('#current_soldAmt').val(amt); 
            $('#bids-info ul').append("<li style='background-color:#BCF7FE'> "+$("#currency_auction").val()+" "+amt+"(Competing bid)</li>"); 
            $('#sold').attr('altcls','color5 list1 phone'); 
            $('#retract').parent().removeClass('disableBtn'); 
            $('#ask_inc').val(data.currentIncval); 
            var inputAskValue=parseInt(amt)+parseInt(data.currentIncval); 
            $("#askamt").val(inputAskValue);
            $("#ask_inc").val(data.currentIncval);
            $('#bidoverfloor').removeAttr('disabled'); 
            $('#bidoverfloor').parent().removeClass('disableBtn'); 
            $('#bidoverphone').parent().removeClass('disableBtn'); 
            $('#bidoverphone').removeAttr('disabled'); 
            $('#retract').parent().removeClass('disableBtn'); 
            $('#retract').removeAttr('disabled','disabled'); 
            if (parseInt($("#maxbid").val()) > parseInt(inputAskValue)) { 
                setTimeout(function() { 
                // Bid after 1 second 
                socket.emit( 'cc_countertobidder', { 
                    cc_count: 0 
                }); 
                $('#cc_counter').val(0); 
                socket.emit( 'systembid', { 
                    act_id:$("#auction_id").val(), 
                    lot_id: $("#auction_id_value").val(), 
                    lot_no:$("#auction_lot_value").val(), 
                    bidamt:$("#askamt").val(), 
                    userid:$("#userid").val(), 
                }); 
            }, 1000); 
            } 
        }, 
        error: function(xhr, textStatus, errorThrown){ 
            alert('server request failed .Please check your connection!'); 
            return false; 
        } 
    }); 
return false; 
}); 
socket.on( 'messages', function( data ) {

        var val_cc=$('#cc_counter').val();
        
        console.log("val_cc  in seller !!!"+val_cc);
        socket.emit( 'cc_countertobidder', {
               cc_count: val_cc
        });
        if (val_cc==1 || val_cc==0) {
            //code
           // console.log("---------------------------------->here seller_sonsole");
            if(data.message!=''&& $("#auction_lot_id").val()== data.name ){
                $('#messasgeBoard li').eq(0).remove();
                $('#messasgeBoard').append("<li> >>"+data.message+"</li>");
                $('#imgLoads').hide();
                $('#message_text').attr('placeholder','');
                $('#message_text').val('');
                $('#sendmessage').attr('alt','');
                $('#cc_counter').val("2");
            }
        }
    }); 
socket.on( 'phoneFloor', function( data ) { 
    var val_cc=$('#cc_counter').val(); 
    console.log("val_cc  in seller phoneFloor !!!"+val_cc); 
    socket.emit( 'cc_countertobidder', { 
        cc_count: val_cc 
    }); 
    if (val_cc==1 || val_cc==0) { 
        if ($('#sold').css('display') == 'none') { 
            $("#resetbtn").attr('disabled','disabled');
            $("#resetbtn").addClass('resetdisabled');   
            $("#askamt").attr('readonly','readonly'); 
            $("#unsold").hide(); 
            $("#sold").show(); 
        } 
        //code 
        console.log("---------------------------------->here phoneFloor seller_sonsole"); 
        if(data.bidamt!='' && parseInt($("#auction_lot_id").val())== parseInt(data.lotid) ){ 
            $('#messasgeBoard li').eq(0).remove(); 
            $('#messasgeBoard').append("<li> Auto accepted bid "+$("#currency_auction").val()+" "+data.bidamt+"</li>"); 
            $("#ask_inc").val(data.iCurrentIncBid); 
            $("#askamt").val(data.bidamt); 
            $('#cc_counter').val("2"); 
        } 
    } 
}); 
socket.on( 'cc_countertoseller',function (data){ 
    $('#cc_counterseller').val(data.cc_counter) ; 
}); 
socket.on('currentbid', function( data ) { 
    socket.on( 'cc_countertoseller',function (data){ 
        $('#cc_counterseller').val(data.cc_counter) ; 
        console.log("yeeeey !!" +data.cc_counter); 
    }); 
    var val_cc= $('#cc_counterseller').val(); 
    if($("#auction_lot_id").val()== data.lotId  && (val_cc==1 || val_cc==0)){ 
        $('#retract').parent().addClass('disableBtn');  
        $('#retract').attr('disabled','disabled');  
        $("#resetbtn").attr('disabled','disabled');
        $("#resetbtn").addClass('resetdisabled');    
        $("#askamt").attr('readonly','readonly');  
        if($('#bidtype').val()=='keyboard'){ 
            $("#messasgeBoard li").eq(0).remove(); 
            $("#messasgeBoard").append('<li>passing for internet acceptence amount '+$("#currency_auction").val()+" "+data.amountonHisthreeLi+'</li>');  
            keyboardArr=data;  
            $('#internet').parent().removeClass('disableBtn'); 
            return false; 
        }  
        $('#cc_counterseller').val('2'); 
        $("#unsold").hide(); 
        $("#sold").show(); 
        //  $('#retract').parent().removeClass('disableBtn'); 
        $('#bids-info ul').append("<li style='background-color:#BCF7FE'>"+$("#currency_auction").val()+" "+data.amountonHisthreeLi+"(paimai)</li>"); 
        $('#sold').attr('altcls','color5 list1'); 
        $( "#bids-info ul li" ).prev().removeAttr('style'); 
        $("#messasgeBoard li").eq(0).remove(); 
        if($('#bidtype').val()=='keyboard') 
            $("#messasgeBoard").append('<li>keyboard accepted bid '+$("#currency_auction").val()+" "+data.amountonHisthreeLi+'</li>'); 
        else 
            $("#messasgeBoard").append('<li>Auto accepted bid '+$("#currency_auction").val()+" "+data.amountonHisthreeLi+'</li>'); 
        var inputAskValue=parseInt(data.amountonHisthreeLi)+parseInt(data.currentIncval); 
        $("#askamt").val(inputAskValue); 
        $("#ask_inc").val(data.currentIncval); 
        $("#current_soldAmt").val(data.amountonHisthreeLi); 
        // Auto absentee bid when someone bid 
        if (parseInt($("#maxbid").val()) > parseInt(data.amountonHisthreeLi)) { 
            setTimeout(function() { 
            // Bid after 1 second 
            socket.emit( 'cc_countertobidder', { 
                cc_count: 0 
            }); 
            $('#cc_counter').val("0"); 
            socket.emit( 'systembid', { 
                act_id:$("#auction_id").val(), 
                lot_id: $("#auction_lot_id").val(), 
                lot_no:$("#auction_lot_value").val(), 
                bidamt:$("#askamt").val(), 
                userid:$("#userid").val(), 
            }); 
        }, 2000); 
        } 
        // End Auto absentee bid when someone bid 
    } 
}); 
$('#internet').click(function(){ 
    if(!$('#internet').parent().hasClass('disableBtn') && keyboardArr.amountonHisthreeLi){ 
        $('#internet').parent().addClass('disableBtn'); 
        var data=[]; 
        data=keyboardArr; 
        $('#cc_counterseller').val('2'); 
        $("#unsold").hide(); 
        $("#sold").show(); 
        $('#bids-info ul').append("<li style='background-color:#BCF7FE'>"+$("#currency_auction").val()+" "+data.amountonHisthreeLi+"(paimai)</li>");  
        $( "#bids-info ul li" ).prev().removeAttr('style');
            $("#messasgeBoard li").eq(0).remove();
            if($('#bidtype').val()=='keyboard')
                $("#messasgeBoard").append('<li>keyboard accepted bid'+$("#currency_auction").val()+" "+data.amountonHisthreeLi+'</li>');
            else
                $("#messasgeBoard").append('<li>Auto accepted bid '+$("#currency_auction").val()+" "+data.amountonHisthreeLi+'</li>');
            var inputAskValue=parseInt(data.amountonHisthreeLi)+parseInt(data.currentIncval);
            $("#askamt").val(inputAskValue);
            $("#ask_inc").val(data.currentIncval);
            $("#current_soldAmt").val(data.amountonHisthreeLi);
        }
    });
        /* Pause action */

    $('#pauseauction').click(function(){        
        $("#my-popup").hide();
        var pausestatus=$('#pauseauction').val();
        if ($('#pauseauction').val() == "Pause") {
            var a=confirm('Are you sure you want to Pause?')
            if (!a)
                return false;
        }
        socket.emit( 'cc_countertobidder', {
               cc_counter: 1
            });
        $('#cc_counter').val("0");
        if ($('#pauseauction').val() == "Pause") {


        socket.emit( 'messages', {
            name: $("#auction_lot_id").val(),
            
            message: "Pause",
            appliedclass:'color2 list1',

        });
        alert("Auction paused");
         $('#sold').parent().addClass('disableBtn');
         $('#sold').attr('disabled','disabled'); 
         $('#unsold').attr('disabled','disabled');          
         $('#pass').parent().addClass('disableBtn'); 
         $('.buttons').parent().addClass('disableBtn'); 
         $('#nextlot').parent().addClass('disableBtn'); 
         $('#bidoverphone').attr('disabled','disabled'); 
         $('#bidoverphone').parent().addClass('disableBtn'); 
         $('#bidoverfloor').attr('disabled', 'disabled'); 
         $('#bidoverfloor').parent().addClass('disableBtn'); 
         $('#retract').parent().addClass('disableBtn'); 
         $('#resetbtn').attr("disabled", "disabled"); 
         $("#askamt").attr('readonly','readonly'); 
         $("#resetbtn").addClass('resetdisabled');  

         $('#pauseauction').val("Resume");
        }
        else {

            socket.emit( 'messages', {
            name: $("#auction_lot_id").val(),
            message: "Resume",
            appliedclass:'color2 list1',

        });
        alert("Auction resume");
         $('#sold').parent().removeClass('disableBtn');
         $('#pass').parent().removeClass('disableBtn');
         $('#bidoverfloor').removeAttr('disabled');
         $('#bidoverfloor').parent().removeClass('disableBtn');
         $('#nextlot').parent().removeClass('disableBtn');
         $('#bidoverphone').parent().removeClass('disableBtn');         
         $('#bidoverphone').removeAttr('disabled');
         $('#pass').parent().removeClass('disableBtn');
         $('#sold').removeAttr('disabled','disabled'); 
         $('#unsold').removeAttr('disabled','disabled');         
         $('.buttons').parent().removeClass('disableBtn');
         $('#pauseauction').val("Pause");
        }
        //inserting record
         $.ajax({
            type: "POST",
          
            dataType: 'json',
            data: {
              pausestatus:pausestatus,
                lot_id: $("#auction_lot_id").val(),
                act_id: $("#auction_id").val(),
                lot_no: $("#auction_lot_value").val(),
                msg_class:$(this).attr('altcls'),
                iCurrentIncBid:$('#ask_inc').val()
            },
            url: base_url+"pauseauction",
            success: function(data) {
                $('#ask_inc').val(data.currentIncval);
            },
            error: function(xhr, textStatus, errorThrown){
                alert('server request failed .Please check your connection!');
                return false;
            }
        });

     });
     $('#endauction').click(function(){
        var act_id = $("#auction_id").val() ;
          var a=confirm('Are you sure you want to Close Auction?')
            if (!a) {
               /* reopen call */               
                 $.get(base_url+"reopen-console", {
                    act_id:$("#auction_id").val()
                },function(req, res){
                   if(res=='success'){
                        socket.emit( 'reopen', {
                            act_id:$("#auction_id").val()
                        });
                        $('#wait').show();
                        window.location.href=base_url+"seller-console/"+act_id;
                        
                        
                    }
                });
               /* end reopen call */
             
            }
        
                
            else{

                $.get(base_url+"auction_end", {
                    act_id:$("#auction_id").val()
                },function(req, res){
                    if(res=='success'){
                        socket.emit( 'endauction', {
                            act_id:$("#auction_id").val()
                        });
//                        window.parent.close();
                    }
                });

            }
     });
     $('#reopenlot').click(function(){
         var previousLotId=$("#previous_lot_id").val();
           $.get(base_url+"nextLot-Change", {
                lot_id:previousLotId,
                act_id:$("#auction_id").val()
            },function(req, res){
                if(res=='success'){
                    $("#replace_content").html(req);
                     $.getScript(base_url+"misc/jquery.js");
                     $.getScript(base_url+"sites/all/modules/custom/auctionbid/js/seller_console.js");
                    //here lot values and auction values currencies everything wil change
                }else{
                    alert('Please check your network connection.');
                    return false;
                }
            });
            socket.emit( 'nextlot', {
                        act_id:$("#auction_id").val(),
                        lot_id: previousLotId
            });
     });
     $('.form-text').blur(function(){
         if($(this).val()==''){
             alert('please enter all required fileds');
             return false;
         }

     });
     $('#closePopup').click(function(){
    $("#my-popup").hide();
     });
     socket.on('endauction',function(data){
         if(data.act_id==$("#auction_id").val()){
             alert("auction finished");
             window.parent.close();
             return false;
         }
     });
     
     $('#systembid').click(function(){
        
      
        var a=isNaN(parseInt($("#maxbid").val()));
        
        if (a) {
            return false;
        }
    
        $('#cc_counter').val(0);
       if ( parseInt($("#askamt").val()) > parseInt($("#maxbid").val())) {
       return false;
       }
       
    $("#askamt").attr('readonly','readonly');
    $("#resetbtn").attr('disabled','disabled'); 
    $("#resetbtn").addClass('resetdisabled');  
     socket.emit( 'cc_countertobidder', {
                      cc_count: 0
                      });
     socket.emit( 'systembid', {
                        act_id:$("#auction_id").val(),
                        lot_id: $("#auction_id_value").val(),
                        lot_no:$("#auction_lot_value").val(),
                        
                        bidamt:$("#sysbid").val(),
                        userid:$("#userid").val(),
                        
            });
    
    });
     
     // System Bid Socket
    
     
     
     socket.on('systembid',function(data){
        var val_cc=$('#cc_counter').val();
        
         if(data.act_id==$("#auction_id").val() && (val_cc==0 || val_cc==1)){
            $('#cc_counter').val(2);
              var amt=$("#sysbid").val();
        //ajax call
        $.ajax({
            type: "POST",
            dataType: 'json',
            data: {
                lot_id:$("#auction_lot_id").val(),
                act_id:$("#auction_id").val(),
                lot_no:$("#auction_lot_value").val(),
                uid:$("#userid").val(),
                bid_amt:data.bidamt,
            },
            url: base_url+"store-systembid",
            success: function(systembid) {
                 
                 $("#resetbtn").attr('disabled','disabled'); 
                 $("#resetbtn").addClass('resetdisabled');  
                  $("#askamt").attr('readonly','readonly');
                 $('#messasgeBoard li').eq(0).remove();
                 //$("#currency_auction").val();
                 
                     $("#messasgeBoard").append('<li>System  bid '+$("#currency_auction").val()+" "+data.bidamt+'</li>');
                     $("#ask_inc").val(systembid.currentIncval);
                     $("#askamt").val(systembid.amount);
                     $("#sysbid").val(systembid.amount);
                     $('#cc_counter').val("2");
                    $('#current_soldAmt').val(data.bidamt);
                    $("#unsold").hide();
                    $("#sold").show();
            
            },
            error: function(xhr, textStatus, errorThrown){
                alert('server request failed .Please check your connection!');
                return false;
            }
        });
        //end ajax call
            
             
            
         }
     });
     
         
     // End system bid
     
     
      socket.on( 'systembidbidder', function( data ) {
        
          socket.on( 'cc_countertoseller',function (edata){
                $('#cc_counterseller').val(edata.cc_count) ;
                console.log("yeeeey !!" +edata.cc_count);
        });
          
        var val_cc= parseInt($('#cc_counterseller').val());
        
        if($("#auction_id").val()== data.act_id  && (val_cc==1 || val_cc==0)){
           
        
        if (parseInt($("#maxbid").val()) > parseInt($("#askamt").val())) {
              $('#cc_counterseller').val('2');
            socket.emit( 'cc_countertobidder', {
                      cc_count: 0
                      });
           
             socket.emit('systembid', {
                        act_id:$("#auction_id").val(),
                        lot_id: $("#auction_id_value").val(),
                        lot_no:$("#auction_lot_value").val(),
                        bidamt:$("#sysbid").val(),
                        userid:$("#userid").val(),
                        
            });
            }
            }
        
        });
      
});
    //----------backup of previous logic-starts-----------//
  /*  $('#message_text').val('');
    $('.buttons111').click(function(){
        $('.buttons').removeClass('buttons');
        /*user should not click any buttons in milli seconds gap so settimeout for add class for bind click*/
        /*setTimeout(function(){
            $('.bid-span span a').addClass('buttons');
        },210);
        var value=$(this).attr('alt');
        console.log(value)
        if($(this).attr('id')=='sendmessage' && value==''){
            $('#message_text').attr('placeholder','Please enter message to send').focus();
            return false;
        }
        $('#imgLoads').show();
        var url = base_url+"store-lots-seller";
        $.post(url, {
            lot_value : value,
            lot_id : $("#auction_lot_id").val(),
            act_id : $("#auction_id").val(),
            lot_no : $("#auction_lot_value").val()
        },
        function(response){
            var data = $.parseJSON(response);
            if(data.success!=''){
                setTimeout(function(){
                    $('#messasgeBoard li').eq(0).remove();
                    $('#messasgeBoard').append("<li> >>"+data.success+"</li>");
                    $('#imgLoads').hide();
                },500);
                $('#message_text').attr('placeholder','');
                $('#message_text').val('');
                $('#sendmessage').attr('alt','');
            }
        });
    });
//});*/
//----------backup of previous logic-ends-----------//
