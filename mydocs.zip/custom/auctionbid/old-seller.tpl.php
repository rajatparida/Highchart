<script> 
var sessionVar="<?php echo $_SESSION['req']['closesoon']?>"; 
$(document).ready(function(){ 
    if($('.slider-cont div').length > 4){ 
        var len=4; 
        $('.slider-cont').find('div:gt('+len+')').remove(); 
    } 
    $('ul.tabs li').click(function(){ 
        var tab_id = $(this).attr('data-tab'); 
        $('ul.tabs li').removeClass('current'); 
        $('.tab-content').removeClass('current'); 
        $(this).addClass('current'); 
        $("#"+tab_id).addClass('current'); 
    }); 
}); 
</script> 
<style> 
.form-text {width: 244px;} 
#sellersetting-form .form-item label {float: left;width: 30%;} 
.form-item, .form-actions {margin-bottom: 1em;margin-top: 1em;} 
#sellersetting-form #autoaccept .form-type-radio {float: left;width: 43%;} 
#autoaccept input {float: left;} 
#sellersetting-form #autoaccept label {float: left;padding: 0 0 0 2%;width: 88%;} 
#sellersetting-form #autoaccept{float: left;width: 100%;} 
.head-tab {float: left;margin: 10px 0 15px;width: 100%;} 
.containerprogess {width: 185px;margin:3px 0 0 74px;} 
.progress {overflow: hidden;height: 18px;background-color: #f7f7f7;
background-image: -moz-linear-gradient(top, #f5f5f5, #f9f9f9);
background-image: -ms-linear-gradient(top, #f5f5f5, #f9f9f9);
background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#f5f5f5), to(#f9f9f9));
background-image: -webkit-linear-gradient(top, #f5f5f5, #f9f9f9);
background-image: -o-linear-gradient(top, #f5f5f5, #f9f9f9);
background-image: linear-gradient(top, #f5f5f5, #f9f9f9);
background-repeat: repeat-x;
filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#f5f5f5', endColorstr='#f9f9f9', GradientType=0);
-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;border:2px solid #AC5202;}

.wrapper-fox{max-width: 940px; width: 100%; margin: 0px auto; padding: 10px; border: 1px #ccc solid; clear: both; border-radius: 5px;}
.progress .barfox {width: 50%;height: 18px;background-color: #AC5202;background-repeat: repeat-x;
filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#149bdf', endColorstr='#0480be', GradientType=0);
-webkit-box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);-moz-box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);
box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);-webkit-box-sizing: border-box;-moz-box-sizing: border-box;
box-sizing: border-box;-webkit-transition: width 0.6s ease;-moz-transition: width 0.6s ease;
-ms-transition: width 0.6s ease;-o-transition: width 0.6s ease;transition: width 0.6s ease;}
.gallery-top{border-radius: 5px;  margin-bottom: 10px;}
.black_overlay{display: none;position: absolute;top: 0%;left: 0%;width: 100%;height: 100%;background-color: black;
    z-index:1001;-moz-opacity: 0.8;opacity:.80;filter: alpha(opacity=80);}
/*.white_content {display: none;position: absolute;top: 25%;left: 25%;width: 50%;height: 50%;
    padding: 16px;border: 5px solid #234273;background-color: white;z-index:1002;overflow: auto;}*/
.containera{margin: 0 auto;max-width: 960px;}
@media only screen and (max-width : 786px){}
/*.white_content {background-color: #FFFFFF;display: none;height: 40%;left: 25%;overflow: auto;
    padding: 16px;position: absolute;top: 15%;width: 53%;z-index: 1002;}
}
@media only screen and (max-width : 480px)
{
.white_content {background-color: #FFFFFF; display: none; height: 44%; left:25%;overflow: auto;
    padding: 16px; position: absolute;top: 8%;width:82%;z-index: 1002;}
@media only screen and (max-width : 320px)
{
.white_content {background-color: #FFFFFF; display: none;height: 44%;left:0%;overflow: auto;
    padding: 16px; position: absolute;top: 8%; width:90%; z-index: 1002;}*/
#sellersetting-form .form-item label {float: left;font-size: 12px;width: 28%;}
.form-text {width: 174px;}
#sellersetting-form #autoaccept .form-type-radio {float: left;width: 52%;}
</style>
<?php 
session_start(); 
global $base_url, $user; 
?>
<span id="replace_content"> 
    <input type="hidden" id="cc_counter" value="0"> 
    <input type="hidden" id="cc_counterseller" value="0"> 
    <input type="hidden" name="bidtype" id="bidtype" value="<?php echo $_SESSION['req']['autoaccept']; ?>">

<?php 
//echo $currentInc;exit; 
$node_dt = node_load($seller_data[0]->field_choose_auction_nid); 
$aucnid = $node_dt->nid;  
$cr_tid = getTermName($node_dt->field_currency['und'][0]['tid']);  
if($cr_tid == 'CHF'){  
    $cr = $cr_tid ; 
} else { 
    $cr = '$' ;   
} 
echo "<div class='online_watch'>Online Bidders :- ".$loggeduser. 
    " Online Watchers :-". $watcher; "</div>";?> 
<?php 
$auctionsCount = $totalLot; 
$premium=$node_dt->field_buyers_premium['und'][0]['value'];
$node_dc = node_load($seller_data[0]->entity_id);
$nodettl = $node_dc->title ;
$lot_value = $node_dc->field_lot_no['und'][0]['value'];
$file = file_load($node_dc->uc_product_image['und'][0]['fid']);
$image = file_create_url($file->uri);
$auctitle = $node_dc->title;
$aucnidd = $node_dc->field_lot_no['und'][0]['value'];
$desc = $node_dc->body['und'][0]['value'];
$aucdesc = $node_dc->body['und'][0]['value'];
$high = $node_dc->field_company['und'][0]['value'];
$low = $node_dc->field_low_estimate['und'][0]['value'];
$start = $node_dc->field_timeout['und'][0]['value']; 
foreach ($totalLot_arr as $key => $val) { 
    $dem_arr[$key] = $totalLot_arr[$key]->entity_id; 
    if ($seller_data[0]->entity_id == $totalLot_arr[$key]->entity_id) { 
        $xtra_dem_arr['len_uncount'] = count($dem_arr); 
        $xtra_dem_arr['len'] = $auctionsCount - count($dem_arr); 
        $xtra_dem_arr['currentid'] = $totalLot_arr[$key]->entity_id; 
    } 
} 
foreach ($seller_data as $key => $val) { 
    if ($key > 0) { 
        $nextLotsArr[] = node_load($seller_data[$key]->entity_id); 
    } 
} 
if (is_array($bid_history) && count($bid_history) > 0) { 
    $temp_count = count($bid_history) - 1; 
    $tmpbidArr = $bid_history[$temp_count]; 
    #echo $tmpbidArr->bid_amt;exit; 
    /* start Bid Increment -value start */ 
    $bidVal = intval($tmpbidArr->bid_amt); 
    foreach ($bidincValArr as $k => $v) { 
        if ($k == 'range1_value' || $k == 'range2_value' || $k == 'range3_value' || $k == 'range4_value' || $k == 'range5_value' || $k == 'range6_value' || $k == 'range7_value' || $k == 'range8_value' 
            || $k == 'range9_value' || $k == 'range10_value') { 
            $bidRangeVal[] = $v; //array of range amounts how much should increase
            } else if ($k == 'range1' || $k == 'range2' || $k == 'range3' || $k == 'range4' || $k == 'range5' || $k == 'range6' || $k == 'range7' || $k == 'range8' || $k == 'range9' || $k == 'range10') {
                $posArr[] = $v; //array of bid amounts which are greater than requested bid amount
            }
        } 
    for ($l = 0; $l < count($posArr); $l++) { 
        $arr= $posArr[$l+1]; 
        if($arr=="" || $arr==0 ){ 
            $arr=$bidVal+1; 
        } 
        if($l==0) { 
            if(($bidVal <= $posArr[$l]) ){ 
                $increment = $bidRangeVal[$l]; 
                break; 
            } 
        } 
        //  echo $posArr[$l] ."<=". $bidVal." &&". $bidVal ."<". $arr."<br>"; 
        if (($posArr[$l] <= $bidVal && $bidVal <= $arr ) || $l == 9) { 
            $bid=$bidRangeVal[$l+1]; 
            // Last lot condition 
            if($bid==0){ 
                $increment = $bidRangeVal[$l]; 
                break; 
            } else { 
                $increment = $bidRangeVal[$l+1]; 
                break; 
            } 
        } 
    } 
    $currentInc=$increment; 
    $bidVal=$bidVal+$currentInc; 
/* start Bid Increment -value end */ 
} 
?> 
<?php 
/* Auto System bid */ 
if($offlinebid ){ 
    $i=0; 
    foreach($offlinebid as $offline){ 
        if($i==0){ 
            $maxbid=$offline->bid_amt; 
            $uid=$offline->uid; 
        } 
        $i++;  
    } 
    if(count($offlinebid)==2){ 
        $start_bid= $offline->bid_amt; 
        if( $start_bid!=$maxbid){ 
            $bidinc=getBidIncrementValue($seller_data[0]->field_choose_auction_nid,$start_bid); 
            $system_bid=$start_bid+$bidinc; 
        }else{ 
            $system_bid=$maxbid; 
        } 
    } else{ 
    // $bidinc = getBidIncrementValue($seller_data[0]->field_choose_auction_nid,$bidVal); 
        $system_bid=$bidVal; 
    } 
    if($bidVal>$system_bid){ 
        $system_bid=$bidVal; 
    } 
    if($system_bid <= $maxbid && isset($_SESSION['req'])){ ?> 
    <script> 
    $(document).ready(function(){ 
        if (sessionVar!=""){ 
            $( "#systembid" ).trigger( "click" ); 
        } 
    }); 
    </script> 
   <?php }  
}  
//End system b   
?> 
<input type='button' id='systembid'  style="display:none;" /> 
<input type='hidden' id='sysbid' value='<?php echo $system_bid; ?>'> 
<input type='hidden' id='userid' value='<?php echo $uid; ?>'> 
<input type='hidden' id='maxbid' value='<?php echo $maxbid; ?>'>  
<input type="hidden" id="currency_auction" value="<?php echo $cr; ?>" /> 
<div id='wait' class="white_content"> 
    <div style="position:relative;"> 
        <br/>Please wait..<br/> 
    </div> 
</div> 
<div class="black_overlay "></div> 
<div id="my-popup" class="white_content" > 
    <div class="btn-clos"> 
        <a href="javascript:void(0);" id="closePopup">X</a> 
    </div> 
    <div class="containera"> 
        <ul class="tabs "> 
            <li class="tab-link current" data-tab="tab-1">Auction Setting</li> 
            <li class="tab-link" data-tab="tab-2" >End Auction</li> 
        </ul> 
        <div id="tab-1" class="tab-content current"> 
            <div class="cont1"> Message to bidders</div> 
            <div class="head-tab"> 
                <div class="tab1-pop">Name</div> 
                <div class="tab2-pop">Message Text</div> 
            </div> 
            <?php print drupal_render(drupal_get_form('sellersetting_form')); ?> 
        </div> 
        <div id="tab-2" class="tab-content"> 
            <div class="pause-auction"> 
                <input type="button" class="endacton-btn" value="Pause" id="pauseauction" > 
            </div> 
            <div class="end-action-btn"> 
                <input type="button" class="endacton-btn" id="endauction" value="End Auction"> 
            </div> 
        </div> 
    </div> 
</div> 
<!-- / POPUP--> 
<div class="gallery-top"> 
    <a href="#" class="logo"> 
        <img src="<?php echo $base_url . '/' . path_to_theme() ?>/images/logo-small.png" alt=""> 
    </a> 
    <div class="gallery-title"> 
        <h4><?php echo $node_dt->title;?></h4> 
        <p><?php echo $node_dt->name;?></p> 
    </div> 
    <div class="loader"> 
        <input type="hidden" value="<?php echo $xtra_dem_arr['len'] ?>" id="total_lot"> 
        <?php $round_no=findAuctionRound($seller_data[0]->field_choose_auction_nid); $len= $totalitems-$xtra_dem_arr['len'];?> 
        <span> 
            <?php if($round_no>1) echo '100'; else echo round(($len / $totalitems) * 100); ?>% &nbsp;  <?php if($round_no>1) echo '0'; else echo $xtra_dem_arr['len'] ?> 0f <?php  echo $totalitems; ?> remaining 
        </span> 
        <br> 
        <input type="hidden" id='round_no' value=<?php echo $round_no; ?>> 
        <script> 
        var diagram="<?php if($round_no > 1) echo '100'; else echo round(($len / $totalitems) * 100); ?>"; 
        //document.getElementById('myid').className.style.width=diagram+"%"; 
        $(document).ready(function(){ 
            $('#myid').attr('style',"width:"+diagram+'% !important'); 
        }) 
    </script> 
    <div class="containerprogess"> 
        <div class="progress"> 
            <div id="myid" class="barfox"></div> 
        </div> 
    </div> 
</div> 
</div> 
<div class="bl"></div> 
<div class="inside_middlesec page-seller-live-auction"> 
    <input type="hidden" id="sellerId" value="<?php echo $node_dc->uid; ?>"/>
    <input type="hidden" name="premium" id="premium" value="<?php echo $premium; ?>">
    <input type="hidden" name="lottitle" id="lottitle" value="<?php echo $nodettl; ?>">
    <input type="hidden" id="auction_lot_id" value="<?php echo $seller_data[0]->entity_id; ?>"/>
    <input type="hidden" id="auction_id" value="<?php echo $seller_data[0]->field_choose_auction_nid; ?>"/>
    <input type="hidden" id="auction_lot_value" value="<?php echo $lot_value; ?>"/>
    <input type="hidden" id="current_soldAmt" value="<?php echo $tmpbidArr->bid_amt ?>"/>
    <input type="hidden" id="previous_lot_id" value="<?php echo $previousLotId ?>"/>
    <input type="hidden" id="lot_history" <?php if($start!=$bidVal) { echo "value='1'"; } else { echo "value='0'"; } ?> />
    <div class="inside_middlesec_left"> 
    <!-- left AuctionConsolePageSec --> 
    <div> 
        <div class="Auction1"> 
            <div class="banner-cont"> 
                <div class="slider-cont"> 
                    <?php 
                    foreach ($seller_data as $single_lot) { 
                        if ($single_lot->entity_id == $seller_data[0]->entity_id) 
                            continue; 
                        $lid = $single_lot->entity_id; 
                        $lot_dt = node_load($lid); 
                        $img_url = file_create_url($lot_dt->uc_product_image['und'][0]['uri']); 
                        $img_title = $lot_dt->title; 
                        echo '<div class="slider1 arrow1"> 
                        <span style="display:none;">' . $img_title . '</span> 
                        <a href="#" class="arrow-curve"></a> 
                        <a href="#"><img src="' . $img_url . '"  class="banners_div" alt="" style="cursor:pointer;width:50px;height:50px;"/></a></div>'; 
                    }?> 
                </div> 
                <div class="banner-img"> 
                    <div class="banner-bg" > 
                        <img src="<?php echo $image ?>" id="mainimg" alt=""  /> 
                    </div> 
                    <div class="banner-slider"  style="margin: 25px 0%;padding: 14px 2%;width: 96%;display:none;"> 
                        <img id="middle_banner" src="<?php echo $base_url . '/' . path_to_theme() ?>/images/banner1.jpg"  alt=""/> 
                        <p id="imgTitle"></p> 
                    </div> 
                </div> 
                <div class="banner-pop" id="popup-div"> 
                    <table width="100%" cellpadding="2" cellspacing="0"> 
                        <tr> 
                            <th width="75%" align="left"> Description</th> 
                            <th width="25%" align="left">Estimate</th> 
                        </tr> 
                        <tr> 
                            <td><?php echo $aucdesc; ?></td> 
                            <td> 
                                <span><img src="<?php echo $base_url . '/' . path_to_theme() ?>/images/arrow-bot.png"  alt="" /></span><?php echo $high; ?><br/> 
                                <span><img src="<?php echo $base_url . '/' . path_to_theme() ?>/images/arrow-toop.png"  alt="" /></span><?php echo $low; ?> 
                            </td> 
                        </tr> 
                    </table> 
                    <a href="#" class="close-icon"> 
                        <img src="<?php echo $base_url . '/' . path_to_theme() ?>/images/close-icon.png"  alt="" /> 
                    </a> 
                </div> 
            </div> 
            <div class="clear"></div> 
            <textarea id="item-desc" style="resize:none;" rows="3" cols="57" readonly="readonly"><?php echo $desc; ?></textarea> 
            <div> 
                <p>Estimate $ <?php echo $low ?> - <?php echo $high ?> 
                </p> 
                <a href="javascript:void(0);" > 
                    <img src="<?php echo $base_url ?>/sites/all/modules/custom/auctionbid/images/settings.jpeg" alt="Settings"   onclick="mypopup()" id="magpopup"> 
                </a> 
            </div> 
        </div> 
        <div id="qt-auc-set" style="display:none;"> 
        </div> 
    </div> 
    <span style="display:none;" id="auid"></span> 
    <!-- left AuctionConsolePageSec --> 
    <div class="box_shadow Consbox_shadow"></div> 
</div> 
<img src="images/loader_ajax.gif" id="imgLoads" class="overlay" style="display:none;position: absolute; right: 478px; top: 539px;"/> 
<div class="inside_middlesec_rightbid"> 
    <div class="sell-op" > 
        <div id="bids-info"> 
            <ul > 
                <?php 
                foreach ($bid_history1 as $k => $v) { 
                // if(is_numeric($bid_sold[$k]->bid_amt)) 
                    echo "<li>".$cr . $bid_history1[$k]->bid_amt . " (paimai) </li>"; 
                } 
                ?> 
            </ul> 
        </div> 
        <div id="bids-info-detail" style="width:48%;float:left;padding:1%;" > 
            <ul > 
                <?php 
                foreach ($bid_sold as $k => $v) { 
                    if(strpos($bid_sold[$k]->msg_class,'phone') == false && strpos($bid_sold[$k]->msg_class,'floor') == false){  
                        echo "<li>Lot " . $bid_sold[$k]->lot_no . " sold " . $bid_sold[$k]->bid_amt . " to paimai</li>"; 
                    } else { 
                        echo "<li>Lot " . $bid_sold[$k]->lot_no . " sold " . $bid_sold[$k]->bid_amt . " to competing bid</li>"; 
                    } 
                } 
                ?> 
            </ul> 
        </div><!-- consolePageContRHead --> 
    </div > 
    <div class="message-cont"> 
        <ul id="messasgeBoard"> 
            <li>Lot <?php echo $lot_value; ?> opened</li> 
            <li>ask <?php echo $cr." ". intval($bidVal); ?></li> 
            <li><span class="autoacceptText">Auto Accepted bid </span><?php echo $cr." ". $bidVal ?></li> 
        </ul> 
    </div> 
    <div  class="message-test1"> 
        <textarea id="message_text" onblur="$('#sendmessage').attr('alt',$(this).val());$(this).attr('placeholder','');"></textarea> 
    </div> 
    <div class="bid-span msgalert"> 
        <span class="ConsSelContrR flr"><a id="colsesoon_mainbtn" href="javascript:void(0);" altcls="color1 list1" alt="<?php echo $_SESSION['req']['closesoon']; ?>" class="ConsSelContrRBtn buttons">Close Soon</a></span>
        <span class="ConsSelContrR flr"><a id="farewarning_mainbtn" href="javascript:void(0);" altcls="color2 list1" alt="<?php echo $_SESSION['req']['fairwarning']; ?>" class="ConsSelContrRBtn buttons">Fair Warning</a></span>
        <span class="ConsSelContrR flr"><a id="lastacll_mainbtn" href="javascript:void(0);" altcls="color3 list1" alt="<?php echo $_SESSION['req']['lastcall']; ?>" class="ConsSelContrRBtn buttons">Last Call</a></span>
        <span class="ConsSelContrR flr"><a href="javascript:void(0);" altcls="color1 list1" id="sendmessage" alt="" class="ConsSelContrRBtn buttons">Send Message</a></span> 
    </div> 
    <div class="sell-bids"><p class="cbid"><strong>Bid Increment : <?php echo $cr ;?></strong></span> 
        <input  style="float:right;margin-top: -2%; text-align: center; width: 24%;" readonly="readonly" type="text" id="ask_inc" value="<?php echo $currentInc; ?>" /></p> 
        <input type="hidden" name="PhoneFloor" id="PhoneFloor" value=""/> 
        <h4 class="nbid"> 
            <span style="float:left;width:62%;">  
                <strong>Current Ask : <?php echo $cr ;?></strong>  
            </span>  
            <input  style="float:left;margin-top: -2%; text-align: center; width: 30%;" type="text" id="askamt" onkeypress="this.value=this.value.replace(/[^.\d]/,'');" onkeyup="this.value=this.value.replace(/[^.\d]/,'');$('#PhoneFloor').val(this.value)" maxlength="8" value="<?php echo $bidVal; ?>" /> 
            <input type="button" value="reset" id="resetbtn"/>  
        </h4> 
        <!-- consolePageContRHead --> 
    </div> 
    <div class="bid-span bidactionbtns"> 
        <span class="ConsSelContrR flr"> 
            <a class="ConsSelContrRBtn actionbuttons" alt="unsold" id="unsold" altcls="color4 list1" href="javascript:void(0);">Unsold</a> 
            <a class="ConsSelContrRBtn actionbuttons" alt="sold" id="sold" altcls="color5 list1" href="javascript:void(0);" style="display: none;">sold</a> 
        </span> 
        <span class="ConsSelContrR flr"> 
            <a class="ConsSelContrRBtn actionbuttons" alt="pass" id="pass" altcls="color6 list1" href="javascript:void(0);">Pass</a> 
        </span> 
        <span class="ConsSelContrR flr disableBtn"> 
            <a class="ConsSelContrRBtn actionbuttons" alt="nextlot" id="nextlot" href="javascript:void(0);">NextLot</a> 
        </span> 
        <span class="ConsSelContrR flr"> 
            <a class="ConsSelContrRBtn actionbuttons" id="retract" href="javascript:void(0);">Retract</a> 
        </span> 
    </div> 
    <div class="bids-span"> 
        <span class="ConsSelContrR flr"><a href="javascript:void(0);" altcls="color6 list1" id="bidoverphone" class="ConsSelContrRBtn">Bids over Phone</a></span> 
        <span class="ConsSelContrR flr"><a href="javascript:void(0);" altcls="color6 list1" id="bidoverfloor" class="ConsSelContrRBtn">Bids over Floor</a></span> 
        <span class="ConsSelContrR flr <?php if($_SESSION['req']['autoaccept']=='auto') {?>disableBtn"<?php }?>"><a href="javascript:void(0);" id="internet" class="ConsSelContrRBtn">Internet</a></span> 
    </div>
        


        </div>
      

    </div>
</span>
