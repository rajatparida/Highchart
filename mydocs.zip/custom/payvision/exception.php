<?php

class Payvision_Exception extends Exception
{

}