<div class="auction-select"> 
    <select id="select_auction_seller" class="filsearch"> 
    	 <option value="0">All</option>  

     <?php   
     foreach($auction_select as $auctions){ ?>
     <option value="<?php echo $auctions->nid ?>"><?php echo $auctions->title ?></option>  
     <?php }       ?> 
 </select> 
</div>