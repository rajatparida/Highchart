<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=true">
</script>
<?php   
global $user ;   
$logged_user_val = user_load($user->uid) ;
$lat = $logged_user_val->field_address['und'][0]['latitude'] ;
$long = $logged_user_val->field_address['und'][0]['longitude'] ;   
?> 
<script type="text/javascript">
    var geocoder;
  	var map;
    var latlng = new google.maps.LatLng('<?php echo $lat; ?>', '<?php echo $long; ?>');
        function initialize()
        {
			var mapProp = {
			  center:latlng,
			  zoom:3, 
			  mapTypeId:google.maps.MapTypeId.ROADMAP
			  };
var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
var infowindow = new google.maps.InfoWindow(); 
var marker, i; 
<?php 
foreach($data as $userid) { 
  $user_dtl = user_load($userid->uid) ; 
  $user_lat = $user_dtl->field_address['und'][0]['latitude'] ;
  $user_lng = $user_dtl->field_address['und'][0]['longitude'] ;   
  $user_fname = $user_dtl->field_first_name['und'][0]['value'] ;   
  $user_lname = $user_dtl->field_last_name['und'][0]['value'] ; 
  $cont_no = $user_dtl->field_home_phone['und'][0]['value'] ; 
  $mail = $user_dtl->mail ;
  $timezone = $user_dtl->timezone ;
  $name = $user_fname.'&nbsp'.$user_lname ; 
  ?> 
  marker = new google.maps.Marker({
        position: new google.maps.LatLng('<?php echo $user_lat;?>', '<?php echo $user_lng;?>'),
        map: map
      });

      google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
          //infowindow.setContent('hello World');  $cont_no ,$mail ,$timezone
          infowindow.setContent('<?php echo $name;?></br>'+
            '<?php echo $cont_no;?></br>' + '<?php echo $mail;?></br>'+'<?php echo $timezone;?></br>'); 
          infowindow.open(map, marker);
        }
      })(marker));

<?php  } ?>

}
google.maps.event.addDomListener(window, 'load', initialize);
   </script>

<div id="googleMap" style="width:960px; height:600px;"></div>

