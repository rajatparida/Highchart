<?php
//echo $data;
global $base_url;
 $theme_path = drupal_get_path('theme', variable_get('theme_default', NULL));
    $imgpath = $base_url . "/" . $theme_path;
?>
<div class="profile-right2">
          <div class="prof-msg">
          	<!--<a href="#"><img src="<?php echo $imgpath?>/images/msg-profile.jpg" alt=""></a>
            <p>Andy Warhol, Signed Print, Marilyn, 1986<br>Item Number: 123<br>Self Price: 500</p>-->
              <p><?php echo $data['subject'];?></p>
          </div>
          <div class="profile-detail1">
            <div class="prof-left"> 
            	<div class="profile-icon1 relative">
                	<div class="profile-frame"></div>
                <a href="#"><img src="<?php echo $data['authimg'];?>" alt="" height="25" width="25"></a></div>
            
            <span> <strong> <?php echo $data['auth_name'];?></strong> to me </span> </div>
            <div class="prof-right"> <span> <?php echo $data['mesg_time'];?> </span> <!--<img src="<?php echo $imgpath?>/images/star-icon.png" alt=""> -->
              <div class="refresh-icon"> 
                  <a href="#"><img src="<?php echo $imgpath?>/images/refresh-arow.png" alt=""></a> 
                 <!-- <a href="<?php echo $base_url?>/messages/delete/<?php echo $data['thread_id'];?>/<?php echo $data['mid'];?>"><img src="<?php echo $imgpath?>/images/trash-ico.png" alt="Delete this Message" title="Delete this Message"></a> -->
                  
                  <a href="#" class="brdrnone"><img src="<?php echo $imgpath?>/images/arrow-down1.png" alt=""></a> 
              </div>
            </div>
            <div class="profile-msgs">
             <?php echo $data['msgbody'];?>
              
              
            </div>
          </div>
        </div>
