<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
<div class="near-map-cont"><?php     
print drupal_render(drupal_get_form('searczip_form'));
$zipcode = arg(2);
if(!empty($zipcode)) { 
  $url = "http://maps.googleapis.com/maps/api/geocode/json?address=".$zipcode."&sensor=false";
  $details=file_get_contents($url);$result = json_decode($details,true);
  $account_lat=$result['results'][0]['geometry']['location']['lat'];
  $account_long=$result['results'][0]['geometry']['location']['lng'];
  $lat = $account_lat; 
  $long = $account_long;
} else { 
  global $user ;    
  $logged_user_val = user_load($user->uid) ; 
  $lat = $logged_user_val->field_address['und'][0]['latitude'] ; 
  $long = $logged_user_val->field_address['und'][0]['longitude'] ;   
} 
?> </div>
<script type="text/javascript">
    var geocoder;
    var map;
    var latlng = new google.maps.LatLng('<?php echo $lat; ?>', '<?php echo $long; ?>');
    //var latlng = new google.maps.LatLng('380015');  
        function initialize(){ 
          var infowindow = new google.maps.InfoWindow(); 
          var marker, i; 
          var mapProp = { 
            center:latlng, 
            zoom:4,  
            mapTypeId:google.maps.MapTypeId.ROADMAP 
          }; 
          var map=new google.maps.Map(document.getElementById("googleMap"),mapProp); 
          marker = new google.maps.Marker({
            position: latlng,
            map: map,
            });
          google.maps.event.addListener(marker, 'click', (function(marker, i) {
            return function() { 
            infowindow.setContent("<?php echo 'My Location';?>");  
            infowindow.open(map, marker); 
          }
          })(marker));
<?php 
foreach($data as $userid) {  
  $user_dtl = user_load($userid->uid) ; 
  $user_lat = $user_dtl->field_address['und'][0]['latitude'] ;
  $user_lng = $user_dtl->field_address['und'][0]['longitude'] ;   
  $user_fname = $user_dtl->field_first_name['und'][0]['value'] ;   
  $user_lname = $user_dtl->field_last_name['und'][0]['value'] ; 
  $cont_no = $user_dtl->field_home_phone['und'][0]['value'] ; 
  $mail = $user_dtl->mail ;
  $timezone = $user_dtl->timezone ;
  $name = $user_fname.'&nbsp'.$user_lname ; 
  ?> 
  var markericon = {  url : 'http://maps.google.com/mapfiles/ms/icons/green-dot.png'};
  marker = new google.maps.Marker({
        position: new google.maps.LatLng('<?php echo $user_lat;?>', '<?php echo $user_lng;?>'),
        map: map,
        icon : markericon
        }); 
  google.maps.event.addListener(marker, 'click', (function(marker, i) {
    return function() { 
    //infowindow.setContent('hello World');  $cont_no ,$mail ,$timezone
    infowindow.setContent('<?php echo $name;?></br>'+'<?php echo $cont_no;?></br>' + '<?php echo $mail;?></br>'+'<?php echo $timezone;?></br>');  
    infowindow.open(map, marker); 
  }
      })(marker)); 
<?php  } ?>  
}
google.maps.event.addDomListener(window, 'load', initialize);
   </script>

<div class="full-map" id="googleMap" style="width:100%; height:400px;"></div>

