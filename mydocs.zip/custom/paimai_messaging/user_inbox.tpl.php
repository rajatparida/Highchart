<?php global $base_url;
$arg2 = arg(2);
// print_r($data);?>
<div class="filter-listing">
    <?php 
    foreach($data as $mesg)
    { 
    $user_dt = user_load($mesg['author']);
    $difference = time() - $mesg['timestamp'];
    $mesg_time = format_interval($difference, 1) . " ago";
  
        //print_r($mesg); ?>
    <a href="<?php echo $base_url?>/user/<?php echo $mesg['author']?>/<?php echo $arg2;?>/view/<?php echo $mesg['mid']?>">
            <div class="filter-list1">
             <!-- <input type="checkbox" value="" name=""> -->
              <div class="list-cont">
                <h4><?php echo $user_dt->name ?> <span><?php echo $mesg_time ?></span></h4>
                <p><?php echo $mesg['subject'] ?></p>
              </div>

            </div>
    </a>
        <?php } ?>
           
          </div>
  <div class="filter-load"> <?php echo $paging;?></div>
