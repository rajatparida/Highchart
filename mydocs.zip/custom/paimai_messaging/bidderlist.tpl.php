<div class="auction-table"> 
    <table cellspacing="0" cellpadding="0" class="seller-bid-tab textcent"> 
        <tr> 
            <th></th> 
            <th>Bidders</th> 
            <th>Bids</th> 
            <th>Bid Value</th> 
        </tr> 
<?php 
$sellerTotal = 0; 
$i=1; 
//print_r($approvebids);
foreach ($status as $key => $val) {  
    $i++; 
    $ss = $i%2; 
    if($ss == 0) { 
        $class = "odd"; 
    } else{ 
        $class="even"; 
    }?> 
    <tr class="<?php echo $class ?>"> 
        <td><?php echo $val;?></td> 
        <td><?php echo ($result[$key]['bidder'])?$result[$key]['bidder']:'0';?></td> 
        <td><?php 
        if($val=='Approved') { 
            echo $approvebids['approvebids']; 
        }elseif ($val=='pending') {
           echo $pendingsbids['pendingsbids']; 
        }elseif ($val=='Declined') {
           echo $declinedbids['declinedbids']; 
        }elseif ($val=='Blocked') {
           echo $blockebids['blockebids']; 
       }elseif ($val=='Suspended') {
           echo $suspendedbids['suspendedbids']; 
       } 
       ?></td> 
        <td><?php //echo $result[$key]['sell']; 
         if($val=='Approved') { 
            $sellerTotal = $sellerTotal + $approvebidval['approvebidval']; 
            echo $approvebidval['approvebidval']; 
        }elseif ($val=='pending') {            
            $sellerTotal = $sellerTotal + $pendingbidval['pendingbidval']; 
           echo $pendingbidval['pendingbidval']; 
        }elseif ($val=='Declined') {
            $sellerTotal = $sellerTotal + $declinebidval['declinebidval']; 
           echo $declinebidval['declinebidval']; 
        }elseif ($val=='Blocked') {
            $sellerTotal = $sellerTotal + $blockbidval['blockbidval']; 
           echo $blockbidval['blockbidval']; 
        }elseif ($val=='Suspended') {
            $sellerTotal = $sellerTotal + $suspendbidvalbidval['suspendbidvalbidval']; 
           echo $suspendbidvalbidval['suspendbidvalbidval'];  
       } 
       ?>
        </td> 
        </tr> 
        <?php 
    } ?> 
    <tr> 
        <td><b>Total</b></td> 
        <td><b><?php echo $result['bidderTotal']; ?></b></td> 
        <td><b></b></td> 
        <td><b><?php echo $sellerTotal; ?></b></td> 
    </tr> 
</table> 
</div>

