jQuery(document).ready(function() {      
    base_url = Drupal.settings.basePath;
    msg_sts=0 ; 
    zip = 0;       
    jQuery('#message_status').change(function(){               
      var selleruser = jQuery("#selleruser").val();              
        var msg_sts = jQuery("#message_status").val();              
        window.location.href= base_url + "user/"+selleruser+"/auction-messages/"+msg_sts; 
    }); 

    jQuery('#select_auction_seller').change(function(){ 
    //alert('hello')      ;
      var sel_auction = jQuery("#select_auction_seller").val(); 
      jQuery.ajax({ 
        type: "POST", 
        url: base_url+"bidderlist",         
        data: { auctionId:sel_auction }, 
        success: function(msg){       
        //alert(msg);    
          jQuery("#messageStatus").html(msg); 
        } 
      }); 
    }); 

    jQuery('#message_allselect').click(function(){    
        jQuery('.msg-check').attr('checked',this.checked);
        var check = jQuery(".msg-check").val(); 
      }); 
    jQuery(".msg-check").click(function(){ 
      if(jQuery(".msg-check").length == jQuery(".msg-check:checked").length) { 
        jQuery("#message_allselect").attr("checked", "checked"); 
      } else { 
        jQuery("#message_allselect").removeAttr("checked"); 
      } 
    }); 
    jQuery('#console_msg').change(function(){ 
      var select_auction = jQuery("#console_msg").val(); 
      window.location.href= base_url + "admin/paimai/console-messages/"+select_auction; 
    }); 
  });
 
function test(){    
    var zip = jQuery("#edit-zipcode").val();
    window.location.href= base_url+"user/auction-nearbyme/"+zip; 
    return false;
}
