<?php   
global $user ;   
//$logged_user_val = user_load($user->uid) ;

print_r($data); exit ;

//print_r($logged_user_val); exit ;
//$lat = $logged_user_val->field_address['und'][0]['latitude'] ;
//$long = $logged_user_val->field_address['und'][0]['longitude'] ;   
//print drupal_render(drupal_get_form('auction_messages_form'));
?> 

