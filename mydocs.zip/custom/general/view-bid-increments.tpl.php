 <?php 
 global $base_url;
 $currency = $result->currency;
 
 ?>
 
  <!-- Range Icrement --> <div class="tab_content_left">
                    
        <div class="bid-increment">
	<div class="bid-range">Bid</div>
    <div class="bid-increment1">Increments</div>
   
        <?php 
    if($count != 0){
    ?>
    <div style="float: left; clear: both; width: 69%;">
    <div class="row">
	<div class="row-left first1"><?php echo $currency;?>0</div>
        <div class="row-right">&nbsp;</div>
    </div>
    <?php for($i = 1;$i <= 10;$i++){ 
    $range = 'range'.$i;
    $rangeValue = 'range'.$i.'_value';
     if($result->$rangeValue != ""){
    ?>
    <div class="row">
	<div class="row-left"><img alt="" src="<?php echo $base_url.'/sites/all/themes/auction/images/to-img.png';?>" /></div>
        <div class="row-right"><span class="dollar"><?php echo $currency;?></span><span class="edit1"><?php echo $result->$rangeValue;?></span></div>
    </div>
    <?php
     }
    if(($result->$range) != $tempBidRange && $result->$range != "") {
    ?>
     <div class="row">
        <div class="row-left"><span class="dollar"><?php echo $currency;?></span><span class="edit1"><?php echo $result->$range;?></span></div>
        <div class="row-right">&nbsp</div>
    </div>
    <?php
    } else {
    ?>
   <div class="row">
	<div class="row-left"><span class="dollar"><?php echo $currency;?></span><span class="edit1">+</span></div>
        <div class="row-right">&nbsp</div>
    </div>
<?php
break;
}
 $tempBidRange = $result->$range + 1;
    } 
    }
    ?>
    </div>
 <div style="float: left; width: 31%;">
    <div style="float:right"><img src="<?php echo $base_url?>/sites/default/files/pictures/<?php echo $sellLogo?>" style="width:139px; height:78px;" ></div>
    <div class="bidlength">This auctioneer set the following standardized amount a lot increases in price after each new bid.</div>       
    </div>

</div>
       </div>                                                         
<!-- Range Icrement --> 

<?php
exit;?>