<?php
/* 
Author:Emp-Id 1241;
Date:6/Sep/2013;
File:Template file for auction catalog page auctioneers description. 
*/ 

global $base_path;
$theme_path = drupal_get_path('theme', variable_get('theme_default', NULL));
$imgpath=$base_path.$theme_path;

?>

<div class="auction-desc1">
<div class="auction-desc-top">
    <h3>Auction Description</h3>
    <a href="#" class="arrow1"><img src="<?php echo $imgpath?>/images/arrow-down.png" alt="" /></a> </div>
<div class="auction-desc-middle auction-para ">
    <p class="cat-desc"><?php print $data['cat-detail']; ?> </p>
</div>
</div>
</div>


<!--
<div class="auction-info">
<div class='headiingpan'>
<h5>Auction Description</h5>
<div class="arrowpan">&nbsp;</div>
</div>
<div class="auction-cat-desc">
 <div class="cat-desc"><?php //print $data['cat-detail']; ?></div>
</div></div>-->