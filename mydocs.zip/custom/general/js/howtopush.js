 jQuery.noConflict();
jQuery(document).ready(function(){
	
	// Logging, don't enable in production environments
	Pusher.log = function() {
      if (window.console) window.console.log.apply(window.console, arguments);
    };
	
	// Make a Pusher connection with your PusherApp API Key and channel
	var socket = new Pusher("d680c861255a911c2481");
	socket.auth_url = '/presence_auth.php';
	
	// Presence Stuff
	/*var Pusher_Presence = socket.subscribe('test_channel');
	Pusher_Presence.bind('pusher:subscription_succeeded', function(member_list){
		alert(member_list);
		console.log("Members: " + member_list);
	
	});
	Pusher_Presence.bind('pusher:member_added', function(member){
	
		console.log("Added: " + member);
	
	});
	Pusher_Presence.bind('pusher:member_removed', function(member){
	
		console.log("Removed: " + member);
	
	});
	*/
	// Subscribe to a specific type of event
	
	
	jQuery('#eventButton').click(function()
	{
		// Get the title and contents of the event
		var title = jQuery('#eventTitle').val();
		var content = jQuery('#eventContent').val();
		
		// Validate they are both not empty
		if(title == '' || content == '')
		{
			// If they are empty, alert the user and don't carry on
			alert('Please enter an event title and some content!');
		}
		else
		{
			// Send a POST request to the file ajax/send.php carrying the title and content
			jQuery.post('ajax/send.php', { title:title, content:content }, function(data)
			{
				if(data != 1)
				{
					// If the send.php file doesn't echo the number 1 onto the page to signify it all went well, alert the user there was an error, for the developer to debug
					alert('There was an error pushing your event!');
				}
			});
		}
	});
	
	jQuery('.close').live('click',function()
	{
		jQuery(this).parent('li').slideUp();
		setTimeout("jQuery(this).parent('li').remove();",300);
	});

});