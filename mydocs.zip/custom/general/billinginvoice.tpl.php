<?php
//print_r($comm);
global $base_url;
global $user;
//print_r($results);
$admin_dt = user_load(1);
//print_r($admin_dt);
$seller_dt = user_load($user->uid);
//echo '<pre>';
//print_r($seller_dt);

$seller_dt->field_address['und'][0]['street'];
$seller_dt->field_address['und'][0]['city'];
$seller_dt->field_address['und'][0]['postal_code'];
$seller_dt->field_address['und'][0]['country_name'];

$admin_dt->name;
$admin_dt->mail;
$admin_dt->field_home_phone['und'][0]['value'];
$admin_dt->field_work_phone['und'][0]['value'];

$aucid = $results[0]->auction_id;
//$lotid = $results['lot_id'];
//$bidderid = $results['user_id'];
//$hammerprice = $results['hammer_price'];
//$status = $results['paid'];
$aucname = node_load($aucid);
$lotname = node_load($lotid);
$biddername = user_load($bidderid);
$auctite = $aucname->title;
$aucpack = $aucname->field_purchased_package['und'][0]['nid'];
$pack = node_load($aucpack);
$packname = $pack->title;
$lotn = $lotname->title;
$bname=$biddername->name;

$biddername->name;
$biddername->mail;
$biddername->field_first_name['und'][0]['value'];
$biddername->field_last_name['und'][0]['value'];
$biddername->field_home_phone['und'][0]['value'];
$biddername->field_work_phone['und'][0]['value'];
$biddername->field_address['und'][0]['street'];
$biddername->field_address['und'][0]['city'];                  
$biddername->field_address['und'][0]['postal_code'];
$biddername->field_address['und'][0]['province_name'];
$biddername->field_address['und'][0]['country_name'];

if($status == 0){
    $paid  = 'Open';
} else {$paid  = 'Paid';}

?>

<table align="center" width="600" border="0" cellspacing="0" cellpadding="0" class="email-table">
    <tr><td><a href="javascript:void();" onclick="window.history.back();">back</a></td></tr>  
  <tr>
         <td align="center" style="background:#ad0303; height:120px; padding:10px 0 10px 0px;">
    
             </td>
 
      <!--<td align="center" style="background:#ad0303; height:120px; padding:10px 0 10px 0px;"><img src="<?php echo $base_url.'/'.drupal_get_path('theme',$GLOBALS['theme']);?>/images/logo-img.png" width="306" height="109" alt="del sam familie" /></td>-->
  </tr>
  <tr>
    <td style="background:#dd3a3a; height:40px;"><p style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight:bold; color:#fff; padding:0px 0 0 10px;" >Please find you invoice for <?php echo '"'.$aucname->title.'"';?></p></td>
  </tr>
  <tr>
    <td style=" background:#FFF;">
    	<div class="invoice-cont">
        	<div class="invoice-top">
            	<h3>INVOICE #<?php echo 'PML'.$aucid;?> </h3>
                <p><?php echo $node->title;?></p>
            </div>
            <div class="invoice-middle">
            	<div class="invoice-left">
                	<h4>Bill To: <?php echo $user->name;?></h4>
                    <p><?php echo $seller_dt->mail;?></p>
                    <p><?php echo $seller_dt->field_home_phone['und'][0]['value'];?></p>
                    <p><?php echo $seller_dt->field_address['und'][0]['name'];?></p>
                    <p><?php echo $seller_dt->field_address['und'][0]['street'];?><br/><?php echo $seller_dt->field_address['und'][0]['city'];?><br/><?php echo $seller_dt->field_address['und'][0]['postal_code'];?><br/><?php echo $seller_dt->field_address['und'][0]['country_name'];?></p>
                </div>
                <div class="invoice-right">
                	<h4><?php echo $term->name; ?></h4>
                        <h4>Accounting Contact: <?php echo $admin_dt->name;?></h4>
                    <p><?php echo $admin_dt->mail;?></p>
                    <p><?php echo $admin_dt->field_home_phone['und'][0]['value'].', '.$admin_dt->field_work_phone['und'][0]['value'];?></p>
                    <p><?php echo $admin_dt->field_address['und'][0]['name'];?></p>
                    <p><?php echo $admin_dt->field_address['und'][0]['street'];?></p>
                    <p><?php echo $admin_dt->field_address['und'][0]['city'];?></p>
                </div>
                <div class="invoice-details">  
                    <table class="sticky-enabled tableheader-processed sticky-table">
                    <thead><tr><th>Date</th><th>Title</th><th>Details</th><th>commission</th></tr></thead>
                    <tbody>
                    <?php 
                        foreach ($results as $value) {
                            $lotname = node_load($value->lot_id);
                            $commi = $value->hammer_price * $comm /100 ;
                           ?>
                        
                        <tr>
                            <td><?php echo date("m/d/Y", $value->created); ?></td>
                            <td><?php echo $lotname->title ; ?></td>
                            <td><?php echo $value->hammer_price.'x'.$comm.'%';?></td>
                            <td><?php echo $commi ; ?></td>
                        </tr>
                        <?php  $sum += $commi;?>
                        <?php } ?>

                    </tbody>
                    </table>
                                
                </div>
                </div>
                <div class="invoice-details">
                    <div class="pay-detail">
                    <?php echo  'Total current charges: '.$sum; ?>
                    </div>
       <?php echo "<span class='paypalicon'> <a href='" . $base_url . "/user/" . $user->uid . "/pay_bill'>To clear you balance click here</a> </span>";?>
                </div>
               
          
            </div>
        
        
     </div>
    
   	  
    </td>
  </tr>
  <tr>
    
    <td style="background:#1d1e22; height:50px;">
    	<p style="font-family:Arial, Helvetica, sans-serif; color:#FFF; font-size:12px; padding:10px 0 0 10px;">This invoice is generated by paimai-live.com as a service</p>
       
    </td>
    
    
  </tr>
</table>
