<div class="account-main"> 
<div class ="account-contact" ><h3>Accounting Contact</h3></div>
<!-- Start Contact Information --> 
    <div id = "contact-information">
        <b><?php echo $contact->name;?></b><br/>
        <?php echo $contact->email;?><br/>
        <?php echo $contact->phone;?><br/>
        <?php echo $contact->fax;?><br/><br/>
        <a class="main-btn" href="javascript:void(0);" onclick="jQuery('#contact-information').hide();jQuery('#contact-form').show();">Edit</a>
    </div>
<!-- End Contact Information --> 
<!-- Start Contact Form --> 
    <div id = "contact-form" style = "display: none;">
        <?php echo drupal_render(drupal_get_form(account_contact_form,$contact));?>
    </div>
<!-- End Contact Form --> 
</div>