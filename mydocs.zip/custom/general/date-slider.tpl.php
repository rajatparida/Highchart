<?php
/* 
Author:Emp-Id 1241;
Date:6/Sep/2013;
File:Template file for auction homepage date slider. 
*/ 
?>
<?php 
  global $base_path;
  global $base_url;
 drupal_add_js(drupal_get_path('module', 'general') . '/js/jquery.jcarousel.min.js');
?>
<!--CALENDAR-->
<div class=" jcarousel-skin-tango Calender_sec">
	<div style="position: relative; display: block;" class="jcarousel-container jcarousel-container-horizontal">
		<div style="position: relative;" class="jcarousel-clip jcarousel-clip-horizontal">
			<ul id="mycarousel"  class="jcarousel-list jcarousel-list-horizontal">
				<?php
					$all_active_class = 'active';
					$check_date = '';
                                        if(isset($_REQUEST['field_auction_start_time_value']['value']['date']) && $_REQUEST['field_auction_start_time_value']['value']['date']!='' ){
					 $check_date = $_REQUEST['field_auction_start_time_value']['value']['date'];
					}
                                        if($check_date!=''){	
						$all_active_class ='';	
					}
					$str = "<li class='first'> <a href='$base_url' class='$all_active_class date_slider_value'>All</a></li>";
					foreach($data as $data_date){
						$active_class= '';
						$class		= $data_date['class'];
						$class2='';
						if($class=='auction_date'){
							$class2 = 'date_slider_value';
						}
						$date_show 	= $data_date['show_date'];
						$date_re	= $data_date['check_date'];
						if($check_date == $date_re ){
						$active_class= 'active';
						}
						$str .=  "<li class='$class'><a class='$class2 $active_class' attr_sent_date='$date_re'>$date_show</a></li>"; 
					}
					print $str;
				?>
			</ul>
		</div>
	<div disabled="disabled" style="display: block;" class="jcarousel-prev jcarousel-prev-horizontal jcarousel-prev-disabled jcarousel-prev-disabled-horizontal">
	<img src='<?php print $base_url;?>/sites/all/themes/auction/images/btn_left.png'/>
	</div>
	<div style="display: block;" class="jcarousel-next jcarousel-next-horizontal">
		<img src='<?php print $base_url;?>/sites/all/themes/auction/images/btn_right.png'/>
	</div>
	</div>
</div>
<div class="clear"></div>
<script>
jQuery(document).ready(function() {
    jQuery('#mycarousel').jcarousel({
        start: 1,
        itemVisibleInCallback: {
            //onBeforeAnimation: highlight_current
        } 
    });
});
</script>