 <?php
/* 
Author:Emp-Id 1241;
Date:8/Aug/2013;
File:Template file for sellers auction console. 
*/ 
?>

<?php 
global $base_path;
global $base_url;
$theme_path = drupal_get_path('theme', variable_get('theme_default', NULL));
$imgpath=$base_path.$theme_path;
$count=1;
?>
<div class="inside_middlesec">
	<div class="inside_middlesec_left">
		<!-- left AuctionConsolePageSec -->
		<div class="AuctionConsolePageSec mrgn_b">
			<div class="AuctionConsolePageSecIns"> 
			<input type="hidden" id="bid-nid" value="<?php print $data[0]['nid']; ?>"/>
				<div class="AuctionConsolSldR flt pr">
					<div id="AuctionConsLrg<?php print $data[0]['lot']; ?>" style="top:0px; left:0px;">
					<p class="AuctionConsolSldRHDs">Lot<?php print $data[0]['lot']; ?>:
					<span><?php print $data[0]['title']; ?></span></p>
					<div class="AuctionImgLrg"><img src="<?php print $data[0]['big_img']; ?>" /></div>				 
					</div>
				</div>
				<div class="clear"></div>
				<?php if($data[0]['body']!=''){ ?>
				<div><textarea id="item-desc" style="resize:none;" rows="3" cols="57"><?php print $data[0]['body']; ?> </textarea></div>
				<?php } ?>
				<div class="ConsBidContr">
					<?php  for($i=1;$i<sizeof($data);$i++){
					?>
					<p class="AuctionConsolSldRHDs">Lot<?php print $data[$i]['lot']; ?>:
					<span><?php print $data[$i]['title']; ?></span></p>
					<?php } ?>
					<div class="clear"></div>
				</div>
			</div>
			<span class="set-img" style="float:right;margin-top: -50px;cursor:pointer;height:40px;width:40px;"><img src="<?php print $imgpath; ?>/images/set.png" /></span>
			<div id="qt-auc-set" style="display:none;">
			<?php	
			$quicktabs = quicktabs_build_quicktabs('seller_console'); // use your qt name here
			print render($quicktabs);
			?>
		</div>
		</div>
		<span style="display:none;" id="auid"><?php print arg(2);?></span>
		<!-- left AuctionConsolePageSec -->
		<div class="box_shadow Consbox_shadow"></div>
	</div>
	<div class="inside_middlesec_rightbid">
		<div class="sell-op" ><div id="bids-info">
			<?php

			?>	
			</div>		
			<div id="bids-info-detail" style="width:48%;float:left;padding:1%;" >
			</div><!-- consolePageContRHead -->
		</div >
			<div style="margin:2%"><textarea class="selop" style="resize:none;" rows="4" cols="51"></textarea></div>
			<div style="margin:2%">						
			</div>
			<div class="bid-span">
				<span class="ConsSelContrR flr"><?php print l('Close Soon','javascript:void(0);',array('external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn'),'id' => array('closesoon'))));	?></span>
				<span class="ConsSelContrR flr"><?php print l('Fair Warning','javascript:void(0);',array('external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn '),'id' => array('fairw'))));	?></span>
				<span class="ConsSelContrR flr"><?php print l('Last Call','javascript:void(0);',array('external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn '),'id' => array('lcall'))));	?></span>
				<span class="ConsSelContrR flr"><?php print l('Send Message','javascript:void(0);',array( 'external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn '),'id' => array('smesg'))));	?></span>
			</div>
			<div class="sell-bids"><p class="cbid">Bid Increment : $<input  style="float:right;margin-top: -2%; text-align: center; width: 32%;" type="text" id="ask_inc" value="<?php print round($data[0]['increase']);?>" /></p>
			<?php 
			$nexbid=round($data[0]['ask_bid']);
			?>	
	
			<h4 class="nbid"><span style="float:left;width:62%;">Current Ask : $</span><input  style="float:left;margin-top: -2%; text-align: center; width: 34%;" type="text" id="askamt" value="<?php print $nexbid;?>" /></h4>			<!-- consolePageContRHead -->
		</div>
		<div class="bid-span">
				<span class="ConsSelContrR lsold flr"><?php print l('Sold','javascript:void(0);',array( 'external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn'),'id' => array('lsold'))));	?></span>
				<span class="ConsSelContrR unsold flr"><?php print l('Unsold','javascript:void(0);',array( 'external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn'),'id' => array('unsold'))));	?></span>
				<span class="ConsSelContrR flr"><?php print l('Pass','javascript:void(0);',array('external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn lpass'))));	?></span>
				<span class="ConsSelContrR nexlot flr"><?php print l('Next Lot','javascript:void(0);',array('external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn'),'id' => array('nexlot'))));	?></span>
				<span class="ConsSelContrR nexlot-dis flr"><?php print l('Next Lot','javascript:void(0);',array('external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn'))));	?></span>
				<span class="ConsSelContrR ropen flr"><?php print l('Reopen','javascript:void(0);',array('external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn '),'id' => array('ropen'))));	?></span>
				<span class="ConsSelContrR rtrack flr"><?php print l('Retract','javascript:void(0);',array('external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn '),'id' => array('rtrack'))));	?></span>
				<span class="ConsSelContrR rtrack-dis flr"><?php print l('Retract','javascript:void(0);',array('external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn '),'id' => array('rtrack-dis'))));	?></span>
		</div>
		<input type="hidden" id="sdnid" value="<?php print $data[0]['nid'];?>" />
		<input type="hidden" id="sduid" value="<?php print $user->uid;?>" /> 
		<input type="hidden" id="sdtime" value="<?php print time();?>" /> 
		<input type="hidden" id="sauction" value="<?php print arg(2);?>" />
		<input type="hidden" id="snbid" value="<?php print round($data[0]['ask_bid']);?>" />
		<div class="bids-span">
		<span class="ConsSelContrR flr"><?php print l('Bids over Phone','javascript:void(0);',array('external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn pid'))));	?></span>
		<span class="ConsSelContrR flr"><?php print l('Bids over Floor','javascript:void(0);',array('external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn fpid'))));	?></span>
		<span class="ConsSelContrR inter flr"><?php print l('Internet','javascript:void(0);',array('external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn'),'id' => array('inter'))));	?></span>
		<span class="ConsSelContrR inters flr"><?php print l('Internet','javascript:void(0);',array('external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn '))));	?></span>
		</div>
		<div class="under_shadow_small"></div>
	</div>
	<div id="basic-modal-content-seller">
		<h4>Do you want to end this auction?</h4><br/>
		<div class="bid-span">
		<span style="margin-left: 18% !important;" class="ConsSelContrR flr"><?php print l('Yes','javascript:void(0);',array('external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn end-yes'))));	?></span>
		<span style="margin-left: 18% !important;" class="ConsSelContrR flr"><?php print l('No','javascript:void(0);',array('external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn end-no'))));	?></span>
		</div>
	</div>
	<div class="clear"></div>
</div>
<script>
var socket = new Pusher("d680c861255a911c2481");
var Pusher_Presence = socket.subscribe('test_channel_<?php echo arg(2);?>');

socket.bind('my_event',function(data)
{
	 
 if(data.sold_status=='bids'){
		    jQuery('#bids-info').append(data.bid_html);
			jQuery('#cbid').html(data.cbid);
			jQuery('#nbid').html(data.nbid);
	}
	else if(data.sold_status=='close'){
			jQuery('.selop').val(data.close_text);
	}
	else if(data.sold_status=='fair'){
			jQuery('.selop').val(data.fair_text);
	}
	else if(data.sold_status=='lcall'){
			jQuery('.selop').val(data.lcall_text);
	}
	else if(data.sold_status=='smesg'){
			jQuery('.selop').val(data.smesg_text);
	}
	else if(data.sold_status=='lsold'){
			jQuery('#bids-info-detail').append(data.sold_seller);
	}
	else if(data.sold_status=='nexlot'){

			jQuery('.AuctionImgLrg').fadeOut("slow", function(){
			  jQuery('.AuctionImgLrg').html(data.bigimg);
			  jQuery('.AuctionImgLrg').fadeIn("slow");
			});
			jQuery('.AuctionConsolSldRHDs').fadeOut("slow", function(){
			  jQuery('.AuctionConsolSldRHDs').html(data.head);
			  jQuery('.AuctionConsolSldRHDs').fadeIn("slow");
			});
			jQuery('.ConsBidContr').fadeOut("slow", function(){
			  jQuery('.ConsBidContr').html(data.headtitle);
			  jQuery('.ConsBidContr').fadeIn("slow");
			});
			jQuery('#askamt').val(data.ask_bid);
		    jQuery('#item-desc').val(data.body);
			jQuery('.cbid').html(data.cbid);
			jQuery('#bid-nid').val(data.nid);
			jQuery('#bids-info').empty();
	}
	else if(data.sold_status=='floor'){
				jQuery('#bids-info').append(data.bid_html);
				jQuery('.cbid').html(data.cbid);
				jQuery('#askamt').val(data.askamt);
	}
	else if(data.sold_status=='phone'){
				jQuery('#bids-info').append(data.bid_html);
				jQuery('.cbid').html(data.cbid);
				jQuery('#askamt').val(data.askamt);
	}
	else if(data.sold_status=='rtract'){
			jQuery('#bids-info').append(data.bid_html);
	}
	else if(data.sold_status=='endauction'){
			var url = Drupal.settings.basePath + 'user';   
			jQuery(location).attr('href',url);
	}
	else if(data.sold_status=='ropen'){

			jQuery('.AuctionImgLrg').fadeOut("slow", function(){
			  jQuery('.AuctionImgLrg').html(data.bigimg);
			  jQuery('.AuctionImgLrg').fadeIn("slow");
			});
			
			jQuery('.AuctionConsolSldRHDs').fadeOut("slow", function(){
			  jQuery('.AuctionConsolSldRHDs').html(data.head);
			  jQuery('.AuctionConsolSldRHDs').fadeIn("slow");
			});
			jQuery('#askamt').val(data.ask_bid);
			jQuery('.ConsBidContr').empty();
		    jQuery('#item-desc').val(data.body);
			jQuery('.cbid').html(data.cbid);
			jQuery('#bid-nid').val(data.nid);
			jQuery('#bids-info').empty();
	}

});
</script>