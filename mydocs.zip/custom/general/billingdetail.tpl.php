<?php
/*global $base_url;
global $user;
$node = node_load(arg(2));
$node1 = node_load(arg(3));
$auctionname = $node->title;
$package = $node->field_purchased_package[und][0][nid];
$lottitle = $node1->title;
$pkg =node_load($package);
$pack = $pkg->title;*/
//print_r($results);
global $user;
$uuid = user_load($user->uid);
//print_r($uuid);

$uuid->name;
$uuid->mail;
$uuid->field_home_phone['und'][0]['value'];
$uuid->field_work_phone['und'][0]['value'];
    

$aucid = $results[0]->auction_id;
$lotid = $results['lot_id'];
$bidderid = $results['user_id'];
$hammerprice = $results['hammer_price'];
$status = $results['paid'];
$aucname = node_load($aucid);
$lotname = node_load($lotid);
$biddername = user_load($bidderid);
$auctite = $aucname->title;
$aucpack = $aucname->field_purchased_package['und'][0]['nid'];
$pack = node_load($aucpack);
$packname = $pack->title;
$lotn = $lotname->title;
$bname=$biddername->name;
$disputem = dispute_message($aucid);
//echo $commi;

if($disputem == !NULL){
    $dis = $disputem;
}
else{
   $dis = 'Not in dispute';
}

if($status == 0){
    $paid  = 'Open';
} else {$paid  = 'Paid';}

?>
<?php 
foreach ($results as $value) {
$commi = $value->hammer_price ;
?>
<?php  $sum += $commi;?>
<?php } ?>
<?php $t_sum = $sum * $comm/100?>
<div><h3>Details of invoice</h3></div><br>
          <div class="billing">
               <div><strong></strong><?php echo $packname.' '.$aucid; ?> Sales commission</div><br>
               <div><strong><?php echo $sum.' x '.$comm.'%'.'='.$t_sum; ?></div><br>
               <!--<div><strong>Name:-- </strong><?php //echo $uuid->name; ?></div>
               <div><strong>Email:-- </strong><?php //echo $uuid->mail; ?></div>
               <div><strong>Phone:-- </strong><?php //echo $uuid->field_home_phone['und'][0]['value']; ?></div>
               <div><strong>Fax:-- </strong><?php //echo $uuid->field_work_phone['und'][0]['value']; ?></div>-->
          </div>



<?php
exit;?>

