<?php
/*
  Author:Emp-Id 1241;
  Date:6/Sep/2013;
  File:Template file for auction item page tabs.
 */
?>
<?php
global $base_url;
$node = node_load(arg(1));
$report = $node->field_auction_term['und'][0]['value'];
$nodedata = node_load($node->field_choose_auction['und'][0]['nid']);
$aucdate = $nodedata->field_auction_start_time['und'][0]['value'];
$auction_date = "";
if ($auction_date) {
    $auction_date = date('Y-m-d h:i a', $aucdate);
}
$est = 'Estimate &nbsp; $' . $node->field_low_estimate['und'][0]['value'] . ' - $' . $node->field_company['und'][0]['value'];
?>

<!-- tans firsrt -->
<?php
global $base_url;
global $user;
$theme_path = drupal_get_path('theme', variable_get('theme_default', NULL));
$imgpath = $base_url . "/" . $theme_path;
?>
<script src="<?php echo $base_url ?>/sites/all/themes/paimai_live/js/scrollbar.js"></script>
<link href="<?php echo $base_url ?>/sites/all/themes/paimai_live/css/scroll.css" type="text/css" rel="stylesheet">
<?php
//drupal_add_js(drupal_get_path('themes', 'paimai_live') . '/js/scrollbar.js');
drupal_add_css(drupal_get_path('themes', 'paimai_live') . '/css/scroll.css');


?>
<!--	save item module	-->
<?php /*
if (in_array('bidders', array_values($user->roles))) {
    ?><div style="width:200px;float:right;"><a id="saveitem" href="javascript:void(0)" >Save Item</a></div>
    <?php
}*/
?>
<!--	save item module	--> 
<div class="lot-tab">
    <div class="lot-tab-block"> <a href="#">Lot : <?php print $node->field_lot_no['und'][0]['value']; ?></a> </div>
    <div class="tabcont-1">
              <div id='mycustomscroll' class='flexcroll'>
                  <div class="info-lot">
                     <p><?php print $node->body['und'][0]['value']; ?></p>
                  </div>
                </div>
            </div>
</div>
<!-- <div class="lot-tab">
            <div class="lot-tab-block"> <a href="#">Lot No : <?php print $node->field_lot_no['und'][0]['value']; ?></a> </div>
            <div class="tabcont-1">
              <div id='mycustomscroll' class='flexcroll'>
                  <div class="info-lot">
                    <p><?php print $node->body['und'][0]['value']; ?></p>
                    
                  </div>
                </div>
            </div>
          </div> -->




<!--<h3><b>Lot No. :&nbsp;<?php // print $node->field_lot_no['und'][0]['value'];	  ?></b></h3>
<b>Description:</b>
<p><?php //print $node->body['und'][0]['value'];	  ?></p>-->

<div class="detail-main-tab">
    <div class="detail-tab-list">
        <ul>
            <li><a class="active" href="javascript:void(0)" id="tab5">Condition Report</a></li>
            <li ><a class="" href="javascript:void(0)" id="tab1">Auction Details</a></li>
            <li><a class="" href="javascript:void(0)" id="tab2">Terms &amp; Conditions</a></li>
            <li ><a class="" href="javascript:void(0)" id="tab4">Payment</a></li>
            <li><a class="" href="javascript:void(0)" id="tab3">Shipping</a></li>
        </ul>
    </div>
    <div id="tab_cont1" class="tab-inner-cont1" style="display: none;">
        <div class="tab-inner-cont1-left">
            <?php
// echo $node->field_choose_auction['und'][0]['nid'];
            $reqSql = "SELECT * FROM bid_increment WHERE auction_id='" . $node->field_choose_auction['und'][0]['nid'] . "'";
            $result = db_query($reqSql)->fetchAll();
            $currencyTaxo = taxonomy_term_load($nodedata->field_currency['und'][0]['tid']);
            if ($currencyTaxo->name) {
                $currency = $currencyTaxo->name;
            } else {
                $currency = 'CHF';
            }
//echo "<pre>";print_r($result);
            ?>
            <div class="table-cont">
                <table width="85%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td width="72" height="23" align="center" valign="top" class="upercase-text">Bid</td>
                        <td width="38">&nbsp;</td>
                        <td width="72" align="center" valign="top" class="upercase-text">Increments</td>
                    </tr>


       <!-- <tr>
          <td width="72" height="28" align="center" valign="top" class="upercase-text"><span>in CHF</span></td>
          <td>&nbsp;</td>
          <td width="72" align="center" valign="top" class="upercase-text"><span>in CHF</span></td>
        </tr> -->


                    <?php if (!empty($result[0]->range1)) {
                        ?>
                        <tr>
                            <td width="72" align="center" valign="top">
                                <div class="sap-div-box">0</div>
                                <div class="sap-div-box"><?php echo $result[0]->range1; ?></div>
                            </td>
                            <td align="center" valign="top"><img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt="" class="MT-10" /><br /> <img src="<?php echo $imgpath ?>/images/curly-break.gif" alt=""  class="MT-5" /></td>
                            <td valign="middle">
                                <div class="relative">
                                    <div class="sap-div-box"><?php echo $result[0]->range1_value; ?></div>
                                    <div class="sap-div-box pos-abs"><?php echo $result[0]->range2_value; ?></div>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                    <?php if (!empty($result[0]->range2)) {
                        ?>
                        <tr>
                            <td align="center" valign="top">
                                <?php if (!empty($result[0]->range2)) { ?> <div class="sap-div-box"><?php echo $result[0]->range2; ?></div><?php } ?>
                                <?php if (!empty($result[0]->range3)) { ?><div class="sap-div-box"><?php echo $result[0]->range3; ?></div><?php } ?>
                            </td>
                            <td align="center" valign="top">
                                <img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt="" class="MT-10" />
                                <?php if (!empty($result[0]->range3)) { ?>  <br /> <img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt=""  class="MT-5" /><?php } ?>
                            </td>
                            <td valign="middle">
                                <div class="relative">
                                    <div class="sap-div-box"><?php echo $result[0]->range3_value; ?></div>
                                    <?php if (!empty($result[0]->range4_value)) { ?> <div class="sap-div-box pos-abs"><?php echo $result[0]->range4_value; ?></div> <?php } ?>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                    <?php if (!empty($result[0]->range4)) {
                        ?>
                        <tr>
                            <td align="center" valign="top">
                                <?php if (!empty($result[0]->range4)) { ?> <div class="sap-div-box"><?php echo $result[0]->range4; ?></div> <?php } ?>
                                <?php if (!empty($result[0]->range5)) { ?>  <div class="sap-div-box"><?php echo $result[0]->range5; ?></div><?php } ?>
                            </td>
                            <td align="center" valign="top"><img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt="" class="MT-10" /><br /> <img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt=""  class="MT-5" /></td>
                            <td valign="middle">
                                <div class="relative">
                                    <?php if (!empty($result[0]->range5_value)) { ?>  <div class="sap-div-box"><?php echo $result[0]->range5_value; ?></div><?php } ?>
                                    <?php if (!empty($result[0]->range6_value)) { ?> <div class="sap-div-box pos-abs"><?php echo $result[0]->range6_value; ?></div><?php } ?>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                    <?php if (!empty($result[0]->range6)) {
                        ?>
                        <tr>
                            <td align="center" valign="top">
                                <?php if (!empty($result[0]->range6)) { ?> <div class="sap-div-box"><?php echo $result[0]->range6; ?></div><?php } ?>
                                <?php if (!empty($result[0]->range7)) { ?><div class="sap-div-box"><?php echo $result[0]->range7; ?></div><?php } ?>
                            </td>
                            <td align="center" valign="top"><img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt="" class="MT-10" /><br /> <img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt=""  class="MT-5" /></td>
                            <td valign="middle">
                                <div class="relative">
                                    <?php if (!empty($result[0]->range7_value)) { ?> <div class="sap-div-box"><?php echo $result[0]->range7_value; ?></div><?php } ?>
                                    <?php if (!empty($result[0]->range8_value)) { ?><div class="sap-div-box pos-abs"><?php echo $result[0]->range8_value; ?></div><?php } ?>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                    <?php if (!empty($result[0]->range8)) {
                        ?>
                        <tr>
                            <td align="center" valign="top">
                                <?php if (!empty($result[0]->range8)) { ?>  <div class="sap-div-box"><?php echo $result[0]->range8; ?></div><?php } ?>
                                <?php if (!empty($result[0]->range9)) { ?><div class="sap-div-box"><?php echo $result[0]->range9; ?></div><?php } ?>
                            </td>
                            <td align="center" valign="top"><img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt="" class="MT-10" /><br /> <img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt=""  class="MT-5" /></td>
                            <td valign="middle">
                                <div class="relative">
                                    <?php if (!empty($result[0]->range9_value)) { ?><div class="sap-div-box"><?php echo $result[0]->range9_value; ?></div><?php } ?>
                                    <?php if (!empty($result[0]->range10_value)) { ?><div class="sap-div-box pos-abs"><?php echo $result[0]->range10_value; ?></div><?php } ?>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                    <tr>
                        <td align="center" valign="top">
                            <?php if (!empty($result[0]->range10)) {
                                ?> <div class="sap-div-box"><?php echo $result[0]->range10; ?></div> <?php } ?>
                            <div class="height-auto sap-div-box">+</div>
                        </td>
                        <td align="center" valign="top">&nbsp;</td>
                        <td valign="middle">

                        </td>
                    </tr> 
                    <tr>
                        <td width="72">&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                </table>
            </div> 

        </div><!-- end of tab-inner-cont1-left  -->           











        <!-- <div class="bid-increment">
        <div class="bid-range">Bid</div>
    <div class="bid-increment1">Increments</div>
        <?php
        if (count($result) != 0) {
            ?>
            <div class="row">
                <div class="row-left first1"><?php echo $currency; ?> 0</div>
                <div class="row-right">&nbsp;</div>
            </div>
            <?php
            for ($i = 1; $i <= 10; $i++) {
                $range = 'range' . $i;
                $rangeValue = 'range' . $i . '_value';
                if ($result[0]->$rangeValue != "") {
                    ?>
                            
                            <div class="row">
                                <div class="row-left"><img alt="" src="<?php echo $base_url . '/sites/all/themes/auction/images/to-img.png'; ?>" /></div>
                                <div class="row-right"><span class="dollar"><?php echo $currency; ?></span><span class="edit1"><?php echo $result[0]->$rangeValue; ?></span></div>
                            </div>
                    <?php
                }
                if (($result[0]->$range) != $tempBidRange && $result[0]->$range != "") {
                    ?>
                            <div class="row">
                                <div class="row-left"><span class="dollar"><?php echo $currency; ?></span><span class="edit1"><?php echo $result[0]->$range; ?></span></div>
                                <div class="row-right">&nbsp</div>
                            </div>
                             
                    <?php
                } else {
                    ?>
                           <div class="row">
                                <div class="row-left"><span class="dollar"><?php echo $currency; ?></span><span class="edit1">+</span></div>
                                <div class="row-right">&nbsp</div>
                            </div>
                    <?php
                    break;
                }
                $tempBidRange = $result[0]->$range + 1;
            }
        }
        ?>
   


</div>-->

        <!-- Range Icrement --> 
        <!-- buyer_premium -->
        <div class="tab-inner-cont1-right">

            <?php
            $bpSql = "SELECT * FROM  buyer_premium WHERE auction_id='" . $node->field_choose_auction['und'][0]['nid'] . "'";
            $bpResult = db_query($bpSql)->fetchObject();  //echo "<pre>"; print_r($bpResult); 
            ?>

            <h3>Buyer's Premium : <span><?php echo $bpResult->bp_range1_value; ?></span></h3>
            <div class="table-cont">
                <table width="85%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td width="72" height="23" align="center" valign="top" class="upercase-text">Bid</td>
                        <td width="38">&nbsp;</td>
                        <td width="72" align="center" valign="top" class="upercase-text">Increments</td>
                    </tr>


       <!-- <tr>
          <td width="72" height="28" align="center" valign="top" class="upercase-text"><span>in CHF</span></td>
          <td>&nbsp;</td>
          <td width="72" align="center" valign="top" class="upercase-text"><span>in CHF</span></td>
        </tr>
                    -->  



                    <tr>
                        <td width="72" align="center" valign="top">
                            <div class="sap-div-box">0</div>
                            <?php if (!empty($bpResult->bp_range1)) { ?> <div class="sap-div-box"><?php echo $bpResult->bp_range1; ?></div> <?php } ?>
                        </td>
                        <td align="center" valign="top">
                            <img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt="" class="MT-10" />
                            <?php if (!empty($bpResult->bp_range2)) { ?>    <br /> <img src="<?php echo $imgpath ?>/images/curly-break.gif" alt=""  class="MT-5" /><?php } ?>
                        </td>
                        <td valign="middle">
                            <div class="relative">
                                <?php if (!empty($bpResult->bp_range1_value)) { ?> <div class="sap-div-box"><?php echo $bpResult->bp_range1_value; ?></div> <?php } ?>
                                <?php if (!empty($bpResult->bp_range2_value)) { ?> <div class="sap-div-box pos-abs"><?php echo $bpResult->bp_range2_value; ?></div><?php } ?>
                            </div>
                        </td>
                    </tr>

                    <?php if (!empty($bpResult->bp_range2)) { ?>
                        <tr>
                            <td align="center" valign="top">
                                <?php if (!empty($bpResult->bp_range2)) { ?>   <div class="sap-div-box"><?php echo $bpResult->bp_range2; ?></div><?php } ?>
                                <?php if (!empty($bpResult->bp_range3)) { ?>  <div class="sap-div-box"><?php echo $bpResult->bp_range3; ?></div><?php } ?>
                            </td>
                            <td align="center" valign="top"><img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt="" class="MT-10" /><br /> <img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt=""  class="MT-5" /></td>
                            <td valign="middle">
                                <div class="relative">
                                    <?php if (!empty($bpResult->bp_range3_value)) { ?> <div class="sap-div-box"><?php echo $bpResult->bp_range3_value; ?></div><?php } ?>
                                    <?php if (!empty($bpResult->bp_range4_value)) { ?><div class="sap-div-box pos-abs"><?php echo $bpResult->bp_range4_value; ?></div><?php } ?>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                    <?php if (!empty($bpResult->bp_range4)) { ?>
                        <tr>
                            <td align="center" valign="top">
                                <?php if (!empty($bpResult->bp_range4)) { ?><div class="sap-div-box"><?php echo $bpResult->bp_range4; ?></div><?php } ?>
                                <?php if (!empty($bpResult->bp_range5)) { ?><div class="sap-div-box"><?php echo $bpResult->bp_range5; ?></div><?php } ?>
                            </td>
                            <td align="center" valign="top"><img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt="" class="MT-10" /><br /> <img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt=""  class="MT-5" /></td>
                            <td valign="middle">
                                <div class="relative">
                                    <?php if (!empty($bpResult->bp_range5_value)) { ?><div class="sap-div-box"><?php echo $bpResult->bp_range5_value; ?></div><?php } ?>
                                    <?php if (!empty($bpResult->bp_range6_value)) { ?><div class="sap-div-box pos-abs"><?php echo $bpResult->bp_range6_value; ?></div><?php } ?>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                    <?php if (!empty($bpResult->bp_range6)) { ?>
                        <tr>
                            <td align="center" valign="top">
                                <?php if (!empty($bpResult->bp_range6)) { ?><div class="sap-div-box"><?php echo $bpResult->bp_range6; ?></div><?php } ?>
                                <?php if (!empty($bpResult->bp_range7)) { ?><div class="sap-div-box"><?php echo $bpResult->bp_range7; ?></div><?php } ?>
                            </td>
                            <td align="center" valign="top"><img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt="" class="MT-10" /><br /> <img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt=""  class="MT-5" /></td>
                            <td valign="middle">
                                <div class="relative">
                                    <?php if (!empty($bpResult->bp_range7_value)) { ?> <div class="sap-div-box"><?php echo $bpResult->bp_range7_value; ?></div><?php } ?>
                                    <?php if (!empty($bpResult->bp_range8_value)) { ?> <div class="sap-div-box pos-abs"><?php echo $bpResult->bp_range8_value; ?></div><?php } ?>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                    <?php if (!empty($bpResult->bp_range8)) { ?>
                        <tr>
                            <td align="center" valign="top">
                                <?php if (!empty($bpResult->bp_range8)) { ?><div class="sap-div-box"><?php echo $bpResult->bp_range8; ?></div><?php } ?>
                                <?php if (!empty($bpResult->bp_range9)) { ?><div class="sap-div-box"><?php echo $bpResult->bp_range9; ?></div><?php } ?>
                            </td>
                            <td align="center" valign="top"><img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt="" class="MT-10" /><br /> <img src="<?php echo $imgpath; ?>/images/curly-break.gif" alt=""  class="MT-5" /></td>
                            <td valign="middle">
                                <div class="relative">
                                    <?php if (!empty($bpResult->bp_range9_value)) { ?><div class="sap-div-box"><?php echo $bpResult->bp_range9_value; ?></div><?php } ?>
                                    <?php if (!empty($bpResult->bp_range10_value)) { ?><div class="sap-div-box pos-abs"><?php echo $bpResult->bp_range10_value; ?></div><?php } ?>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                    <tr>
                        <td align="center" valign="top">
                            <?php if (!empty($bpResult->bp_range10)) { ?><div class="sap-div-box"><?php echo $bpResult->bp_range10; ?></div><?php } ?>
                            <div class="height-auto sap-div-box">+</div>
                        </td>
                        <td align="center" valign="top">&nbsp;</td>
                        <td valign="middle">

                        </td>
                    </tr>
                    <tr>
                        <td width="72">&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                </table>
            </div> 
        </div>







        <!--
         <div class="bid-increment">
                <div class="Buyer-range">Buyer's Premium </div>
            
        <?php
        $bpSql = "SELECT * FROM  buyer_premium WHERE auction_id='" . $node->field_choose_auction['und'][0]['nid'] . "'";
        $bpResult = db_query($bpSql)->fetchObject();
        if (db_query($bpSql)->rowCount() != 0) {
            ?>
                    
            <?php
            $tempRange = "";
            if ($bpResult->bp_range2_value != "") {
                ?><div class="row">
                                <div class="row-left first1"><?php echo $currency; ?> 0</div>
                                <div class="row-right">&nbsp;</div>
                            </div>
                <?php
                for ($i = 1; $i <= 3; $i++) {
                    $bpRange = 'bp_range' . $i;
                    $bprangeValue = 'bp_range' . $i . '_value';
                    if ($bpResult->$bprangeValue != "") {
                        ?>
                                                <div class="row">
                                                    <div class="row-left"><img alt="" src="<?php echo $base_url . '/sites/all/themes/auction/images/to-img.png'; ?>" /></div>
                                                    <div class="row-right"><span class="dollar"><?php echo $currency; ?></span><span class="edit1"><?php echo $bpResult->$bprangeValue . '%'; ?></span></div>
                                                </div>
                        <?php
                    }
                    if (($bpResult->$bpRange) != $tempRange && $bpResult->$bpRange != "") {
                        ?>
                                                <div class="row">
                                                    <div class="row-left"><span class="dollar"><?php echo $currency; ?></span><span class="edit1"><?php echo $bpResult->$bpRange; ?></span></div>
                                                    <div class="row-right">&nbsp</div>
                                                </div>
                        <?php
                    } else {
                        ?>
                                                <div class="row">
                                                    <div class="row-left"><span class="dollar"><?php echo $currency; ?></span><span class="edit1">+</span></div>
                                                    <div class="row-right">&nbsp</div>
                                                </div>
                                        
                        <?php
                        break;
                    }
                    $tempRange = $bpResult->$bpRange + 1;
                }
                ?>
                <?php
            } else {
                ?>
                                    <div class="first-range">:<?php echo $bpResult->bp_range1_value; ?>%</div>
                <?php
            }
        }
        ?>
           
        </div>-->
        <!-- buyer_premium -->				
        <div class="clear"></div>
    </div>

    <div style="display:none;" id="tab_cont2" class="tab-inner-cont1">
        <?php print $nodedata->field_auction_term['und'][0]['value']; ?>
    </div>
    <div style="display: none;" id="tab_cont3" class="tab-inner-cont1">
        <?php print $node->field_shipping['und'][0]['value']; ?>

    </div>
    <div style="display: none;" id="tab_cont4" class="tab-inner-cont1">
        Accepted payment methods<br/>
        <?php
        if (isset($nodedata->field_payment_options[$nodedata->language])) {
            foreach ($nodedata->field_payment_options[$nodedata->language] as $payment) {
                $paymentOptions = taxonomy_term_load($payment['tid']);
                echo '<img src="' . file_create_url($paymentOptions->field_pm_image[$nodedata->language][0]['uri']) . '" alt="' . $paymentOptions->name . '" title="' . $paymentOptions->name . '"/>&nbsp;';
            }
        }
        ?>
    </div>
    <div style="display: block;" id="tab_cont5" class="tab-inner-cont1">
        <?php print $report; ?>
    </div>

</div>



<!-- tabs second-->
<!--<div class="tab_sec" id='auction-product-slider'>
    <h4 class="slider_2_heading">Similar Items from this auctioneer</h4>
    <div class="slider2">
        <div class="flexslider2 carousel">
                <div class="flex-viewport">
<?php //print $data['bottom_slider'];  ?> 
                </div>
        </div>
        </div>
</div>					-->

