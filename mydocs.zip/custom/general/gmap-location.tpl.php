<?php
/* 
Author:Emp-Id 1241;
Date:6/Sep/2013;
File:Template file for auction section google map. 
*/ 
?>
<?php 
	drupal_add_css(drupal_get_path('module', 'general') . '/css/gmap.css', array('group' => CSS_DEFAULT, 'every_page' => false));
	drupal_add_js('http://maps.google.com/maps/api/js?sensor=false','external');
	drupal_add_js(drupal_get_path('module', 'general') . '/js/jquery.gmap.js');
	global $base_path;
	$imgurl= $base_path.'/sites/all/themes/auction/images/marker.png.png';
?>
<div class='message'><?php print $data['message'];?></div>
<div id="map_addresses-<?php print $data['mapid'];?>" class="auction-gmap">
    <p>This will be replaced with the Google Map.</p>
</div>
<!--
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.6.1.min.js"></script>
<script type="text/javascript" src="jquery.gmap.js"></script> -->
<?php if(isset($data['data']) && count($data['data'] >=0)){
?>
<script type="text/javascript" charset="utf-8">
jQuery(function()
{
   jQuery('#map_addresses-<?php print $data['mapid'];?>').gMap({
     zoom: 8,
	 	 	icon: {
			image: <?php print '"'.$imgurl.'"' ?>,
			shadow: "http://www.google.com/mapfiles/shadow50.png",
			iconsize: [50, 54],
			shadowsize: [37, 34],
			iconanchor: [9, 34],
			shadowanchor: [6, 34]
		},
		markers:[
			<?php foreach($data['data'] as $location_data) { ?>
			{
				latitude:<?php print $location_data['latitude'] ?>,
				longitude:<?php print $location_data['longitude'] ?>,
				html:<?php print '"'.$location_data['marker'].'"' ?>
			},
			<?php } ?>
			
		]
    });

	
});
</script>
<?php } ?>