<?php
// Include pusher library
	require_once('Pusher.php');

	// Define constants for the pusher api info
	define('PUSHER_API_KEY', 'd680c861255a911c2481');
	define('PUSHER_API_SECRET', 'e99ed25bb62ceba25a04');
	define('PUSHER_APP_ID', '51311');
	
	// Creating a connection to Pusher for other files to use
	$_pusher = new Pusher(PUSHER_API_KEY, PUSHER_API_SECRET, PUSHER_APP_ID);
	
