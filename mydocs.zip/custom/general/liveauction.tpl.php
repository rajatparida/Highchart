 <?php
/* 
Author:Emp-Id 1241;
Date:8/Aug/2013;
File:Template file for Bidders auction console. 
*/ 
?>

<?php 
  global $base_path;
  global $base_url;
  global $user;
  $theme_path = drupal_get_path('theme', variable_get('theme_default', NULL));
  $imgpath=$base_path.$theme_path;
  $count=1;
?>
<script type="text/javascript" charset="utf-8">
 WebSocket.__swfLocation = "js/WebSocketMain.swf";
</script>
 <div class="inside_middlesec">
            	<div class="inside_middlesec_left">
                	<!-- left AuctionConsolePageSec -->
                    <div class="AuctionConsolePageSec mrgn_b">
                         <div class="AuctionConsolePageSecIns"> 
                             <div id="auc-thumb" class="AuctionConsolSldL flt">
							 <?php  foreach($data as $auction_data){ ?>
						
						<div class="thumbnail-item">
						<a href="#"><div class="AuctionConsolSldLImgSml redBdeAct" id="AuctionConsSmls<?php print $auction_data['lot']; ?>" ><img class="thumbnail" src="<?php print $auction_data['small_img']; ?>" /></div></a>
						<div class="tooltip">
						<img class="thumbnail" src="<?php print $auction_data['hover_image']; ?>" />
						<span class="overlay"></span>
						</div> 
						</div> 
						<?php } ?>
                              </div>
                       <div style="display:none;" id="bid-nid"><?php print $data[0]['nid']; ?></div>
      
                       <div id="auc-live-big" class="AuctionConsolSldR flt pr">
                               <div id="AuctionConsLrg<?php print $data[0]['lot']; ?>" style="top:0px; left:0px;">
                                <p class="AuctionConsolSldRHDs">Lot<?php print $data[0]['lot']; ?>:
								<span><?php print $data[0]['title']; ?></span></p>
								<div class="AuctionConsolSldRImgLrg"><img src="<?php print $data[0]['big_img']; ?>" /></div>
								<div class="consInfoIcon pa"><a href="#"><img src="<?php print $imgpath ; ?>/images/infoIcon.png" width="21" height="22" border="0"/></a></div>					 
                                  </div>
                                  
                             </div>
                             
                             
                             <div class="clear"></div>
                             
                             <div class="ConsBidContr">
                                  <span style="float:left;" class="consInptL flt">Lot <?php print $data[0]['lot']; ?></span>
					
							<div class="bid-right" style="float:right;">
							<?php  
							$askbid=array();
                          echo '<input name="" type="text" class="consInptR flt" value="$"/>';
						  echo '<input name="" type="text" class="consInptR flt" value="0"/>';	

							$curbid = str_split($data[0]['high_bid']);?>
								<p style="float:right;margin:0 !important;"><?php foreach($curbid as $curbid_data){ 
								echo '<input name="" type="text" class="consInptR flt" value="'.$curbid_data.'"/>';	
							  }
							  ?></p>
                               </div>  
                              <div class="clear"></div>  
								<?php
									$askbid=round($data[0]['ask_bid']);
													
								?>
								   <div class="ConsSelContrR flr">
								  <?php
								  global $user;
									if($user->uid == 0){
									
									   $link = l('Sign in to Bid','user/login',array('attributes' => array('class' => array('ConsSelContrRBtn'))));
										}
									else{
										$bidder=$user->uid;
										$bidder_id=live_auction_bidder_status($bidder,arg(1));
										if($bidder_id!=''){
											$link= l('BID $'.$askbid,'javascript:void(0);',array('external' => TRUE,'attributes' => array('class' => array('ConsSelContrRBtn'),'id' => array('nextbid'))));

											print '<span id="ask-bid" style="display:none;">'.round($data[0]['ask_bid']).'</span>';
										}
										else{
												$link = l('Register For This Auction','register/auction/'.arg(1),array('attributes' => array('class' => array('ConsSelContrRBtn'))));		
										}
											
									}
								 print $link;
								  ?>
								  
								  </div>
								  <div class="clear"></div>
                             </div>
                         </div>
                    </div>
                	<!-- left AuctionConsolePageSec -->
                  <div class="box_shadow Consbox_shadow"></div>
			<input type="hidden" id="dnid" value="<?php print $data[0]['nid'];?>" />
			<input type="hidden" id="damt" value="<?php print $askbid;?>" /> 
			<input type="hidden" id="oldamt" value="<?php print round($data[0]['high_bid']);?>" /> 
			<input type="hidden" id="duid" value="<?php print $user->uid;?>" /> 
			<input type="hidden" id="high_uid" value="<?php print $data[0]['high_uid'];?>" /> 
			<input type="hidden" id="dtime" value="<?php print time();?>" />
         <input type="hidden" id="bid-aid" value="<?php print arg(1);?>" /> 			
                </div>
             <div class="inside_middlesec_right">
                	<div class="right_sec_block">
						<?php 
						$nexbid=round($data[0]['ask_bid']);
						?>
		              	<h4  class="aucSolCol padtopaucSolCol">Lot <?php print $data[0]['lot'];?> Opened, ask $<span  id="lbid"><?php print $nexbid;?></span></h4>
						<div id="bid-info">

                       </div>						
                    </div>
                    <div class="under_shadow_small"></div>
                    
                    
                </div>
			 <div id="basic-modal-content">
				<h5>The Seller has paused the auction for a break.</h5>
				<h5>Auction will resume after few minutes.</h5>
			 </div>
                <div class="clear"></div>
		   </div>
<script>
var socket = new Pusher("d680c861255a911c2481");
var Pusher_Presence = socket.subscribe('test_channel_<?php echo arg(1);?>');

socket.bind('my_event',function(data)
{
  		if(data.sold_status=='close'){
			jQuery('#bid-info').append(data.close_soon);
		}
		else if(data.sold_status=='fair'){
			jQuery('#bid-info').append(data.fair);
		}
		else if(data.sold_status=='lcall'){
			jQuery('#bid-info').append(data.lcall);
		}
		else if(data.sold_status=='smesg'){
			jQuery('#bid-info').append(data.smesg);
		}
		else if(data.sold_status=='lsold'){
			jQuery('#bid-info').append(data.sold_bidder);
		}
		else if(data.sold_status=='bids'){
			jQuery('#bid-info').append(data.bid_html);
		    jQuery('.bid-right').html(data.bid_sell_html);
			jQuery('#nextbid').html(data.nextbid);
			jQuery('#lbid').html(data.lbid);
			jQuery('#damt').val(data.askamt);
			jQuery('#high_uid').val(data.high_uid);
		}
		else if(data.sold_status=='floor'){
			jQuery('#bid-info').append(data.bid_html);
		    jQuery('.bid-right').html(data.bid_sell_html);
			jQuery('#nextbid').html(data.nextbid);
			jQuery('#lbid').html(data.lbid);
			jQuery('#damt').val(data.askamt);
		}
		else if(data.sold_status=='phone'){
			jQuery('#bid-info').append(data.bid_html);
		    jQuery('.bid-right').html(data.bid_sell_html);
			jQuery('#nextbid').html(data.nextbid);
			jQuery('#lbid').html(data.lbid);
			jQuery('#damt').val(data.askamt);
		}
		else if(data.sold_status=='rtract'){
			jQuery('#bid-info').append(data.bid_html);
		}
		else if(data.sold_status=='nexlot'){
	
			jQuery('.AuctionConsolSldRHDs').html(data.head);
			jQuery('#nextbid').html(data.nextbid);
			jQuery('#lbid').html(data.lbid);
			jQuery('#damt').val(data.ask_bid);
			jQuery('#auc-thumb').fadeOut("slow", function(){
			  jQuery('#auc-thumb').html(data.auc_thumb);
			  jQuery('#auc-thumb').fadeIn("slow");
			});
			jQuery('#AuctionConsolSldRImgLrg').fadeOut("slow", function(){
			  jQuery('#AuctionConsolSldRImgLrg').html(data.bigimg);
			  jQuery('#AuctionConsolSldRImgLrg').fadeIn("slow");
			});
			jQuery('.bid-right').fadeOut("slow", function(){
			  jQuery('.bid-right').html(data.bid_sell_html);
			  jQuery('.bid-right').fadeIn("slow");
			});	
			jQuery('.consInptL').html('Lot' + data.lotnum);			
		}
		else if(data.sold_status=='pause'){
			jQuery('#basic-modal-content').modal();		
		}
		else if(data.sold_status=='start'){
			jQuery('.page-live-auction .simplemodal-close').trigger('click');		
		}
		else if(data.sold_status=='endauction'){
			var url = Drupal.settings.basePath + 'user';   
			jQuery(location).attr('href',url);
		}
		else if(data.sold_status=='ropen'){
	
			jQuery('.AuctionConsolSldRHDs').html(data.head);
			jQuery('#nextbid').html(data.nextbid);
			jQuery('#lbid').html(data.lbid);
			jQuery('#damt').val(data.ask_bid);
			jQuery('#AuctionConsolSldRImgLrg').fadeOut("slow", function(){
			  jQuery('#AuctionConsolSldRImgLrg').html(data.bigimg);
			  jQuery('#AuctionConsolSldRImgLrg').fadeIn("slow");
			});
			jQuery('.bid-right').fadeOut("slow", function(){
			  jQuery('.bid-right').html(data.bid_sell_html);
			  jQuery('.bid-right').fadeIn("slow");
			});	
			jQuery('.consInptL').html('Lot' + data.lotnum);
			jQuery('#bid-info').empty();
			
		}
	
});
</script>
