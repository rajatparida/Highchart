<?php
global $base_url;
?><div class="seller-dash">
        <h3>Seller Dashboard</h3>
      </div>
<div class="seller-auction">

    <div class="cover-image">
        <div class="view-lot">
            <h3><?php echo $auction; ?></h3>
        </div>
        <div class="cover-cont">

            <?php
            if (count($lots) == 0):
                echo '<div class="request-inner"><div class="live-items"><div class="recent-lot"><h3>No any images uploaded for this Auction. </h3></div></div></div>';
                echo "<a href='javascript:void(0);' onclick='history.go(-1);' class='btn-black'>Back</a>";
            else:
                ?>     
                <form action = "<?php echo url('user/' . arg(1) . '/cover_image/' . arg(3) . '/submit'); ?>" method="post">
                    <div class="request-inner">
                        <div class="live-items"> 
                            <div class="recent-lot">
                            <?php
                            $i = 0;
                            $k = 0;
                            foreach ($lots as $lot):
                                 if(!file_exists($lot->uri)) {
                                      $img_src = $base_url."/sites/default/files/noimage.jpg";
                                     
                                 }
                                 else {
                                     $img_src = file_create_url($lot->uri);
                                    
                                 }
                                  $altval = $lot->node_title;
                                  
                                echo '<div class="lot1-cont"> <div class="lot1-left"><a href="'.url("node/".$lot->nid).'"> <img alt ="'.$altval.'" title="'.$altval.'" src="' . $img_src . '" width="115" height="90"/></a></div><div class="lot1-right">';
                                if (in_array($lot->uri, $images)):
                                    echo '<input type="checkbox" name="check[' . $lot->nid . '][]" value="' . $lot->uri . '" checked="checked"/>';
                                else:
                                    echo '<input type="checkbox" name="check[' . $lot->nid . '][]" value="' . $lot->uri . '"/>';
                                endif;
                                echo $lot->node_title . ' <b>(' . $lot->nid . ')</b></div></div>';
                            endforeach;
                            ?>
                            </div>
                        </div> <!-- end of live items -->
                    </div> <!-- request inner ends here -->
                    <div class="view-image"> 
                        <input type="submit" name ="submit" value ="Submit" class=""/>
                        <input type="button" name ="cancel" value ="Cancel" onclick ="history.go(-1);" class="" />  </div>
                </form>
            <?php
            endif;
            ?>


        </div>
    </div>
</div>
<script>
                        jQuery(document).ready(function() {
                            if (jQuery("input[type=checkbox]:checked").length >= 5) {
                                jQuery('input[type=checkbox]').not(':checked').attr("disabled", true);
                            }
                            jQuery("input[type=checkbox]").click(function() {
                                var countchecked = jQuery("input[type=checkbox]:checked").length;
                                if (countchecked >= 5)
                                {
                                    jQuery('input[type=checkbox]').not(':checked').attr("disabled", true);
                                } else {
                                    jQuery('input[type=checkbox]').not(':checked').attr("disabled", false);
                                }
                            });
                        });
</script>