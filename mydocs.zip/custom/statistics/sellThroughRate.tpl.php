<?php 
global $base_url, $user; ?>
<div class="graph-cont">
	<input type="hidden" id="avg_price" value="0">
	<h3>Sell Through Rate</h3> 
<?php $sellThroughRate->printScripts();?>
<div id="sellThroughRate"></div> 
<script type="text/javascript"><?php echo $sellThroughRate->render();?></script>
</div>


