<?php
global $base_url; 
$chart->printScripts();?>
<div id="container"></div>
<script type="text/javascript"><?php echo $chart->render();?></script>
<!--h1 align="center">Hourly Basis</h1-->
<?php $dailychart->printScripts();?>
<div id="container1"></div>
<script type="text/javascript"><?php echo $dailychart->render();?></script>

<div class="count-visitor"><?php echo 'Total Pageviews:- '. $totalpageview;?></div>
<div class="count-visitor"><?php echo 'Total Visitors:- '. $unique_visitors;?></div>

<!--h1 align="center">Referal Url</h1-->
<?php $referalurl->printScripts();?>
<div id="container2"></div>
<script type="text/javascript"><?php echo $referalurl->render();?></script>

<!--h1 align="center">Top 20 Lots </h1-->
<?php $bubblechart->printScripts();?>
<div id="container3"></div>
<script type="text/javascript"><?php echo $bubblechart->render();?></script>


<!--h1 align="center">Sale performance of the recent auctions </h1-->
<?php $dual->printScripts();?>
<div id="container4"></div>
<script type="text/javascript"><?php echo $dual->render();?></script>
<!-- DISPLAYING COUNTRY WISE REGISTER USERS -->
<div class="country-users" style="float:left;">
<div style="float:left;">  
	<table class=""> 
		<tr> 
			<th colspan="3">Country</th> 
			<th>Registration</th> 
		</tr>  
		<?php   
		foreach ($register_bidders as  $value) { ?> 
		<tr> 
			<td><?php echo '<img src="'.$base_url.'/sites/default/files/flags/'.$value->country.'.png" height="32">';?></td> 
			<td>&nbsp;</td>
			<td><?php echo $value->country_name ?></td>
			<td><?php echo $value->users ?></td>
		</tr>  
		<?php }  ?> 
	</table> 
</div> 
<div style="float:left;"><?php echo embed_googlemap();?></div> 
</div>
<!-- DISPLAYING CURRENT VISITORS -->
<div style="float:left;"><h2>Current Visitor : <?php echo $current_visitor;?></h2></div> 