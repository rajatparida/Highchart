<?php global $base_url, $user;?>
 <div class="graph-cont">
 	<h3>Average Hammer Price</h3> 
<?php $averageHammerPrice->printScripts();?>
<div id="averageHammerPrice"></div> 
<script type="text/javascript">
<?php echo $averageHammerPrice->render();?></script>
</div>