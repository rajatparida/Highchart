<?php 

global $base_url, $user;
//print_r(user_load(151));
 ?>
<script type="text/javascript">
.upcom-auction{ 
	background: none repeat scroll 0 0 #3E3E41;
    color: #FFFFFF;
    font-size: 16px;
    height: 19px;
    margin: 0;
    padding: 6px; }
</script>
<div class="graph-cont">
	<h3>Upcoming Auction</h3> 
<?php $record->printScripts();?>
<div id="uauction"></div>

<script type="text/javascript"><?php echo $record->render();?></script>
</div>


