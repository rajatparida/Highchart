<?php // print_r($rows);?>
<div class="search-main">
    <div class="search-filter"><?php print render($filter_form)?></div>
    <?php foreach($rows as $lot)
    {
        ?>
	
        <div class="auction1">
                    	<div class="black-bg"></div>
                        <div class="auction-img">
                        	<a href="lot-page-auction-details.html"><img alt="" src="http://beta.paimai-live.com/site/images/auction1.jpg" width="285"></a>
                            <div class="country-icon"><img alt="" src="images/country-logo.jpg"></div>
                        </div>
                      <div class="auction-desc">
                        	<p><a href="catalog.html"><?php echo $lot['data']['lot_title'] ?></a></p>
                            <div class="frame-left">
                            	<p>Asiatica Asiatica</p>
                                <h5>06:45 Dec 31</h5>
                            	
                            </div>
                            <div class="frame-right">
                            	<div class="frame-top"><a class="bid-now" href="lot-page-auction-details.html"><img alt="" src="images/bid-icon.png">BID NOW</a></div>
                                <div class="frame-middle">2 months 1 week</div>
                          </div>
                        </div>
                  </div>
        
        
        
        <?php
    }
    ?>
	
	<div class="search-pager"><?php echo $paging;?></div>
</div>
