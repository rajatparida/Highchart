1. Enable the Module "paimai search"

2. Configure the search setting - 
/admin/config/search/settings

	ACTIVE SEARCH MODULES

	   Need to check the checkbox - "Paimai Search"
		
	Default search module

	   Need to choose option "Paimai Search"
   
3. Save the Configuration


