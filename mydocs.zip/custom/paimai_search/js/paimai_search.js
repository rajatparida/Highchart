jQuery(document).ready(function() {        
    base_url = Drupal.settings.basePath;
     jQuery('#edit-type').change(function(){                                 
        this.form.submit();
    }); 
     jQuery('#edit-category').change(function(){                        
        this.form.submit();       
    }); 
     jQuery('#edit-auctioneers').change(function(){                        
        this.form.submit();       
    }); 
     jQuery('#edit-countries').change(function(){                        
        this.form.submit();       
    }); 
    
     jQuery('#field_category_tid').change(function(){                                
        //this.form.submit();
       cat_id = jQuery("#field_category_tid").val(); 
       uid_id = jQuery("#uid").val(); 
       cout_id = jQuery("#country").val(); 
       window.location.href="auction-product?field_category_tid="+cat_id+"&uid=&country="+cout_id+"&field_auction_start_time_value[value][date]=";
    }); 
    jQuery('#uid').change(function(){                                 
      cat_id = jQuery("#field_category_tid").val();
      uid_id = jQuery("#uid").val(); 
      cout_id = jQuery("#country").val(); 
      window.location.href="auction-product?field_category_tid="+cat_id+"&uid="+uid_id+"&country="+cout_id+"&field_auction_start_time_value[value][date]=";
    }); 
    jQuery('#country').change(function(){                                
       cat_id = jQuery("#field_category_tid").val(); 
       uid_id = jQuery("#uid").val(); 
       cout_id = jQuery("#country").val(); 
       window.location.href="auction-product?field_category_tid="+cat_id+"&uid="+uid_id+"&country="+cout_id+"&field_auction_start_time_value[value][date]="; 
    }); 
    //past block 
    
         jQuery('#field_category_tidpast').change(function(){                                
        //this.form.submit();
       cat_id = jQuery("#field_category_tidpast").val(); 
       uid_id = jQuery("#uidpast").val(); 
       cout_id = jQuery("#countrypast").val(); 
       window.location.href="past-auctions?field_category_tid="+cat_id+"&uid=&country="+cout_id+"&pastauctiondate=";
    }); 
    jQuery('#uidpast').change(function(){                                 
      cat_id = jQuery("#field_category_tidpast").val();
      uid_id = jQuery("#uidpast").val(); 
      cout_id = jQuery("#countrypast").val(); 
      past_date = jQuery("#datepicker").val(); 
      window.location.href="past-auctions?field_category_tid="+cat_id+"&uid="+uid_id+"&country="+cout_id+"&pastauctiondate="+past_date;
    }); 
    jQuery('#countrypast').change(function(){                                
       cat_id = jQuery("#field_category_tidpast").val(); 
       uid_id = jQuery("#uidpast").val(); 
       cout_id = jQuery("#countrypast").val(); 
       past_date = jQuery("#datepicker").val(); 
       window.location.href="past-auctions?field_category_tid="+cat_id+"&uid="+uid_id+"&country="+cout_id+"&pastauctiondate="+past_date; 
    }); 
    jQuery( ".pastauct-datepick" ).datepicker({
        
           showOn: "button",
           buttonImage:Drupal.settings.basePath + "sites/all/themes/paimai_live/images/calender-icon.png",
           buttonImageOnly: true,
           dateFormat: 'yy-mm-dd',
           onSelect: function(dateText, inst) { 
           cat_id = jQuery("#field_category_tidpast").val(); 
            uid_id = jQuery("#uidpast").val(); 
            cout_id = jQuery("#countrypast").val(); 
            window.location.href="past-auctions?field_category_tid="+cat_id+"&uid="+uid_id+"&country="+cout_id+"&pastauctiondate="+dateText; 
    }
    });
  
});
