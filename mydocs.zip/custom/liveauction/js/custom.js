 jQuery(document).ready(function() {
	 jQuery(".error-msg").hide();
	 
		jQuery('.range').keyup(function() {
		var val = jQuery(this).val();

			if (isNaN(val)) 
			{			
				jQuery(this).val("");
				return false;
			}
			else if (parseInt(val,10) != val || val<= 0) 
			{
				jQuery(this).val("");
				return false;
			}
		});
		
		jQuery('.range-value').keyup(function() {
		var val = jQuery(this).val();

			if (isNaN(val)) 
			{			
				jQuery(this).val("");
				return false;
			}
			else if (parseInt(val,10) != val || val<= 0) 
			{
				jQuery(this).val("");
				return false;
			}
		});
		jQuery('.bp_range').keyup(function() {
		var val = jQuery(this).val();

			if (isNaN(val)) 
			{			
				jQuery(this).val("");
				return false;
			}
			else if (parseInt(val,10) != val || val<= 0) 
			{
				jQuery(this).val("");
				return false;
			}
		});
		 
	 
	 
	 
	 
	 
		jQuery("#bid-increment-form").submit(function( event ) {
			// alert(jQuery("#edit-range2-value").val());
			
			msgstr ="";
			/* All Range Value Fields */
			jQuery("input.range-value[type=text]").each(function() {		
			if(isNaN(this.value)) {
			 msgstr = msgstr + "<div>" + this.value + " is not a valid number </div>";
			 
			}
			if(this.value < 0 ) {
			 msgstr = msgstr + "<div>" + this.value + " is not a valid number </div>";			 
			}
			
			});
			/* All Buyer Premium Range Fields */
			jQuery("input.bp_range[type=text]").each(function() {		
			if(isNaN(this.value)) {
			 msgstr = msgstr + "<div>" + this.value + " is not a valid number </div>";			 
			}
			if(this.value < 0 ) {
			msgstr = msgstr + "<div>" + this.value + " is not a valid number </div>";			 
			}
			if(this.value!="") {
					post_tf_id  = jQuery(this).attr("clbl2");
					pre_tf_id = jQuery(this).attr("clbl1");
					// alert(pre_tf_id + "0000" + post_tf_id);
					if(jQuery.trim(pre_tf_id)!='na')
					{ 
						if(jQuery.trim(pre_tf_id)=="")
						{
							msgstr = msgstr + "<div>Buyer Premium value is not properly filled for Range " +  this.value + " </div>";	
						}
					}
					
					
						post_tf_value = jQuery("#" + post_tf_id).val();
						if(jQuery.trim(post_tf_value)=="")
						{
							msgstr = msgstr + "<div>Buyer Premium value is not properly filled for Range " +  this.value + " </div>";
						}
						// alert(pre_tf_value + "+" + post_tf_value);
						// alert(pre_tf_id + " " + post_tf_id);					
			
				  /* Validation For Incremental Value */
					range_id = jQuery(this).attr("id");
					var arr = range_id.split('_');
					var curid = parseInt(arr[1]);
					crf_val = jQuery('#bprange_2' + curid).val();
					if(curid > 1)
					{
						var preid = parseInt(curid) - 1;
						prf_val = jQuery('#bprange_2' + preid).val();
						if(parseInt(prf_val) > parseInt(crf_val))
						{
								msgstr = msgstr + "<div> Buyer Premium Range should be in incremental Order for " +  this.value + " </div>";
						}
					}
					var postid = parseInt(curid) + 1;
					if(postid < 3)
					{
						porf_val = jQuery('#bprange_2' + postid).val();
						if(parseInt(porf_val) < parseInt(crf_val))
						{
							msgstr = msgstr + "<div> Buyer Premium Range should be in incremental Order for " +  this.value + " </div>";
						}
					}
					
				
			}
			
			});
			/* All Range Fields  */
			jQuery("input.range[type=text]").each(function() {		
			if(isNaN(this.value)) {
				msgstr = msgstr + "<div>" + this.value + " is not a valid number </div>";
			}
			if(this.value < 0 ) {
			msgstr = msgstr + "<div>" + this.value + " is not a valid number </div>";			 
			}
			
				if(this.value!="") {
					post_tf_id  = jQuery(this).attr("clbl2");
					pre_tf_id = jQuery(this).attr("clbl1");
					// alert(pre_tf_id + "0000" + post_tf_id);
					if(jQuery.trim(pre_tf_id)!='na')
					{ 
						if(jQuery.trim(pre_tf_id)=="")
						{
							msgstr = msgstr + "<div>Bid Increment value is not properly filled for Range " +  this.value + " </div>";	
						}
					}
					
					
						post_tf_value = jQuery("#" + post_tf_id).val();
						if(jQuery.trim(post_tf_value)=="")
						{
							msgstr = msgstr + "<div>Bid Increment value is not properly filled for Range " +  this.value + " </div>";
						}
						// alert(pre_tf_value + "+" + post_tf_value);
						// alert(pre_tf_id + " " + post_tf_id);					
			
				  /* Validation For Bid Incremental Value */
					range_id = jQuery(this).attr("id");
					var arr = range_id.split('_');
					var curid = parseInt(arr[1]);
					crf_val = jQuery('#range_' + curid).val();
					if(curid > 1)
					{
						var preid = parseInt(curid) - 1;
						prf_val = jQuery('#range_' + preid).val();
						if(parseInt(jQuery.trim(prf_val)) > parseInt(jQuery.trim(crf_val)))
						{
								msgstr = msgstr + "<div> Bid Increment Range should be in incremental Order for " +  this.value + " </div>";
						}
					}
					var postid = parseInt(curid) + 1;
					if(postid < 10)
					{
						porf_val = jQuery('#range_' + postid).val();
						if(parseInt(porf_val) < parseInt(crf_val))
						{
							msgstr = msgstr + "<div> Bid Increment Range should be in incremental Order for "  +  this.value + " </div>";
						}
					}
					
					
					
				} /* End Of If this.value */
			});
			
			
			if(jQuery("#range_2").val()=="")
			{
				msgstr = msgstr + "<div>Bid Increment Range 1 is Required. </div>";				
			}
			if(jQuery("#range1_value").val()=="")
			{
				msgstr = msgstr + "<div>Bid Increment Range 1 value is Required. </div>";				
			}
			if(jQuery("#bp_range1_value").val()=="")
			{
				msgstr = msgstr + "<div>Buyer Premium Range 1 value is Required. </div>";				
			}
			
			if(msgstr!="")
			{
				 jQuery(".error-msg").show();
				jQuery(".error-msg").html(msgstr);
				jQuery("html, body").animate({ scrollTop: 0 }, 600);
				return false;
			}
			/*
			else
			{
				return true;
			} */
			//event.preventDefault();
			return true;
		});
  });
