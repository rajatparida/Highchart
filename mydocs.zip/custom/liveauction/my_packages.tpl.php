<?php global $base_url,$user;
$theme_path = drupal_get_path('theme', variable_get('theme_default', NULL));
$imgpath = $base_url . "/" . $theme_path;?>
<div class="dash-packages">
                <!-- <div class="graph-cont">
                <h3>Bar graph</h3>
                <p>Title</p>
                <a href="#"><img src="<?php echo $imgpath ?>/images/bar-graph.png" alt=""></a>
                </div> -->
                <div class="package-cont">
                                 <h3>My Packages</h3>
                                 

	
		
			<?php if(is_array($data)) { ?>                            
			<ul><?php 
			foreach($data as $sub_pack){  
				echo '<li>'.$sub_pack['title'].' -- '.date("Y-m-d",$sub_pack['sub_date']).'</li>'; 
			} 
			?> 
			</ul> 
			<?php } else{ 
			 echo '<ul><li>No any packages. <a href="'.$base_url.'/user/'.$user->uid.'/buy-auction-package">Purchase Package.</a></li></ul>'; 
			} 
			if($readmore=='yes'){ 
				echo '<div class="view-more"><a class="btn-black" href="'.$base_url.'/packageslist" >VIEW MORE</a></div>'; 
			} 
			?> 

                               
                            </div>
                       </div>