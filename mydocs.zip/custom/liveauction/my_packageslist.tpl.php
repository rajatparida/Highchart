<?php global $base_url, $user;
?>
<div> 
                <?php if(is_array($data))
                {?>                           
                        <table >
                            <tr>
                                <th style="width:10%">
                                    Sr. No.
                                </th>
                                <th style="width:20%">
                                    Package Name
                                </th>
                                <th style="width:50%">
                                    Auction Name
                                </th>
                                <th style="width:20%">
                                    Creation date
                                </th>
                            </tr>
                        <?php
                        $j=1;
                        foreach($data as $sub_pack)
                        {
                            $fetch_node_alias = drupal_lookup_path('alias', 'node/'.$sub_pack['nid']);
                            ?>
                             <tr>
                                <td>
                                   <?php
                                        echo $j;
                                     ?>
                                </td>
                                <td>
                                   <?php
                                        echo $sub_pack['packname'];
                                     ?>
                                </td>
                                <td>
                                    <a href="<?php  echo $base_url.'/'.$fetch_node_alias; ?>" target="_blank">
                                   <?php
                                        echo $sub_pack['title'];
                                     ?>
                                    </a>
                                </td>
                                <td>
                                    <?php
                                        echo date("Y-m-d",$sub_pack['sub_date']);
                                     ?>
                                </td>
                            </tr>
                           
                      <?php
                      $j++;
                           }
                        ?>
                        </table>
                <?php } 
                else{ echo 'No any packages. <a href="'.$base_url.'/user/'.$user->uid.'/buy-auction-package">Purchase Package.</a>';}
                ?>
                <?php ?>

                <div class="clear"></div>
                <div> <?php echo $paging;?> </div>
                </div>
		</div>
</div>
