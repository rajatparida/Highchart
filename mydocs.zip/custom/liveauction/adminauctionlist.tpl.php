<div class="admin-auction">
	<table>
		<tr>
			<th>Sl No</th>
			<th>Auction name</th>
			<th>Assigned To</th>
			<th>Action</th>
			</tr> 
		<?php  
		$destination = drupal_get_destination(); 
		$i = 0 ; 
		foreach ($adminauction as $key => $value) { 
			$i ++ ;
			$val = node_load($value->auction_id) ;
			$user_dtl = user_load($val->field_seller['und'][0]['uid']);			
			$first_name = $user_dtl->field_first_name['und'][0]['value'];
			$last_name = $user_dtl->field_last_name['und'][0]['value'];
			?> 
			<tr> 
				<td><?php echo $i ; ?></td>
				<td><?php echo $val->title ; ?></td>
				<td><?php echo $first_name.'&nbsp;'.$last_name ; ?></td>
				<td>
				<?php echo $link = l('Edit', 'node/'.$val->nid.'/edit', 
				array('attributes'=>array('class' => array(' long_button ')),
				'query' => array('destination' => $destination['destination']))); ?> | 

				<?php echo $link = l('Delete', 'node/'.$val->nid.'/delete', 
				array('attributes'=>array('class' => array(' long_button ')),
				'query' => array('destination' => $destination['destination']))); ?>
				</td>
			</tr>
		<?php } ?>
</table>
</div>