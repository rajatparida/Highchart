<?php
$nid=$data;
$node_dt=node_load($nid);
//print_r($node_dt);
$uid=$node_dt->uid;
$user_dt=user_load($uid);
$cr_status_tid=$node_dt->field_contract_request_status['und'][0]['tid'];
 $req_status_load =taxonomy_term_load($cr_status_tid);
 $req_status = $req_status_load->name;
?>
<table width="50%" style="width:50%!important;">
	<tr><td width="25%"><strong>Title</strong> </td><td><?php echo $node_dt->title?></td></tr>
	<tr><td><strong>Sent On</strong> </td><td><?php echo date("Y-m-d",$node_dt->created)?></td></tr>
	<tr><td><strong>Seller</strong> </td><td><?php echo $user_dt->name;?></td></tr>
	<tr><td><strong>Status</strong> </td><td><?php echo $req_status;?></td></tr>
	<tr><td><strong>Description</strong> </td><td><?php echo $node_dt->body['und'][0]['value'];?></td></tr>
	<tr><td><strong>&nbsp;</strong> </td><td><a onclick="history.go(-1);" href="javascript:void(0)"> Back</a>
	</td></tr>
	
</table>
