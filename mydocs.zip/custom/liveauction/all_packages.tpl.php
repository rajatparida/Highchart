<?php
global $base_url;
global $user;
//print_r($user->roles);
//echo 'Hello'. $user->roles[14] ;
//print_r($data);
?>
 <div class="seller-dash">
                    <h3>Buy Auction Package </h3>
                </div>
<div class="profile-details">
    <div class="profile1">
        <div class="setup-left tablecell">
            <div class="setup-cont1 table1">
                <div class="setup-details table-row">
                    <?php
                    if (is_array($data)) {
                        foreach ($data as $node_pkg) {
                            $node_dt = node_load($node_pkg->nid);
                            $max_item = $node_dt->field_maximum_items['und'][0]['value'];
                            if ($max_item == -1):
                                $max_item = "Unlimited";
                            endif;
                            ?>
                            <div class="setup-cont1-left">
                                <div class="setup2">
                                    <h3><a href="<?php echo url('node/' . $node_pkg->nid) ?>"> <?php echo $node_pkg->title; ?> </a> </h3>
                                    <p> <?php echo $node_dt->body['und'][0]['value']; ?> </p>
                                    <p><em>CHF <?php echo number_format($node_dt->sell_price, 2); ?></em></p>
                                    <!-- <p><span class="bold1">Maximum Item Limit -</span> 1300</p> -->
                                    <?php if ($max_item) { ?><p><span class="bold1"> Maximum Item Limit -</span>  <?php echo $max_item; ?></p> <?php } ?>
                                    <!-- <input type="text" value="" name=""> -->
                                    <br>
                                    <?php
                                    if (($node_pkg->nid == "299") && (in_array('Contract', array_values($user->roles)))) {
                                        echo "<br/>";
                                        echo "Already you have this package";
                                        echo "<br/>";
                                        echo "<div class='addauc'>";
                                        echo l('Add Auction', $base_url . '/node/add/auction-catalog', array('attributes' => array('class' => 'btn-black pad17')));
                                        echo "</div>";
                                    } elseif (($node_pkg->nid == "299")) {
                                        echo contract_request();
                                    } else {
                                        print drupal_render(drupal_get_form('uc_product_add_to_cart_form_' . $node_pkg->nid, $node_dt));
                                    }
                                    ?>
                                </div>
                            </div>
                            <?php
                        } /* End of Foreach */
                    } /* End Of If */
                    ?>                                     
                    <!-- <div class="setup-cont1-left">
                         <div class="setup2">
                             <h3>Mini Auctioneers </h3>
                             <p>CHF 260 + <span>5% online sales</span></p>
                             <p><em>CHF 260.00</em></p>
                             <p><span class="bold1">Maximum Item Limit -</span> 250</p>
                             <input type="text" value="" name="">
                             <br>
                             <a class="btn-black pad17" href="#">Add to Cart</a>
                         </div>
                     </div>
                                                     <div class="setup-cont1-left">
                         <div class="setup2">
                             <h3>Online Seller </h3>
                             <p>CHF 86 + <span>5% online sales</span></p>
                             <p><em>CHF 86.00</em></p>
                             <p><span class="bold1">Maximum Item Limit -</span> 86</p>
                             <input type="text" value="" name="">
                             <br>
                             <a class="btn-black pad17" href="#">Add to Cart</a>
                         </div>
                     </div>
                     <div class="setup-cont1-left">
                         <div class="setup2">
                             <h3>Promotion </h3>
                             <p>
                                 <span>*</span>please check the updated offers in our News
     http://184.164.156.54/drupal/auctionportal/
                             </p>
                             <p><em>CHF 290.00</em></p>
                             <p><span class="bold1">Maximum Item Limit -</span> 1300</p>
                             <input type="text" value="" name="">
                             <br>
                             <a class="btn-black pad17" href="#">Add to Cart</a>
                         </div>
                     </div>
                                                     <div class="setup-cont1-left">
                         <div class="setup2">
                             <h3>Top Banner Ad (960*102) </h3>
                             <p>in homepage slideshow (lower-centered) on Paimai-LiveAuctioneers</p>
                             <p>CHF 280/week</p>
                             <p><em>CHF 280.00</em></p>
                             <select>
                                 <option>Week</option>
                                 <option>Week1</option>
                                 <option>Week2</option>
                             </select>
                             <input type="text" value="" name="">
                             <br>
                             <a class="btn-black pad17" href="#">Add to Cart</a>
                         </div>
                     </div>
                     <div class="setup-cont1-left">
                         <div class="setup2">
                             <h3>Bottom Banner Ad (960*64) </h3>
                             <p>in homepage slideshow (lower-centered) on Paimai-LiveAuctioneers</p>
                             <p>CHF 880/week</p>
                             <p><em>CHF 880.00</em></p>
                             <select>
                                 <option>Week</option>
                                 <option>Week1</option>
                                 <option>Week2</option>
                             </select>
                             <input type="text" value="" name="">
                             <br>
                             <a class="btn-black pad17" href="#">Add to Cart</a>
                         </div>
                     </div>
                 
               
                     <div class="setup-cont1-left">
                         <div class="setup2">
                             <h3>Contract </h3>
                             <p>CHF 290 + <span>3% online sales</span></p>
                             <p><em>CHF 290.00</em></p>
                             <p><span class="bold1">Maximum Item Limit -</span> Unlimited</p>
                             <p>Already you have this package</p>
                             <a class="btn-black pad17" href="#">Add to Cart</a>
                         </div>
                     </div> -->

                </div>
            </div>
        </div>
        <div class="setup-right tablecell">
            <div class="setup-top">
                <h4>Your Cart</h4>
            </div>
            <div class="setup-table">
                 
                 <?php
                 $myprofile_block = module_invoke('uc_ajax_cart','block_view','delta-0');
                 print render($myprofile_block['content']);
                 ?>
               <!-- <table cellspacing="0" cellpadding="0" class="setup-tab">
                    <thead>
                        <tr>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Qnt.</th>
                            <th>Total</th>
                            <th>Remove</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="odd">
                            <td class="first-col">Traditional Auctioneers</td>
                            <td>580.00</td>
                            <td>1</td>
                            <td>580</td>
                            <td><a href="#">
                                    <img alt="" src="images/remove-icon.png"></a></td>
                        </tr>
                        <tr class="even">
                            <td class="first-col">Mini Auctioneers</td>
                            <td>260.00</td>
                            <td>5</td>
                            <td>1300</td>
                            <td><a href="#">
                                    <img alt="" src="images/remove-icon.png"></a></td>
                        </tr>
                        <tr class="odd">
                            <td class="first-col">Promotion</td>
                            <td>290.00</td>
                            <td>3</td>
                            <td>870</td>
                            <td><a href="#">
                                    <img alt="" src="images/remove-icon.png"></a></td>
                        </tr>
                        <tr class="even">
                            <td class="first-col">Mini Auctioneers</td>
                            <td>290.00</td>
                            <td>3</td>
                            <td>870</td>
                            <td><a href="#">
                                    <img alt="" src="images/remove-icon.png"></a></td>
                        </tr>
                        <tr class="odd">
                            <td class="first-col">Promotion </td>
                            <td>260.00</td>
                            <td>5</td>
                            <td>1300</td>
                            <td><a href="#">
                                    <img alt="" src="images/remove-icon.png"></a></td>
                        </tr>
                    </tbody>
                </table> -->
            </div>
            <!-- <div class="setup-total">17 Items Total  4920.00 </div> -->
        </div>
    </div>
</div>

<?php
/*
if (is_array($data)) {
    foreach ($data as $node_pkg) {
        $node_dt = node_load($node_pkg->nid);
        $max_item = $node_dt->field_maximum_items['und'][0]['value'];
        if ($max_item == -1):
            $max_item = "Unlimited";
        endif;
        //print_r($node_dt);
        ?>
        <div class="pkg">
            <div class='pkg-title'><a href="<?php echo url('node/' . $node_pkg->nid) ?>"> <?php echo $node_pkg->title; ?> </a></div>
            <div class='pkg-desc'> <?php echo $node_dt->body['und'][0]['value']; ?></div>
            <div class='pkg-price'>CHF <?php echo number_format($node_dt->sell_price, 2); ?></div>

            <?php if ($max_item) { ?><div class='pkg-price'> Maximum Item Limit - <?php echo $max_item; ?></div> <?php } ?>

            <div class='pkg-desc'> 
                <?php
                if (($node_pkg->nid == "299") && (in_array('Contract', array_values($user->roles)))) {
                    echo "<br/>";
                    echo "Already you have this package";
                    echo "<br/>";
                    echo "<div class='addauc'>";
                    echo l('Add Auction', $base_url . '/node/add/auction-catalog', array('attributes' => array('class' => 'btn-black pad17')));
                    echo "</div>";
                } elseif (($node_pkg->nid == "299")) {
                    echo contract_request();
                } else {
                    print drupal_render(drupal_get_form('uc_product_add_to_cart_form_' . $node_pkg->nid, $node_dt));
                }
                ?>
            </div>
        </div>
        <?php
    }
    ?>                           

<?php } else {
    echo 'No any packages.';
}
*/ ?>


<div class="clear"></div>
