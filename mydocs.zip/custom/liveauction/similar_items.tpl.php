<?php
global $base_path, $base_url;
global $user;
$theme_path = drupal_get_path('theme', variable_get('theme_default', NULL));
$imgpath = $base_url . '/' . $theme_path;
//print_r($data);
if(count($data)>0) {
?>
<div class="lot-detail-right-block">
    <div class="detail-slider-arrow"> 

        <div id="p-select" class="glidecontenttoggler">
            <a href="#" class="prev arrow-left lot-detail-arrow-sprite">&nbsp;</a> 

            <a href="#" class="next arrow-right lot-detail-arrow-sprite">&nbsp;</a>
        </div>
    </div>
    <h2>Similar Items from this auction</h2>
    <div class="lot-detail-right-inner-cont MR-0">
        <div id="canadaprovinces" class="glidecontentwrapper">
            <?php
            $i = 1;
            foreach ($data as $outerlot) {
                echo '<div class="glidecontent gallary-lot-detail"><ul>';
                foreach ($outerlot as $inlot) {
                    $lot_id = $inlot->nid;
                    $lot_dt = node_load($lot_id);
                    //if()$lot_dt->uc_product_image['und'][0]['uri']
                    if (!file_exists(($lot_dt->uc_product_image['und'][0]['uri']))) {
                        $lot_img = $base_url . "/sites/default/files/noimage.jpg";
                    } else {
                        $lot_img = file_create_url($lot_dt->uc_product_image['und'][0]['uri']);
                    }

                    //$lot_img = file_create_url($lot_dt->uc_product_image['und'][0]['uri']);
                    echo '<li><a href="'.url('node/'.$lot_id).'"><img alt="" src="' . $lot_img . '"  alt="'.$lot_dt->title.'" title="'.$lot_dt->title.'"></a></li>';
                }

                echo '</ul></div>';
            }
            ?>

          

          

        </div>

    </div>
</div>
<?php } ?>