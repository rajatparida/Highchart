<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Paimai Live Auction --- New Auction</title>

</head>
<body>
  <?php echo $data['body'];?>
</body>
</html>