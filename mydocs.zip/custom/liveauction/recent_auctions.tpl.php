<?php
global $base_url;
$theme_path = drupal_get_path('theme', variable_get('theme_default', NULL));
$imgpath = $base_url . "/" . $theme_path;
?>
<div class="lot-detail-right-block">
    <div class="detail-slider-arrow"> 
        <div id="p-select" class="glidecontenttoggler">
            <a class="prev arrow-left lot-detail-arrow-sprite" href="#">&nbsp;</a> 
            <a class="next arrow-right lot-detail-arrow-sprite" href="#">&nbsp;</a> 
        </div>
    </div>
    <h2>Recent Auctions</h2>
    <div class="lot-detail-right-inner-cont MR-0">
        <div id="canadaprovinces" class="glidecontentwrapper">
            <?php
            foreach ($data as $outer_auc) {
                echo '<div class="glidecontent recent-lot">';
                foreach ($outer_auc as $auction) {

                    $auction_id = $auction->nid;
                    $auction_dt = node_load($auction_id);
                    //$lot_id = 
                    //print_r($auction_dt);die;
                    ?>
                    <div class="lot1-cont">
                        <div class="lot1-left">
                            <?php $img_src= get_auction_image($auction_id,'157x137');
                            if(empty($img_src)) {$img_src=$base_url."/sites/default/files/noimage.jpg"; $style="style='width:157px;height:137px;'"; } ?>
                            <a href="<?php echo url('catalog/'.$auction_id);?>"><img title="<?php echo $auction_dt->title?>" alt="<?php echo $auction_dt->title?>" src="<?php echo $img_src; ?>" <?php echo $style;?>></a>
                        </div>
                        <div class="lot1-right">
                            <h3><?php echo l($auction_dt->title,"catalog/".$auction_id);?> </h3>
                            <p><?php echo $auction_dt->field_auction_start_time['und'][0]['value'];?></p>
                        </div>
                    </div>
                    <?php
                }
                echo "</div>";
            }
            ?>


        </div>
    </div>
</div>
