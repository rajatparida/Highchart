<?php
// print_r($data);
?>
<div class="dash-news">
                        	<h3>Latest News</h3>
                            <div class="dash-list">
<?php foreach($data as $lat_news)
{
 
    $news_load =node_load($lat_news->nid);
    if (!file_exists($news_load->field_image['und'][0]['uri'])) {
        $lat_img = $base_url . "/sites/default/files/noimage.jpg";
    } else {
        $lat_img = file_create_url($news_load->field_image['und'][0]['uri']);
    }
            ?>
                            	<div class="dash1">
                                	<div class="dash1-image">
                                            <a href="<?php echo url("node/".$news_load->nid)?>"><img alt="<?php echo $news_load->title?>" src="<?php echo $lat_img;?>" width="240" height="150" title="<?php echo $news_load->title?>"></a>
                                        <div class="dash-date">
                                        	<span class="date1"><?php echo date("d",$news_load->created);?></span>
                                            <em>|</em>
                                            <span><?php echo date("M",$news_load->created);?><br><em class="year1"><?php echo date("Y",$news_load->created);?></em></span>
                                        </div>
                                    </div>
                                    <div class="dash1-head1">
                                        <h4><a href="<?php echo url("node/".$news_load->nid)?>" alt="<?php echo $news_load->title?>" title="<?php echo $news_load->title?>"><?php echo truncate_utf8($news_load->title, 40, TRUE, TRUE) ?></a></h4>
                                        <p> <?php echo truncate_utf8($news_load->body['und'][0]['value'], 350, TRUE, TRUE); ?></p>
                                    </div>
                                </div>
<?php } ?>                                        
                                
                                
                                
                                
                                
                            </div>
                       </div>