                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            <?php
global $base_url;
global $user;
$act_val = node_load($eoa_list[0]->auction_id);
//print_r($act_val); 
/*  $query = db_select('bidder', 'bidder'); 
  $query->fields('bidder');
  $query->condition('bidder.id', 79);
  $result = $query->execute()->fetchAll();
  print_r($result);die; */
?>
<h2>End Of Auction - <?php echo $act_val->title; ?></h2>
<table>
    <tr>
        <th>Lot</th>
        <th>Title</th>
        <th>Hammer Price</th>
        <th>Premium</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Username</th>
        <th>Email</th>
        <th>Paid</th>
        <th>Shipped</th>
        <th>Dispute</th>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
        <th title="First you need to send request to admin to get enable the remove button.">Remove</th>                                                                                                                                                                                                                                                                                                                                                                                                                                            
    </tr>                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                            
    <?php
    foreach ($eoa_list as $value) {                                                                                                                                                                                                                                                                                                         
        //print_r($value);
        $isDisputed = $value->dispute;
        $isPaid = $value->paid;
        $isShipped = $value->shipped;
        $isRequested = $value->remove;
        $act_dtl = node_load($value->auction_id);
        $user_dtl = user_load($value->user_id);
        $lot_dtl = node_load($value->lot_id);
        //   print_r($act_dtl);
        //print_r($user_dtl); 
        // $act_dtl = node_load($res->auctionid) ;     
        //    echo ;
        /* After 10 days of EOA, Dispute functionality will be enabled. */
        if (strtotime(date("Y-m-d", $value->created) . ' + 10 days') < strtotime(date("Y-m-d"))) {
            $chkDisputable = "";
            $chkDisputeText = "Click here to dispute this lot.";
        } else {
            $chkDisputable = "disabled='disabled'";
            $chkDisputeText = "You will be able to dispute this lot on: " . date("Y-m-d", strtotime(date("Y-m-d", $value->created) . ' + 10 days'));
        }
        if( $isRequested == "9" ) {
            $disable_txt = "disabled='disabled'";
            $trstrike = "trstriked";
        }
        else { $trstrike = "";}
        ?>
        <tr class="<?php echo $trstrike;?>">
            <td><?php echo $value->lot_no; ?></td>
            <td><?php echo $lot_dtl->title; ?></td>
            <td>
    <?php echo $value->hammer_price; ?><br>
    <?php //echo date("Y-m-d",$value->created);  ?>
                <?php //echo date('Y-m-d', strtotime(date("Y-m-d",$value->created). ' + 10 days')) ?>
            </td>
            <td><?php 
            
           $premiumval = getPremiumValue($value->auction_id, $value->hammer_price); 
           echo  $newpremium = $value->hammer_price * ($premiumval / 100);
            ?></td>
            <td><?php echo $user_dtl->field_first_name['und'][0]['safe_value']; ?></td>
            <td><?php echo $user_dtl->field_last_name['und'][0]['safe_value']; ?></td>
            <td><?php echo $user_dtl->name; ?></td>
            <td><?php echo $user_dtl->mail; ?></td>
            <td>
    <?php
    if (($isPaid == 0) && ($isRequested != "9")) {
        $href = $base_url . "/user/" . $user->uid . "/markpaid/" . $value->id;
        ?>
                    <a href="javascript:void(0)"><input type="checkbox" name="isPaid" id="isPaid" value="" onchange="plsConfirm('<?php echo $href ?>', 'paid')" ></a> 
                </td> 
    <?php
    } 
    elseif($isRequested == "9"){
        echo '<input type="checkbox" name="isPaid" id="isPaid" value="" checked="checked" disabled="disabled">';        
    }else {
        echo '<input type="checkbox" name="isPaid" id="isPaid" value="" checked="checked" disabled="disabled">';
    }
    ?>
            <td>
                <?php
                if (($isShipped == 0) && ($isRequested != 9)) {
                    $href = $base_url . "/user/" . $user->uid . "/markshipped/" . $value->id;
                    ?>
                    <a href="javascript:void(0)"><input type="checkbox" name="isShipped" id="isShipped" value="" onchange="plsConfirm('<?php echo $href ?>', 'shipped')" ></a> 
                </td> 
            <?php
            } else {
                echo '<input type="checkbox" name="markshipped" id="markshipped" value="" checked="checked" disabled="disabled">';
            }
            ?>
            </td>
            <td>
                <?php
                if (($isDisputed == 0) || ($isDisputed == 2)) {
                    ?>
                    <a href="<?php echo $base_url; ?>/dispute/nojs/reasons/<?php echo $value->id; ?>" class="ctools-use-modal ctools-modal-modal-popup-medium" title="<?php echo $chkDisputeText; ?>"><input type="checkbox" name="dispute" id="dispute" value="55"  <?php echo $chkDisputable ?>/></a>
                <?php } else { ?>
                    <a href="<?php echo $base_url; ?>/dispute/nojs/removereasons/<?php echo $value->id; ?>" class="ctools-use-modal ctools-modal-modal-popup-medium" title="Click here to withdraw dispute this lot."><input type="checkbox" name="dispute" id="dispute" value="55"  checked="checked"/></a>
    <?php } ?>
            </td>	
            <td>
                <!--	
                0 - Default State; 
                1-  Requested For Remove; 
                2-  Admin Approved the Removal;
                3-  Admin Declined the removal;
                4 - Removed -->
                <?php
                if ($isRequested == 0) {
                    ?>
                    <a href="<?php echo $base_url; ?>/remove/nojs/request/<?php echo $value->id; ?>" class="ctools-use-modal ctools-modal-modal-popup-medium" title="Click here to Request to admin to remove this lot.">Request to Admin</a>
                <?php } elseif ($isRequested == 1) {
                    echo "Pending for Admin Approval"; ?>						
                <?php
                } elseif ($isRequested == 2) {
                    $href = $base_url . "/user/" . $user->uid . "/remove/soldlot/" . $value->id;
                    ?>
                    <!-- <a href="javascript:void(0)" onClick = "plsConfirm('<?php echo $href ?>', 'removed')">Remove</a> -->
                    <a href="<?php echo $base_url; ?>/cancel/nojs/request/<?php echo $value->id; ?>" class="ctools-use-modal ctools-modal-modal-popup-medium" title="Click here to Request to Bidder to remove this lot.">Request to Bidder</a>
                <?php
                } elseif ($isRequested == 3) {
                    echo '<span title="Admin has rejected your removal request.">Rejected</span>';
                } elseif ($isRequested == 4) {
                    echo '<span title="Request Sent, pending at bidder end.">Pending</span>';
                } elseif ($isRequested == 5) {
                    echo '<span title="Bidder Approved, pending at Admin end.">Pending</span>';
                } elseif ($isRequested == 6) {
                    echo '<span title="Bidder Rejected, pending at Admin end.">Pending</span>';
                } elseif ($isRequested == 7) {
                    $href = $base_url . "/user/" . $user->uid . "/remove/soldlot/" . $value->id;
                    ?>
                    <a href="javascript:void(0)" onClick = "plsConfirm('<?php echo $href ?>', 'removed')" title="Finally Remove this lot.">Remove</a> 

        <?php
        } elseif ($isRequested == 8) {
            echo '<span title="Admin has rejected your removal request.">Rejected</span>';
        } elseif ($isRequested == 9) {
            echo "Removed";
        }
        ?>
            </td>


        </tr>
<?php } ?>
</table>

