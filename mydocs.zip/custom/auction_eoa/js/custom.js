function plsConfirm(href,mode) {
 if(!confirm("Are you sure you want to mark this as " + mode + "?")){
	 return false;
 }else{
	 window.location = href;
 }
}
